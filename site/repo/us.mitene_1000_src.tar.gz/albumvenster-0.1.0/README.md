# Albumvenster

Android-app voor het lokaal testen van de invoer van een gebruikersnaam en wachtwoord. Gebruik voorbeeldgegevens. De app wist het wachtwoord na de invoertest. Aanmelden bij FamilyAlbum, albums bekijken en uploaden zijn niet beschikbaar in versie 0.1.0.

Deze onafhankelijke app gebruikt Kotlin en Jetpack Compose en wordt verspreid onder GPL-3.0-only.

Deze zelfstandig ondertekende invoertest gebruikt de pakketnaam us.mitene. Android kan deze app en FamilyAlbum niet naast elkaar installeren.
