plugins {
    id("com.android.application") version "8.9.2"
    id("org.jetbrains.kotlin.android") version "2.1.20"
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.20"
}
android {
    namespace = "us.mitene"
    compileSdk = 35
    defaultConfig {
        applicationId = "us.mitene"
        minSdk = 26
        targetSdk = 35
        versionCode = providers.gradleProperty("releaseCode").orNull?.toInt() ?: 1000
        versionName = providers.gradleProperty("releaseName").getOrElse("0.1.0-dev")
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
kotlin { jvmToolchain(17) }
dependencies {
    implementation(platform("androidx.compose:compose-bom:2025.04.01"))
    implementation("androidx.activity:activity-compose:1.10.1")
    implementation("androidx.compose.material:material")
}

