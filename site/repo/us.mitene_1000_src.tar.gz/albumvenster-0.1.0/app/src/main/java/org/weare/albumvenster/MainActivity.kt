package org.weare.albumvenster

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { LoginForm() } }
    }
}

@Composable
private fun LoginForm() {
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var checked by remember { mutableStateOf(false) }
    val focus = LocalFocusManager.current
    Column(
        modifier = Modifier.fillMaxSize().systemBarsPadding().imePadding()
            .verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Albumvenster", style = MaterialTheme.typography.h4)
        Text("Test de invoer met voorbeeldgegevens. Deze versie controleert de velden alleen op dit toestel.")
        OutlinedTextField(
            value = username,
            onValueChange = { username = it; checked = false },
            label = { Text("Gebruikersnaam of e-mailadres") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = password,
            onValueChange = { password = it; checked = false },
            label = { Text("Wachtwoord") },
            singleLine = true,
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            enabled = username.isNotBlank() && password.isNotEmpty(),
            onClick = {
                focus.clearFocus()
                password = ""
                checked = true
            }
        ) { Text("Invoer testen") }
        if (checked) Text("Beide velden waren ingevuld. Het wachtwoord is gewist.")
    }
}
