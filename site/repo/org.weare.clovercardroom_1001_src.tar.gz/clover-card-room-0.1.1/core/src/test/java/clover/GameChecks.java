package clover;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public final class GameChecks {
    public static void main(String[] args) {
        pokerRanking();
        holdemStreets();
        holdemAllInPots();
        holdemBoardSplit();
        solitaireMoves();
        klaverBonuses();
        switchyardRouteCards();
        for (int seed = 0; seed < 100; seed++) {
            pokerMatch(seed);
            trickMatch(false, seed);
            trickMatch(true, seed);
            switchyardMatch(seed);
        }
        System.out.println("All five games passed. Ran 400 seeded matches and focused rule checks.");
    }

    private static void pokerRanking() {
        List<Card> wheel = List.of(c(0, 14), c(1, 2), c(2, 3), c(3, 4), c(0, 5));
        List<Card> sixHigh = List.of(c(0, 2), c(1, 3), c(2, 4), c(3, 5), c(0, 6));
        List<Card> fullHouse = List.of(c(0, 13), c(1, 13), c(2, 13), c(0, 7), c(1, 7));
        List<Card> flush = List.of(c(0, 14), c(0, 10), c(0, 8), c(0, 3), c(0, 2));
        require(Poker.rank(wheel) >>> 20 == 4 && Poker.rank(wheel) < Poker.rank(sixHigh), "Wheel");
        require(Poker.rank(fullHouse) > Poker.rank(flush), "Full house beats flush");
        List<Card> royal = List.of(c(3, 10), c(3, 11), c(3, 12), c(3, 13), c(3, 14));
        require(Poker.bestRank(royal, List.of(c(0, 2), c(1, 4))) == Poker.rank(royal), "Can play the board");
        List<Card> twoTrips = List.of(c(0, 14), c(1, 14), c(2, 14), c(0, 13), c(3, 2));
        require(Poker.bestRank(twoTrips, List.of(c(1, 13), c(2, 13))) == Poker.rank(
            List.of(c(0, 14), c(1, 14), c(2, 14), c(0, 13), c(1, 13))), "Higher triplet for a full house");
    }

    private static void holdemStreets() {
        Poker poker = new Poker(new Random(7));
        require(poker.board.isEmpty() && poker.hands.stream().allMatch(hand -> hand.size() == 2), "Two hole cards");
        require(poker.pot == 7 && poker.turn == 0 && poker.due() == 5 && poker.minRaiseTo() == 10, "Opening blinds");
        poker.raiseTo(9);
        require(poker.turn == 0 && poker.pot == 7, "Reject undersized raise");
        poker.call();
        poker.fold();
        poker.call();
        require(poker.turn == poker.bigBlind && poker.due() == 0 && poker.canRaise(), "Big blind keeps its option");
        poker.call();
        require(poker.turn == poker.smallBlind, "First active seat left of the dealer acts after the flop");
        for (int boardSize = 3; boardSize <= 5; boardSize++) {
            require(poker.phase == Poker.Phase.BET && poker.board.size() == boardSize, "Reveal flop, turn and river");
            for (int i = 0; i < 3; i++) poker.call();
        }
        require(poker.reveal && poker.phase == Poker.Phase.SHOWDOWN && poker.burns.size() == 3, "River showdown");
        int priorDealer = poker.dealer;
        poker.nextDeal();
        require(poker.dealer == (priorDealer + 1) % 4 && poker.board.isEmpty(), "Rotate dealer and clear board");
    }

    private static void holdemAllInPots() {
        Poker poker = new Poker(new Random(8));
        poker.chips[0] = 20;
        poker.chips[1] = 45;
        setCards(poker.hands.get(0), List.of(c(0, 14), c(1, 14)));
        setCards(poker.hands.get(1), List.of(c(0, 13), c(1, 13)));
        setCards(poker.hands.get(3), List.of(c(0, 12), c(1, 12)));
        setCards(poker.deck, List.of(c(3, 12), c(0, 2), c(1, 3), c(2, 7),
            c(3, 13), c(3, 9), c(3, 14), c(0, 11)));
        Collections.reverse(poker.deck);
        poker.raiseTo(20);
        poker.raiseTo(45);
        poker.fold();
        poker.call();
        require(poker.phase == Poker.Phase.SHOWDOWN && poker.board.size() == 5, "All-ins run out the board");
        require(Arrays.equals(poker.chips, new int[]{62, 50, 98, 55}), "Main pot and side pot award separately");

        Poker shortRaise = new Poker(new Random(9));
        shortRaise.chips[1] = 7;
        shortRaise.call();
        shortRaise.raiseTo(7);
        shortRaise.call();
        shortRaise.call();
        require(shortRaise.turn == 0 && shortRaise.due() == 2 && !shortRaise.canRaise(),
            "Short all-in does not reopen raising");
    }

    private static void setCards(List<Card> cards, List<Card> replacement) {
        cards.clear();
        cards.addAll(replacement);
    }

    private static void holdemBoardSplit() {
        Poker poker = new Poker(new Random(10));
        setCards(poker.deck, List.of(c(0, 10), c(3, 10), c(3, 11), c(3, 12),
            c(0, 11), c(3, 13), c(0, 12), c(3, 14)));
        Collections.reverse(poker.deck);
        poker.call();
        poker.call();
        poker.fold();
        while (poker.phase == Poker.Phase.BET) poker.call();
        require(Arrays.equals(poker.chips, new int[]{101, 100, 98, 101}),
            "Board plays for the tie, with odd chips awarded left of the dealer");
    }

    private static void pokerMatch(int seed) {
        Poker poker = new Poker(new Random(seed));
        for (int step = 0; step < 2000; step++) {
            int balance = Arrays.stream(poker.chips).sum();
            int onTable = poker.phase == Poker.Phase.BET ? poker.pot : 0;
            require(balance + onTable == 400, "Poker chip conservation");
            for (int chip : poker.chips) require(chip >= 0, "Negative chips");
            Set<Card> unique = new HashSet<>(poker.deck);
            for (Card card : poker.board) require(unique.add(card), "Poker duplicate board card");
            for (Card card : poker.burns) require(unique.add(card), "Poker duplicate burn card");
            for (List<Card> hand : poker.hands) {
                for (Card card : hand) require(unique.add(card), "Poker duplicate card");
            }
            require(unique.size() == 52, "Poker deck conservation");
            switch (poker.phase) {
                case BET -> poker.bot();
                case SHOWDOWN -> poker.nextDeal();
                case OVER -> { return; }
            }
        }
        throw new AssertionError("Poker did not finish");
    }

    private static void klaverBonuses() {
        List<TrickGame.Play> jacks = new ArrayList<>();
        for (int suit = 0; suit < 4; suit++) jacks.add(new TrickGame.Play(suit, c(suit, 11)));
        require(TrickGame.roem(jacks, Card.CLUBS) == 200, "Four jacks");
        List<TrickGame.Play> marriage = List.of(new TrickGame.Play(0, c(0, 11)),
            new TrickGame.Play(1, c(0, 12)), new TrickGame.Play(2, c(0, 13)), new TrickGame.Play(3, c(1, 7)));
        require(TrickGame.roem(marriage, Card.CLUBS) == 40, "Trump run and stuk");
    }

    private static void trickMatch(boolean klaver, int seed) {
        TrickGame table = new TrickGame(klaver, new Random(seed));
        for (int step = 0; step < 2500; step++) {
            switch (table.phase) {
                case TRUMP -> table.botTrump();
                case PASS -> table.pass(new ArrayList<>(table.hands.get(0).subList(0, 3)));
                case PLAY -> {
                    List<Card> legal = table.legal();
                    require(!legal.isEmpty(), "No legal trick play");
                    if (!klaver && table.tricks == 0 && table.trick.isEmpty()) {
                        require(legal.equals(List.of(c(Card.CLUBS, 2))), "Hearts opening lead");
                    }
                    table.botPlay();
                }
                case TRICK -> table.collect();
                case ROUND, OVER -> {
                    require(Arrays.stream(table.roundPoints).sum() == (klaver ? 162 : 26), "Deal total");
                    require(table.hands.stream().allMatch(List::isEmpty), "Unused trick cards");
                    if (table.phase == TrickGame.Phase.OVER) {
                        require(!klaver || table.deal == 16, "Klaverjassen match length");
                        return;
                    }
                    table.nextDeal();
                }
            }
        }
        throw new AssertionError("Trick-taking match did not finish");
    }

    private static void solitaireMoves() {
        Solitaire game = new Solitaire(new Random(1));
        List<Card> originalStock = new ArrayList<>(game.stock);
        for (int i = 0; i < originalStock.size(); i++) require(game.draw(), "Solitaire draw");
        require(game.draw() && game.stock.equals(originalStock), "Stock order after recycling");
        game.undo();
        require(game.stock.isEmpty(), "Undo recycling");
        List<Card> first = game.piles.get(0);
        first.clear();
        first.add(c(Card.HEARTS, 14));
        Solitaire.Source ace = new Solitaire.Source(0, 0);
        require(!game.move(ace, Solitaire.FIRST_FOUNDATION + Card.DIAMONDS), "Wrong foundation suit");
        require(game.move(ace, Solitaire.FIRST_FOUNDATION + Card.HEARTS), "Place ace");
        require(game.built() == 1, "Foundation count");
        List<Card> second = game.piles.get(1);
        second.clear();
        second.add(c(0, 9));
        second.add(c(Card.HEARTS, 2));
        require(game.move(new Solitaire.Source(1, 1), Solitaire.FIRST_FOUNDATION + Card.HEARTS), "Build onto ace");
        require(game.hidden[1] == 0, "Flip uncovered card");
        game.undo();
        require(game.hidden[1] == 1 && game.built() == 1, "Undo flip and build");
    }

    private static void switchyardRouteCards() {
        for (int route = 0; route < 2; route++) {
            Switchyard yard = new Switchyard(new Random(1));
            int first = route == 0 ? 1 : 10;
            int last = route == 0 ? 10 : 1;
            List<Integer> hand = yard.hands.get(0);
            hand.clear();
            hand.add(first);
            hand.add(last);
            require(yard.currentNumber(route) == 0, "New route is empty");
            require(!yard.route(1, route) && yard.currentNumber(route) == 0, "Illegal play leaves route empty");
            require(yard.route(0, route) && yard.currentNumber(route) == first, "Route shows opening card");
            hand.add(first);
            yard.stocks.get(0).add(last);
            yard.signal = true;
            require(yard.route(Switchyard.STOCK, route), "Signal allows a stock card out of sequence");
            require(yard.currentNumber(route) == last, "Route shows signal card at the end of the sequence");
            require(yard.canRoute(1, route) && !yard.canRoute(0, route), "Next play wraps to the first number");
            require(yard.currentNumber(1 - route) == 0, "Other route is unaffected");
        }
    }

    private static void switchyardMatch(int seed) {
        Switchyard yard = new Switchyard(new Random(seed));
        for (int step = 0; step < 500; step++) {
            int cards = yard.supply.size() + yard.spent.size();
            for (List<Integer> stock : yard.stocks) cards += stock.size();
            for (List<Integer> hand : yard.hands) cards += hand.size();
            require(cards == 50, "Switchyard card conservation");
            require(yard.actions >= 0 && yard.actions <= 3, "Switchyard action limit");
            if (yard.winner >= 0) {
                require(yard.stocks.get(yard.winner).isEmpty(), "Switchyard winner still has stock");
                return;
            }
            yard.bot();
        }
        throw new AssertionError("Switchyard stalled");
    }

    private static Card c(int suit, int rank) {
        return new Card(suit, rank);
    }

    private static void require(boolean valid, String rule) {
        if (!valid) throw new AssertionError(rule);
    }
}
