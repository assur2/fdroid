package clover;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Application.ApplicationType;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.math.Rectangle;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.StretchViewport;
import com.badlogic.gdx.utils.viewport.Viewport;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static clover.TableArt.*;

public final class CardRoom extends ApplicationAdapter {
    private enum Game {
        POKER("Texas Hold'em", "Poker", "Make your best hand with the shared cards.", Card.SPADES),
        HEARTS("Four-player Hearts", "Hearts", "Pass three cards and duck penalty tricks.", Card.HEARTS),
        KLAVER("Amsterdam rules", "Klaverjassen", "Take tricks with North and make trump.", Card.CLUBS),
        SOLITAIRE("Draw-one Klondike", "Solitaire", "Build four foundations from ace to king.", Card.DIAMONDS),
        SWITCHYARD("Original stockpile game", "Switchyard", "Clear your stock on two shared routes.", Card.CLUBS);

        final String variant, title, description;
        final int suit;

        Game(String variant, String title, String description, int suit) {
            this.variant = variant;
            this.title = title;
            this.description = description;
            this.suit = suit;
        }
    }

    private record Hit(Rectangle bounds, Runnable click) {}

    private final Random random = new Random();
    private Viewport viewport;
    private final List<Hit> hits = new ArrayList<>();
    private final List<Card> selected = new ArrayList<>();
    private Game game;
    private Poker poker;
    private int raiseTarget;
    private TrickGame hearts, klaver;
    private Solitaire solitaire;
    private Switchyard yard;
    private Solitaire.Source source;
    private Integer ticket;
    private TableArt art;
    private float timer;
    private boolean help, restart;
    private String notice = "";

    @Override
    public void create() {
        viewport = Gdx.app.getType() == ApplicationType.Android
            ? new StretchViewport(WIDTH, HEIGHT) : new FitViewport(WIDTH, HEIGHT);
        art = new TableArt();
        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override
            public boolean touchDown(int x, int y, int pointer, int button) {
                if (pointer != 0 || button != Input.Buttons.LEFT) return false;
                Vector2 point = viewport.unproject(new Vector2(x, y));
                for (int i = hits.size() - 1; i >= 0; i--) {
                    Hit hit = hits.get(i);
                    if (hit.bounds.contains(point.x, HEIGHT - point.y)) {
                        hit.click.run();
                        hits.clear();
                        return true;
                    }
                }
                return false;
            }

            @Override
            public boolean keyDown(int key) {
                if (key != Input.Keys.ESCAPE) return false;
                if (help || restart) {
                    help = restart = false;
                } else {
                    game = null;
                }
                hits.clear();
                return true;
            }
        });
    }

    @Override
    public void resize(int width, int height) {
        viewport.update(width, height, true);
        hits.clear();
    }

    @Override
    public void render() {
        if (game != null && !help && !restart) updateBots(Gdx.graphics.getDeltaTime());
        ScreenUtils.clear(INK);
        viewport.apply();
        art.batch.setProjectionMatrix(viewport.getCamera().combined);
        art.batch.begin();
        hits.clear();
        if (game == null) menu();
        else {
            header();
            switch (game) {
                case HEARTS -> trickTable(hearts);
                case KLAVER -> trickTable(klaver);
                case POKER -> pokerTable();
                case SOLITAIRE -> solitaireTable();
                case SWITCHYARD -> switchyardTable();
            }
            if (help || restart) modal();
        }
        art.batch.end();
    }

    private void open(Game choice) {
        game = choice;
        if (!started(choice)) reset();
        selected.clear();
        notice = "";
        timer = 0;
    }

    private boolean started(Game choice) {
        return switch (choice) {
            case POKER -> poker != null;
            case HEARTS -> hearts != null;
            case KLAVER -> klaver != null;
            case SOLITAIRE -> solitaire != null;
            case SWITCHYARD -> yard != null;
        };
    }

    private void reset() {
        selected.clear();
        source = null;
        ticket = null;
        notice = "";
        timer = 0;
        restart = false;
        raiseTarget = 0;
        switch (game) {
            case POKER -> poker = new Poker(random);
            case HEARTS -> hearts = new TrickGame(false, random);
            case KLAVER -> klaver = new TrickGame(true, random);
            case SOLITAIRE -> solitaire = new Solitaire(random);
            case SWITCHYARD -> yard = new Switchyard(random);
        }
    }

    private void updateBots(float elapsed) {
        TrickGame tricks = game == Game.HEARTS ? hearts : klaver;
        boolean waiting = switch (game) {
            case HEARTS, KLAVER -> tricks.phase == TrickGame.Phase.TRICK
                || (tricks.phase == TrickGame.Phase.TRUMP || tricks.phase == TrickGame.Phase.PLAY) && tricks.turn != 0;
            case POKER -> poker.phase == Poker.Phase.BET && poker.turn != 0;
            case SWITCHYARD -> yard.winner < 0 && yard.turn != 0;
            case SOLITAIRE -> false;
        };
        if (!waiting) {
            timer = 0;
            return;
        }
        timer += elapsed;
        float delay = (game == Game.HEARTS || game == Game.KLAVER)
            && tricks.phase == TrickGame.Phase.TRICK ? 1.15f : .44f;
        if (timer < delay) return;
        timer = 0;
        switch (game) {
            case HEARTS, KLAVER -> {
                switch (tricks.phase) {
                    case TRUMP -> tricks.botTrump();
                    case PLAY -> tricks.botPlay();
                    case TRICK -> tricks.collect();
                    default -> { }
                }
            }
            case POKER -> poker.bot();
            case SWITCHYARD -> yard.bot();
            case SOLITAIRE -> { }
        }
    }

    private void hit(float x, float y, float w, float h, Runnable action) {
        hits.add(new Hit(new Rectangle(x, y, w, h), action));
    }

    private void button(String label, float x, float y, float w, boolean accent, boolean enabled, Runnable click) {
        art.border(x, y, w, 42, enabled ? accent ? GOLD : LINE : FRAME, enabled && accent ? GOLD : PANEL);
        art.center(label, x + w / 2, y + 13, 19, enabled && accent ? INK : enabled ? PAPER : MUTED, false);
        if (enabled) hit(x, y, w, 42, click);
    }

    private void menu() {
        art.box(24, 24, 410, 672, FELT);
        art.suit(Card.CLUBS, 51, 64, 31, GOLD);
        art.text("OFFLINE CARD COLLECTION", 94, 72, 18, GOLD);
        art.title("Clover", 50, 122, 66, PAPER);
        art.title("Card Room", 49, 193, 63, PAPER);
        art.paragraph("Five tables for a quick hand or a full match.", 54, 272, 23, MUTED, 315);
        art.rect(54, 338, 326, 1, LINE);
        art.back(76, 381, 134, 212);
        art.face(136, 398, 134, 212, new Card(Card.HEARTS, 12), false, true);
        art.face(198, 419, 134, 212, new Card(Card.CLUBS, 14), false, true);
        art.text("Choose a table", 470, 33, 22, GOLD);
        int index = 0;
        for (Game choice : Game.values()) {
            float y = 70 + 125 * index++;
            art.border(456, y, 672, 110, LINE, FRAME);
            art.box(475, y + 19, 67, 72, PANEL);
            art.suit(choice.suit, 491, y + 38, 35, GOLD);
            art.title(choice.title, 560, y + 18, 31, PAPER);
            art.text(choice.description, 561, y + 64, 20, MUTED);
            button(started(choice) ? "Resume" : "Play", 995, y + 34, 110, true, true, () -> open(choice));
            hit(456, y, 672, 110, () -> open(choice));
        }
    }

    private void header() {
        art.border(24, 94, 1104, 602, LINE, FELT);
        button("< Tables", 24, 24, 110, false, true, () -> game = null);
        art.title(game.title, 155, 20, 39, PAPER);
        art.text(game.variant, 158, 65, 16, MUTED);
        button("Restart", 897, 24, 111, false, true, () -> restart = true);
        button("Rules", 1020, 24, 108, false, true, () -> help = true);
    }

    private void seat(float x, float y, float width, String name, String detail, boolean active) {
        art.border(x, y, width, 62, active ? GOLD : LINE, PANEL);
        art.text(name, x + 13, y + 9, 20, active ? GOLD : PAPER);
        art.text(detail, x + 13, y + 34, 17, MUTED);
    }

    private void status(String line, float y) {
        art.center(line, WIDTH / 2f, y, 23, PAPER, false);
    }

    private void toggle(Card card, int limit) {
        if (!selected.remove(card) && selected.size() < limit) selected.add(card);
    }

    private void hand(List<Card> cards, float y, float w, float h, float gap,
                      java.util.function.Predicate<Card> allowed, java.util.function.Consumer<Card> choose) {
        float center = WIDTH / 2f;
        float x = center - (cards.size() * (w + gap) - gap) / 2;
        for (Card card : cards) {
            boolean picked = selected.contains(card);
            boolean legal = allowed.test(card);
            float top = y - (picked ? 9 : 0);
            art.face(x, top, w, h, card, picked, legal || choose == null);
            if (legal && choose != null) hit(x, top, w, h, () -> choose.accept(card));
            x += w + gap;
        }
    }

    private void trickTable(TrickGame table) {
        boolean playing = table.phase == TrickGame.Phase.PLAY;
        int[] xs = {41, 41, 461, 893};
        int[] ys = {601, 248, 109, 248};
        for (int i = 1; i < 4; i++) {
            String name = TrickGame.SEATS[i] + (table.klaver && i == 2 ? "  /  Partner" : "");
            String score = table.klaver ? "Team " + table.score[i % 2] + "  /  " : table.score[i] + " points  /  ";
            seat(xs[i], ys[i], 218, name, score + table.hands.get(i).size() + " cards", playing && table.turn == i);
        }
        art.text("Deal " + table.deal + (table.klaver ? " of 16" : ""), 45, 116, 19, GOLD);
        art.text("Tricks " + table.tricks + (table.klaver ? " / 8" : " / 13"), 45, 145, 19, MUTED);
        if (table.klaver && table.trump >= 0) {
            art.suit(table.trump, 888, 114, 25, GOLD);
            art.text("Trump " + Card.SUITS[table.trump], 921, 116, 20, PAPER);
            art.text("Called by " + TrickGame.SEATS[table.caller], 921, 144, 17, MUTED);
        } else if (!table.klaver) {
            art.text(table.heartsBroken ? "Hearts broken" : "Hearts unbroken", 931, 116, 19, MUTED);
        }
        art.border(298, 183, 556, 278, LINE, FRAME);
        if (table.trick.isEmpty()) {
            art.suit(Card.CLUBS, 543, 251, 66, LINE);
        } else {
            float[] cardX = {542, 395, 542, 690};
            float[] cardY = {349, 273, 201, 273};
            int winner = table.phase == TrickGame.Phase.TRICK ? table.winner().seat() : -1;
            for (TrickGame.Play play : table.trick) {
                art.face(cardX[play.seat()], cardY[play.seat()], 69, 93, play.card(), play.seat() == winner, true);
            }
        }
        String prompt = switch (table.phase) {
            case PASS -> "Choose three cards to pass " + table.passDirection().toLowerCase(java.util.Locale.ROOT) + ".";
            case TRUMP -> table.turn == 0 ? "Choose the trump suit." : TrickGame.SEATS[table.turn] + " is choosing trump.";
            case PLAY -> table.turn == 0 ? "Choose a highlighted card." : TrickGame.SEATS[table.turn] + " to play";
            case TRICK -> TrickGame.SEATS[table.winner().seat()] + (table.winner().seat() == 0 ? " take" : " takes") + " the trick.";
            case ROUND, OVER -> table.result;
        };
        status(prompt, 474);

        if (table.phase == TrickGame.Phase.PASS) {
            button("Pass " + selected.size() + " / 3", 496, 506, 160, true, selected.size() == 3, () -> {
                table.pass(selected);
                selected.clear();
            });
            hand(table.hands.get(0), 566, 70, 96, 5, card -> true, card -> toggle(card, 3));
        } else {
            if (table.phase == TrickGame.Phase.TRUMP && table.turn == 0) {
                for (int i = 0; i < 4; i++) {
                    int suit = i;
                    button(Card.SUITS[i], 306 + i * 137, 506, 128, true, true, () -> table.chooseTrump(suit));
                }
            }
            if (table.phase == TrickGame.Phase.ROUND) {
                button("Next deal", 491, 506, 170, true, true, table::nextDeal);
            } else if (table.phase == TrickGame.Phase.OVER) {
                button("New match", 491, 506, 170, true, true, this::reset);
            }
            List<Card> legal = table.turn == 0 && playing ? table.legal() : java.util.Collections.emptyList();
            hand(table.hands.get(0), 566, 70, 96, 5, legal::contains, legal.isEmpty() ? null : table::play);
        }
        art.text("YOU  /  " + table.score[0] + (table.klaver ? " team points" : " points"),
            44, 670, 17, GOLD);
        if (table.klaver) {
            art.text("This deal  " + table.roundPoints[0] + " + " + table.meld[0] + " roem  /  "
                + table.roundPoints[1] + " + " + table.meld[1] + " roem", 737, 670, 17, MUTED);
        } else {
            art.text("This deal  " + table.roundPoints[0] + " penalty points", 898, 670, 17, MUTED);
        }
    }

    private void pokerTable() {
        boolean show = poker.phase == Poker.Phase.SHOWDOWN;
        boolean bet = poker.phase == Poker.Phase.BET;
        art.text("Hand " + poker.deal + " / " + Poker.MATCH_HANDS, 44, 117, 19, GOLD);
        art.text("Blinds " + Poker.SMALL_BLIND + " / " + Poker.BIG_BLIND, 44, 146, 17, MUTED);
        for (int seat = 1; seat < 4; seat++) {
            float left = 239 + (seat - 1) * 263;
            String name = TrickGame.SEATS[seat] + (seat == poker.dealer ? " (D)" : "");
            seat(left, 109, 213, name + "  /  " + poker.chips[seat] + " chips", poker.action[seat],
                bet && poker.turn == seat);
            List<Card> cards = poker.hands.get(seat);
            boolean visible = poker.reveal && poker.playing[seat];
            for (int i = 0; i < cards.size(); i++) {
                float x = left + 61 + i * 48;
                if (visible) art.face(x, 180, 41, 58, cards.get(i), false, true);
                else if (poker.playing[seat] && bet) art.back(x, 180, 41, 58);
            }
            if (visible) {
                art.center(poker.handName(seat), left + 106, 243, 17, MUTED, false);
            }
        }
        art.center("COMMUNITY CARDS", 576, 273, 17, MUTED, false);
        for (int i = 0; i < 5; i++) {
            float x = 375 + i * 82;
            if (i < poker.board.size()) art.face(x, 299, 74, 90, poker.board.get(i), false, true);
            else art.border(x, 299, 74, 90, LINE, FRAME);
        }
        art.border(820, 321, 177, 47, LINE, FRAME);
        art.center((bet ? "Pot " : "Awarded ") + poker.pot, 908, 333, 23, GOLD, true);
        String line = !bet ? poker.result : poker.street.label + "  /  "
            + (poker.turn == 0 ? "Your turn" : TrickGame.SEATS[poker.turn] + " to act");
        status(line, 412);
        if (bet && poker.turn == 0) {
            int due = poker.due();
            button("Fold", 313, 448, 142, false, true, () -> {
                raiseTarget = 0;
                poker.fold();
            });
            button(due == 0 ? "Check" : "Call " + due, 465, 448, 142, true, true, () -> {
                raiseTarget = 0;
                poker.call();
            });
            pokerRaiseControls(due);
        } else if (show) {
            button("Continue", 495, 448, 162, true, true, poker::nextDeal);
        } else if (poker.phase == Poker.Phase.OVER) {
            button("New match", 495, 448, 162, true, true, this::reset);
        }
        List<Card> cards = poker.hands.get(0);
        hand(cards, 560, 78, 100, 10, card -> true, null);
        art.text((poker.dealer == 0 ? "YOU (D)" : "YOU") + "  /  " + poker.chips[0] + " chips", 44, 668, 17, GOLD);
        if (poker.board.size() >= 3 && !cards.isEmpty()) {
            art.center(poker.handName(0), 576, 668, 17, MUTED, false);
        }
    }

    private void pokerRaiseControls(int due) {
        boolean allowed = poker.canRaise();
        String label = poker.bet == 0 ? "Bet" : "Raise";
        int minimum = poker.minRaiseTo();
        int maximum = poker.allInTo();
        int target = Math.max(minimum, Math.min(raiseTarget, maximum));
        String wager = target == maximum ? "All-in " + target : label + (poker.bet == 0 ? " " : " to ") + target;
        button(allowed ? wager : label, 617, 448, 222, false, allowed, () -> {
            raiseTarget = 0;
            poker.raiseTo(target);
        });
        if (!allowed || minimum == maximum) return;
        button("Min", 313, 501, 88, false, target != minimum, () -> raiseTarget = minimum);
        button("-5", 411, 501, 65, false, target > minimum, () -> raiseTarget = target - 5);
        button("-1", 486, 501, 65, false, target > minimum, () -> raiseTarget = target - 1);
        button("+1", 561, 501, 65, false, target < maximum, () -> raiseTarget = target + 1);
        button("+5", 636, 501, 65, false, target < maximum, () -> raiseTarget = target + 5);
        button("Pot", 711, 501, 67, false, true, () -> raiseTarget = poker.bet + poker.pot + due);
        button("Max", 788, 501, 51, false, target != maximum, () -> raiseTarget = maximum);
    }

    private void solitaireTable() {
        float x = 62, y = 126, w = 101, h = 122;
        List<Card> waste = solitaire.piles.get(Solitaire.WASTE);
        if (solitaire.stock.isEmpty()) {
            art.border(x, y, w, h, LINE, FRAME);
            art.center(waste.isEmpty() ? "Empty" : "Recycle", x + w / 2, y + 52, 20, MUTED, false);
        } else art.back(x, y, w, h);
        hit(x, y, w, h, () -> {
            if (solitaire.draw()) notice = "";
            source = null;
        });
        art.center("Stock  /  " + solitaire.stock.size(), x + w / 2, 261, 17, MUTED, false);
        solitaireTop(Solitaire.WASTE, x + 129, y, w, h);
        art.center("Waste", x + 129 + w / 2, 261, 17, MUTED, false);

        for (int suit = 0; suit < 4; suit++) {
            solitaireTop(Solitaire.FIRST_FOUNDATION + suit, 612 + suit * 129, y, w, h);
        }
        art.center("FOUNDATIONS  /  " + solitaire.built() + " of 52", 855, 261, 17, MUTED, false);
        art.rect(45, 289, 1062, 1, LINE);

        for (int pile = 0; pile < 7; pile++) {
            int target = pile;
            List<Card> stack = solitaire.piles.get(pile);
            float left = 62 + pile * 154;
            float top = 307;
            boolean destination = source != null && solitaire.canMove(source, pile);
            art.border(left, top, w, h, destination ? GOLD : LINE, FRAME);
            if (stack.isEmpty()) {
                art.center("King", left + w / 2, top + 52, 20, MUTED, false);
                hit(left, top, w, h, () -> solitaireClick(target, -1));
            }
            int covered = solitaire.hidden[pile];
            float step = Math.min(32, (223f - covered * 10) / Math.max(1, stack.size() - covered - 1));
            for (int index = 0; index < stack.size(); index++) {
                int cardIndex = index;
                boolean hidden = index < solitaire.hidden[pile];
                boolean picked = source != null && source.pile() == pile && index >= source.index();
                if (hidden) art.back(left, top, w, h);
                else if (index == stack.size() - 1) art.face(left, top, w, h, stack.get(index), picked, true);
                else art.overlappedFace(left, top, w, h, stack.get(index), picked, step);
                if (!hidden || destination) hit(left, top, w, h, () -> solitaireClick(target, cardIndex));
                if (index < stack.size() - 1) top += hidden ? 10 : step;
            }
            if (destination && !stack.isEmpty()) art.rect(left, top + h - 4, w, 3, GOLD);
        }
        art.text(solitaire.moves + (solitaire.moves == 1 ? " move" : " moves"), 45, 670, 17, GOLD);
        art.center(solitaire.built() == 52 ? "All four foundations complete. You win!"
            : !notice.isEmpty() ? notice : source == null ? "Tap a face-up card to select it."
            : "Tap a destination, or tap the selected card to clear.", 576, 670, 18, PAPER, false);
        button("Undo", 985, 646, 111, false, !solitaire.history.isEmpty(), () -> {
            solitaire.undo();
            source = null;
            notice = "";
        });
    }

    private void solitaireTop(int pile, float x, float y, float w, float h) {
        List<Card> stack = solitaire.piles.get(pile);
        boolean destination = source != null && solitaire.canMove(source, pile);
        if (stack.isEmpty()) {
            art.border(x, y, w, h, destination ? GOLD : LINE, FRAME);
            if (pile >= Solitaire.FIRST_FOUNDATION) {
                art.suit(pile - Solitaire.FIRST_FOUNDATION, x + (w - 39) / 2, y + (h - 39) / 2, 39,
                    destination ? GOLD : LINE);
            }
        } else {
            art.face(x, y, w, h, stack.get(stack.size() - 1), source != null && source.pile() == pile, true);
            if (destination) art.rect(x, y + h - 4, w, 3, GOLD);
        }
        hit(x, y, w, h, () -> solitaireClick(pile, stack.size() - 1));
    }

    private void solitaireClick(int pile, int index) {
        notice = "";
        Solitaire.Source clicked = new Solitaire.Source(pile, index);
        if (source != null && (source.equals(clicked) || solitaire.move(source, pile))) {
            source = null;
        } else if (solitaire.canPick(clicked) && (source == null || source.pile() == pile)) {
            source = clicked;
        } else if (source != null) {
            notice = "That card cannot go there.";
        }
    }

    private void switchyardTable() {
        boolean yours = yard.turn == 0 && yard.winner < 0;
        for (int seat = 1; seat < 3; seat++) {
            float x = seat == 1 ? 55 : 882;
            seat(x, 121, 215, Switchyard.SEATS[seat],
                yard.stocks.get(seat).size() + " in stock", yard.turn == seat && yard.winner < 0);
            art.ticket(x + 70, 196, 75, 89, yard.top(seat) > 0 ? "" + yard.top(seat) : "-", true, false);
        }
        art.text("SHARED ROUTES", 505, 117, 19, GOLD);
        for (int route = 0; route < 2; route++) {
            int destination = route;
            float x = 349 + route * 238;
            boolean legal = yours && ticket != null && yard.canRoute(ticket, route);
            int current = yard.currentNumber(route);
            art.border(x, 154, 215, 202, legal ? GOLD : LINE, FRAME);
            art.center(route == 0 ? "Up line  1 to 10" : "Down line  10 to 1", x + 107, 174, 21, PAPER, false);
            art.ticket(x + 63, 210, 89, 105, current == 0 ? "-" : Integer.toString(current), current != 0, false);
            art.center(legal ? "Dispatch here" : current == 0 ? "Empty route" : "Last card played",
                x + 107, 330, 15, MUTED, false);
            if (legal) hit(x, 154, 215, 202, () -> {
                yard.route(ticket, destination);
                ticket = null;
            });
        }
        String prompt = yard.winner >= 0 ? Switchyard.SEATS[yard.winner]
            + (yard.winner == 0 ? " cleared your stock. You win!" : " cleared their stock and wins.")
            : yours ? yard.signal ? "Signal open. Your stock card can take either route."
            : "Your turn  /  " + yard.actions + " of 3 moves left" : Switchyard.SEATS[yard.turn] + " is dispatching.";
        status(prompt, 384);
        art.center(yard.event, 576, 415, 18, MUTED, false);

        List<Integer> hand = yard.hands.get(0);
        art.center("YOUR STOCK  /  " + yard.stocks.get(0).size(), 209, 462, 18, GOLD, false);
        art.ticket(160, 493, 98, 120, yard.top(0) > 0 ? "" + yard.top(0) : "-", true,
            ticket != null && ticket == Switchyard.STOCK);
        if (yours && yard.actions > 0) hit(160, 493, 98, 120, () -> selectTicket(Switchyard.STOCK));
        art.center("YOUR HAND", 575, 462, 18, GOLD, false);
        for (int i = 0; i < hand.size(); i++) {
            int slot = i;
            float x = 365 + i * 110;
            art.ticket(x, 493, 98, 120, "" + hand.get(i), true, ticket != null && ticket == i);
            if (yours) hit(x, 493, 98, 120, () -> selectTicket(slot));
        }
        if (yard.winner >= 0) {
            button("New match", 887, 513, 183, true, true, this::reset);
        } else {
            button("End turn", 887, 506, 183, true, yours, () -> leaveYard(-1));
            button("Exchange & end", 887, 557, 183, false, yours && ticket != null && ticket >= 0,
                () -> leaveYard(ticket));
        }
        art.center("Select a stock or hand card, then tap a highlighted route.", 576, 664, 18, MUTED, false);
    }

    private void selectTicket(int slot) {
        ticket = ticket != null && ticket == slot ? null : slot;
    }

    private void leaveYard(int exchange) {
        yard.endTurn(exchange);
        ticket = null;
    }

    private void modal() {
        hits.clear();
        art.rect(0, 0, WIDTH, HEIGHT, new com.badlogic.gdx.graphics.Color(0, 0, 0, .65f));
        int top = restart ? 211 : 105;
        int height = restart ? 296 : 510;
        art.border(231, top, 690, height, GOLD, FRAME);
        art.title(restart ? "Restart the table?" : game.title + " rules", 267, top + 30, 38, PAPER);
        if (restart) {
            art.paragraph("The current match at this table will be replaced by a fresh deal.", 269, top + 109, 24, MUTED, 613);
            button("Keep playing", 536, top + 213, 165, false, true, () -> restart = false);
            button("Restart", 714, top + 213, 167, true, true, this::reset);
        } else {
            String[] rules = rules();
            for (int i = 0; i < rules.length; i++) {
                art.paragraph(rules[i], 271, top + 100 + i * 81, 22, MUTED, 607);
            }
            button("Back to game", 710, top + 429, 170, true, true, () -> help = false);
        }
    }

    private String[] rules() {
        return switch (game) {
            case POKER -> new String[]{
                "You start with 100 chips and two private cards each hand. The dealer rotates, and the small and big blinds are 2 and 5.",
                "Bet preflop, then on the flop (three shared cards), turn (one more) and river (the fifth). You can wager up to your stack.",
                "At showdown, make the best five-card hand using any cards from your two private cards and the shared board. Ties split the pot.",
                "All-in players can win only chips they matched. The chip leader wins after 12 hands, when you bust, or when one player remains."
            };
            case HEARTS -> new String[]{
                "Pass three cards left, across, then right on successive deals. Keep your cards on the fourth deal and repeat.",
                "Lead with the two of clubs. Follow suit if able. Avoid penalty cards on the first trick when you have another legal play.",
                "Hearts can lead once a heart has been discarded or when you hold only hearts. Highest card of the led suit takes the trick.",
                "Hearts cost 1 each and the queen of spades costs 13. Take all 26 to give 26 to each opponent. At 100, lowest total wins."
            };
            case KLAVER -> new String[]{
                "Play 16 deals with North as your partner. The caller rotates and must choose trump. The caller leads the first trick.",
                "Follow suit. Overtrump when trump is led if possible. If void and an opponent leads the trick, trump or overtrump if able.",
                "Trump jack and nine score 20 and 14. Aces score 11 and tens 10. The last trick is worth 10. Roem adds bonuses.",
                "The calling team must outscore its opponents including roem, or go nat and give up all points. A sweep adds 100."
            };
            case SOLITAIRE -> new String[]{
                "Build four foundations from ace to king, one per suit. The top foundation card can return to the tableau.",
                "Build the tableau downward in alternating colors. An empty column accepts a king or a run beginning with a king.",
                "Tap a face-up card or run and then tap its destination. Tap the stock to reveal one card and recycle when it runs out.",
                "Undo reverses a move or draw. Complete all four foundations to win."
            };
            case SWITCHYARD -> new String[]{
                "Clear your eight-card stock first. The two shared routes run 1 to 10 and 10 to 1, then loop.",
                "Each route shows its last card. Play up to three cards from your hand or stock top, using the next number in sequence.",
                "Refill to four at the start of a turn. You may select a hand card and exchange it when ending your turn.",
                "After three turns with zero stock cards played, the next player can dispatch their stock card on either route once."
            };
        };
    }

    @Override
    public void dispose() {
        art.dispose();
    }
}
