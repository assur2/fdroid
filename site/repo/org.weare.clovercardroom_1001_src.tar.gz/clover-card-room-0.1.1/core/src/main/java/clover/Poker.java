package clover;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

final class Poker {
    enum Phase { BET, SHOWDOWN, OVER }
    enum Street {
        PREFLOP("Preflop"), FLOP("Flop"), TURN("Turn"), RIVER("River");

        final String label;

        Street(String label) {
            this.label = label;
        }
    }

    static final int SMALL_BLIND = 2, BIG_BLIND = 5, MATCH_HANDS = 12;
    static final String[] RANKS = {"High card", "One pair", "Two pair", "Three of a kind",
        "Straight", "Flush", "Full house", "Four of a kind", "Straight flush"};

    final List<List<Card>> hands = new ArrayList<>();
    final List<Card> deck = new ArrayList<>();
    final List<Card> board = new ArrayList<>(5);
    final List<Card> burns = new ArrayList<>(3);
    final int[] chips = {100, 100, 100, 100};
    final int[] paid = new int[4];
    final int[] committed = new int[4];
    final String[] action = new String[4];
    final boolean[] playing = new boolean[4];
    private final int[] actedAt = new int[4];
    private final long[] handRanks = new long[4];
    final Random random;
    int deal, turn, pot, bet, dealer, smallBlind, bigBlind;
    private int raiseSize;
    Street street;
    boolean reveal;
    Phase phase;
    String result;

    Poker(Random random) {
        this.random = random;
        for (int i = 0; i < 4; i++) hands.add(new ArrayList<>());
        nextDeal();
    }

    void nextDeal() {
        int eligible = 0;
        for (int chip : chips) if (chip > 0) eligible++;
        if (eligible < 2 || chips[0] == 0 || deal == MATCH_HANDS) {
            phase = Phase.OVER;
            int high = Arrays.stream(chips).max().orElse(0);
            List<String> leaders = new ArrayList<>();
            for (int seat = 0; seat < 4; seat++) {
                if (chips[seat] == high) leaders.add(TrickGame.SEATS[seat]);
            }
            String finish = leaders.size() > 1 ? " tie" : leaders.get(0).equals("You") ? " win" : " wins";
            result = leaders.stream().collect(Collectors.joining(" / ")) + finish + " with " + high + " chips.";
            return;
        }

        deal++;
        street = Street.PREFLOP;
        pot = 0;
        reveal = false;
        result = "";
        deck.clear();
        deck.addAll(Card.deck(2, random));
        board.clear();
        burns.clear();
        Arrays.fill(committed, 0);
        Arrays.fill(handRanks, -1);
        for (int seat = 0; seat < 4; seat++) {
            hands.get(seat).clear();
            playing[seat] = chips[seat] > 0;
            action[seat] = playing[seat] ? "Waiting" : "Sitting out";
        }
        int previousBigBlind = bigBlind;
        dealer = nextSeat(dealer);
        smallBlind = eligible == 2 ? dealer : nextSeat(dealer);
        bigBlind = nextSeat(smallBlind);
        if (eligible == 2 && deal > 1 && bigBlind == previousBigBlind) {
            dealer = bigBlind;
            smallBlind = dealer;
            bigBlind = nextSeat(dealer);
        }
        for (int card = 0; card < 2; card++) {
            for (int seat = smallBlind, dealt = 0; dealt < eligible; seat = nextSeat(seat), dealt++) {
                hands.get(seat).add(Card.pop(deck));
            }
        }
        for (List<Card> hand : hands) hand.sort(Card.ORDER);
        resetBetting();
        postBlind(smallBlind, SMALL_BLIND);
        postBlind(bigBlind, BIG_BLIND);
        bet = BIG_BLIND;
        phase = Phase.BET;
        advanceFrom(bigBlind);
    }

    private void resetBetting() {
        Arrays.fill(paid, 0);
        Arrays.fill(actedAt, -1);
        bet = 0;
        raiseSize = BIG_BLIND;
    }

    private void postBlind(int seat, int blind) {
        int amount = Math.min(blind, chips[seat]);
        pay(seat, amount);
        action[seat] = (blind == SMALL_BLIND ? "Small blind " : "Big blind ") + amount
            + (chips[seat] == 0 ? " (all-in)" : "");
    }

    private void pay(int seat, int amount) {
        chips[seat] -= amount;
        paid[seat] += amount;
        committed[seat] += amount;
        pot += amount;
    }

    private int amountToCall(int seat, boolean anotherCanBet) {
        int target = bet;
        if (!anotherCanBet) {
            target = 0;
            for (int other = 0; other < 4; other++) {
                if (other != seat && playing[other]) target = Math.max(target, paid[other]);
            }
        }
        return Math.min(chips[seat], Math.max(0, target - paid[seat]));
    }

    private int seatsWithChips() {
        int count = 0;
        for (int seat = 0; seat < 4; seat++) if (playing[seat] && chips[seat] > 0) count++;
        return count;
    }

    int due() {
        return amountToCall(turn, seatsWithChips() > 1);
    }

    int allInTo() {
        return paid[turn] + chips[turn];
    }

    int minRaiseTo() {
        return Math.min(allInTo(), bet == 0 ? BIG_BLIND : bet + raiseSize);
    }

    boolean canRaise() {
        return phase == Phase.BET && seatsWithChips() > 1 && allInTo() > bet
            && (actedAt[turn] < 0 || bet - actedAt[turn] >= raiseSize);
    }

    void call() {
        if (phase != Phase.BET) return;
        int amount = due();
        pay(turn, amount);
        action[turn] = chips[turn] == 0 ? "All-in for " + paid[turn] : amount > 0 ? "Called " + amount : "Checked";
        actedAt[turn] = bet;
        advanceFrom(turn);
    }

    void raiseTo(int target) {
        if (!canRaise() || target < minRaiseTo() || target > allInTo()) return;
        int previous = bet;
        pay(turn, target - paid[turn]);
        bet = target;
        raiseSize = Math.max(raiseSize, target - previous);
        actedAt[turn] = bet;
        action[turn] = (chips[turn] == 0 ? "All-in for " : previous == 0 ? "Bet " : "Raised to ") + target;
        advanceFrom(turn);
    }

    void fold() {
        if (phase != Phase.BET) return;
        playing[turn] = false;
        action[turn] = "Folded";
        advanceFrom(turn);
    }

    private void advanceFrom(int after) {
        int remaining = 0;
        for (boolean inHand : playing) if (inHand) remaining++;
        if (remaining == 1) {
            award(false);
            return;
        }

        boolean canBet = seatsWithChips() > 1;
        while (true) {
            for (int offset = 1; offset <= 4; offset++) {
                int seat = (after + offset) % 4;
                if (playing[seat] && chips[seat] > 0
                    && (amountToCall(seat, canBet) > 0 || canBet && actedAt[seat] < 0)) {
                    turn = seat;
                    return;
                }
            }
            if (street == Street.RIVER) {
                award(true);
                return;
            }
            dealStreet();
            after = dealer;
        }
    }

    private void dealStreet() {
        street = switch (street) {
            case PREFLOP -> Street.FLOP;
            case FLOP -> Street.TURN;
            case TURN -> Street.RIVER;
            case RIVER -> throw new IllegalStateException("The board is already complete");
        };
        burns.add(Card.pop(deck));
        int cards = street == Street.FLOP ? 3 : 1;
        for (int i = 0; i < cards; i++) board.add(Card.pop(deck));
        resetBetting();
        for (int seat = 0; seat < 4; seat++) {
            if (!hands.get(seat).isEmpty()) handRanks[seat] = bestRank(board, hands.get(seat));
            if (playing[seat]) action[seat] = chips[seat] > 0 ? "Waiting" : "All-in";
        }
    }

    private int nextSeat(int seat) {
        do {
            seat = (seat + 1) % 4;
        } while (!playing[seat]);
        return seat;
    }

    private void award(boolean showdown) {
        reveal = showdown;
        long[] values = new long[4];
        for (int seat = 0; seat < 4; seat++) {
            values[seat] = playing[seat] ? showdown ? handRanks[seat] : 0 : -1;
        }
        // A contribution level defines a pot that only players who covered it can win.
        int[] levels = committed.clone();
        Arrays.sort(levels);
        int[] won = new int[4];
        int previous = 0;
        int awarded = 0;
        for (int level : levels) {
            if (level == previous) continue;
            int contributors = 0;
            int lastContributor = -1;
            long best = -1;
            List<Integer> winners = new ArrayList<>();
            for (int offset = 1; offset <= 4; offset++) {
                int seat = (dealer + offset) % 4;
                if (committed[seat] < level) continue;
                contributors++;
                lastContributor = seat;
                long value = values[seat];
                if (value < 0 || value < best) continue;
                if (value > best) winners.clear();
                best = value;
                winners.add(seat);
            }
            int amount = (level - previous) * contributors;
            previous = level;
            if (contributors == 1) {
                chips[lastContributor] += amount;
                continue;
            }
            for (int i = 0; i < winners.size(); i++) {
                won[winners.get(i)] += amount / winners.size() + (i < amount % winners.size() ? 1 : 0);
            }
            awarded += amount;
        }
        // With only short, unmatched forced bets, the winner may take an empty contested pot.
        pot = awarded;
        List<Integer> winners = new ArrayList<>();
        for (int seat = 0; seat < 4; seat++) {
            chips[seat] += won[seat];
            if (won[seat] > 0) winners.add(seat);
        }
        if (winners.isEmpty()) {
            result = "Uncalled chips returned";
        } else if (winners.size() == 1) {
            int seat = winners.get(0);
            result = TrickGame.SEATS[seat] + (seat == 0 ? " win " : " wins ") + won[seat]
                + (showdown ? " with " + handName(seat).toLowerCase(java.util.Locale.ROOT) : " chips");
        } else {
            result = winners.stream().map(seat -> TrickGame.SEATS[seat] + " +" + won[seat])
                .collect(Collectors.joining("  /  "));
        }
        phase = Phase.SHOWDOWN;
    }

    void bot() {
        List<Card> hand = hands.get(turn);
        int strength;
        if (street == Street.PREFLOP) {
            Card first = hand.get(0), second = hand.get(1);
            strength = first.rank() == second.rank() ? (first.rank() >= 10 ? 3 : 2)
                : Math.max(first.rank(), second.rank()) >= 12 && Math.min(first.rank(), second.rank()) >= 9 ? 1 : 0;
        } else {
            long value = handRanks[turn];
            strength = (int) (value >>> 20);
            if (board.size() == 5 && value == rank(board)) strength = 1;
        }
        int due = due();
        if (canRaise() && random.nextInt(100) < (strength >= 3 ? 53 : strength == 2 ? 24 : 6)) {
            raiseTo(Math.min(allInTo(), Math.max(minRaiseTo(), bet + (pot + due) / 2)));
        } else if (due > 0 && strength < 2
            && random.nextInt(100) < (strength == 0 ? 32 : 10) + (due * 2 > pot ? 36 : 0)) {
            fold();
        } else {
            call();
        }
    }

    String handName(int seat) {
        return RANKS[(int) (handRanks[seat] >>> 20)];
    }

    static long bestRank(List<Card> board, List<Card> hole) {
        List<Card> cards = new ArrayList<>(board);
        cards.addAll(hole);
        if (cards.size() == 5) return rank(cards);
        List<Card> five = new ArrayList<>(5);
        long best = -1;
        for (int mask = 0; mask < (1 << cards.size()); mask++) {
            if (Integer.bitCount(mask) != 5) continue;
            five.clear();
            for (int i = 0; i < cards.size(); i++) {
                if ((mask & (1 << i)) != 0) five.add(cards.get(i));
            }
            best = Math.max(best, rank(five));
        }
        return best;
    }

    static long rank(List<Card> hand) {
        int[] counts = new int[15];
        boolean flush = true;
        for (Card card : hand) {
            counts[card.rank()]++;
            flush &= card.suit() == hand.get(0).suit();
        }
        int straight = 0;
        for (int top = 14; top >= 6; top--) {
            if (counts[top] * counts[top - 1] * counts[top - 2] * counts[top - 3] * counts[top - 4] == 1) {
                straight = top;
                break;
            }
        }
        if (counts[14] * counts[5] * counts[4] * counts[3] * counts[2] == 1) straight = 5;

        int[] ranks = new int[5];
        int index = 0;
        int four = 0, three = 0, pairs = 0;
        for (int number = 4; number >= 1; number--) {
            for (int value = 14; value >= 2; value--) {
                if (counts[value] != number) continue;
                if (number == 4) four++;
                if (number == 3) three++;
                if (number == 2) pairs++;
                ranks[index++] = value;
            }
        }
        int category = 0;
        if (flush && straight > 0) category = 8;
        else if (four > 0) category = 7;
        else if (three > 0 && pairs > 0) category = 6;
        else if (flush) category = 5;
        else if (straight > 0) category = 4;
        else if (three > 0) category = 3;
        else if (pairs > 0) category = pairs;
        if (category == 4 || category == 8) return ((long) category << 20) | ((long) straight << 16);
        long value = category;
        for (int rank : ranks) value = (value << 4) | rank;
        return value;
    }
}
