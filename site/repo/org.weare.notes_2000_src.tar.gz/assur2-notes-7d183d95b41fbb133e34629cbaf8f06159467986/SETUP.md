# Notes releases

Notes is a Kotlin Compose Multiplatform app for Android and Windows x64, licensed under GPL-3.0-only.
The Notes app repository is private. The public catalog repository
[assur2/fdroid](https://github.com/assur2/fdroid) hosts the signed F-Droid feed
and the corresponding source archive from the Git tag of every distributed version.

## Run Notes

- **Windows x64:** Download `Notes-Windows-x64.zip` from the app's [GitHub Releases](https://github.com/assur2/notes/releases), extract the entire folder, and run `Notes.exe`. The ZIP includes Java. The Save button writes to `%LOCALAPPDATA%\Weare\Notes\note.txt`.
- **Android:** Install or update `org.weare.notes` through the [Weare Apps F-Droid repository](https://assur2.github.io/fdroid/repo/). The editor uses the existing app-private `filesDir/note.txt`. Each device keeps its own note.

## Build from source

Use JDK 17 and Gradle 8.11.1. Set `ANDROID_HOME` to an Android SDK with platform 35 and build-tools 35.0.0. From the repository root:

- `gradle :app:run` starts Notes on Windows.
- `gradle :app:createDistributable` creates a Windows application image under `app/build/compose/binaries/main/app/Notes/` when run on Windows.
- `gradle :app:assembleDebug` builds the Android debug APK. Use the signed release from F-Droid for in-place updates to an installed release.

## CI
Run unit tests and lint from Actions > Test Notes > Run workflow. Select the emulator
option to include the Android editor test. Tests run only on manual request.

## Signing and hosting
The Notes repository holds two tag-restricted GitHub Actions environments.
`android-release` contains the APK keystore and password. `catalog-signing` contains
the separate catalog keystore and password and the SSH deploy key for fdroid.
The catalog action is fetched from the public fdroid repository by commit SHA.
The Notes workflow reads its own release assets with a job-scoped token. The feed
publisher can push to the public feed repository using its dedicated deploy key.
The public Pages workflow publishes only the site directory.

The Notes repository variables are APP_ID, APK_SHA256, CATALOG_SHA256, FEED_REPO and FEED_URL.
The two signing certificates are long-lived. Keep the original private signing keys
and recoverable passwords backed up outside Git. Replacing either changes identity.

## Release
Tag a reviewed main commit with vMAJOR.MINOR.PATCH (each component 0..999, increasing).
The tagged workflow checks access to the shared publisher, then builds the Android APK and portable Windows app.
The Android signing job checks the signing certificate and creates a GitHub Release containing `Notes.apk` and `Notes-Windows-x64.zip`.

The release then dispatches the approved catalog workflow. It obtains the Notes APK and corresponding tagged source, verifies the Android identity and signature, and publishes updates alongside the other apps. The scheduled **Check for new app releases** workflow can also reconcile the feed. See the [shared publisher instructions](https://github.com/assur2/fdroid/blob/main/SETUP.md) for the catalog and Pages checks.
