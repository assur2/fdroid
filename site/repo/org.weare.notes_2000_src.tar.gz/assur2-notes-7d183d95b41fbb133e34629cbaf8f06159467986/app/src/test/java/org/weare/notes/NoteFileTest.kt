// SPDX-License-Identifier: GPL-3.0-only
package org.weare.notes

import org.junit.Assert.assertEquals
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class NoteFileTest {
    @get:Rule val folder = TemporaryFolder()
    @Test fun overwritesAndReopensUtf8() {
        val path = folder.root.resolve("note.txt")
        val file = NoteFile(path)
        assertEquals("", file.read())
        file.save("long first note\nsecond line")
        file.save("café")
        assertEquals("café", NoteFile(path).read())
        file.save("")
        assertEquals("", NoteFile(path).read())
    }
}
