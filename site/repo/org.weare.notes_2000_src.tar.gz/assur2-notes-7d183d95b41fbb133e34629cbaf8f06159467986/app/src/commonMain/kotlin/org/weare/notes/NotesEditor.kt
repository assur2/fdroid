// SPDX-License-Identifier: GPL-3.0-only
package org.weare.notes

import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private val wordPattern = Regex("\\S+")

@Composable
internal fun NotesEditor(
    initial: String?,
    onSave: (String) -> Boolean,
    modifier: Modifier = Modifier
) {
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            if (initial == null) {
                Text("Could not open note.txt", modifier.padding(16.dp))
            } else {
                var draft by rememberSaveable { mutableStateOf(initial) }
                var savedText by remember { mutableStateOf(initial) }
                var status by remember { mutableStateOf("") }
                Column(modifier.fillMaxSize().padding(16.dp)) {
                    Text("Notes", style = MaterialTheme.typography.h5)
                    OutlinedTextField(
                        value = draft,
                        onValueChange = {
                            draft = it
                            status = ""
                        },
                        label = { Text("Note") },
                        modifier = Modifier.fillMaxWidth().weight(1f)
                    )
                    val words = remember(draft) { wordPattern.findAll(draft).count() }
                    Text(if (words == 1) "1 word" else "$words words",
                        style = MaterialTheme.typography.caption)
                    Button(onClick = {
                        if (onSave(draft)) {
                            savedText = draft
                            status = "Saved"
                        } else {
                            status = "Save failed"
                        }
                    }) { Text("Save") }
                    if (status.isNotEmpty()) Text(status)
                    else if (draft != savedText) Text("Unsaved changes")
                }
            }
        }
    }
}
