// SPDX-License-Identifier: GPL-3.0-only
package org.weare.notes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val file = NoteFile(filesDir.resolve("note.txt"))
        val initial = file.readForEditor()
        setContent {
            NotesEditor(initial, file::saveFromEditor, Modifier.systemBarsPadding().imePadding())
        }
    }
}
