// SPDX-License-Identifier: GPL-3.0-only
package org.weare.notes

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EditorTest {
    @get:Rule val ui = createAndroidComposeRule<MainActivity>()
    @Test fun keyboardShrinksEditorAndLeavesFooterAboveIt() {
        val editor = ui.onNode(hasSetTextAction())
        val initialHeight = editor.fetchSemanticsNode().boundsInWindow.height
        editor.performClick()
        editor.performTextReplacement("Keyboard check")

        fun keyboardTop(): Int? = ui.runOnIdle {
            val decor = ui.activity.window.decorView
            val insets = ViewCompat.getRootWindowInsets(decor)
            val ime = WindowInsetsCompat.Type.ime()
            if (insets != null && insets.isVisible(ime) && insets.getInsets(ime).bottom > 0)
                decor.height - insets.getInsets(ime).bottom else null
        }

        val save = ui.onNodeWithText("Save")
        val count = ui.onNodeWithText("2 words")
        ui.waitUntil(timeoutMillis = 10000) {
            val top = keyboardTop() ?: return@waitUntil false
            editor.fetchSemanticsNode().boundsInWindow.height < initialHeight &&
                save.fetchSemanticsNode().boundsInWindow.bottom <= top &&
                count.fetchSemanticsNode().boundsInWindow.bottom <= top
        }
        save.performClick()
        ui.onNodeWithText("Saved").assertIsDisplayed()
    }

    @Test fun saveWritesTextFileAndEditorReopensIt() {
        val text = "Remember the library"
        ui.onNode(hasSetTextAction()).performTextReplacement(text)
        ui.onNodeWithText("Unsaved changes").assertIsDisplayed()
        ui.onNodeWithText("Save").performClick()
        ui.onNodeWithText("Saved").assertIsDisplayed()
        ui.onNodeWithText("Unsaved changes").assertDoesNotExist()
        ui.activityRule.scenario.onActivity {
            org.junit.Assert.assertEquals(text, it.filesDir.resolve("note.txt").readText())
        }
        ui.activityRule.scenario.recreate()
        ui.onNodeWithText(text).assertExists()
    }
}
