// SPDX-License-Identifier: GPL-3.0-only
package org.weare.notes

import androidx.compose.ui.renderComposeScene
import java.awt.EventQueue
import java.io.File
import java.nio.file.Files

/** Exercise the packaged editor and native renderer without opening a desktop window. */
internal fun runDesktopSelfTest(preview: File?) {
    val directory = Files.createTempDirectory("weare-notes-test").toFile()
    val target = directory.resolve("note.txt")
    try {
        val file = NoteFile(target)
        check(file.readForEditor() == "")
        check(file.saveFromEditor("First draft"))
        val sample = "Caf\u00e9 notes\nA second line."
        check(file.saveFromEditor(sample))
        val reopened = NoteFile(target).readForEditor()
        check(reopened == sample)
        EventQueue.invokeAndWait {
            renderComposeScene(width = 640, height = 480) {
                NotesEditor(reopened, file::saveFromEditor)
            }.use { image ->
                check(image.width == 640 && image.height == 480)
                if (preview != null) {
                    checkNotNull(image.encodeToData()).use { preview.writeBytes(it.bytes) }
                }
            }
        }
        println("Notes desktop self-test passed.")
    } finally {
        Files.deleteIfExists(target.toPath())
        Files.delete(directory.toPath())
    }
}
