// SPDX-License-Identifier: GPL-3.0-only
package org.weare.notes

import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import androidx.compose.ui.window.rememberWindowState
import java.io.File

fun main(args: Array<String>) {
    if (args.firstOrNull() == "--self-test") {
        System.setProperty("java.awt.headless", "true")
        runDesktopSelfTest(args.getOrNull(1)?.let(::File))
        return
    }

    val dataDirectory = System.getenv("LOCALAPPDATA")?.takeIf { it.isNotBlank() }?.let(::File)
        ?: File(System.getProperty("user.home"), "AppData/Local")
    val file = NoteFile(dataDirectory.resolve("Weare/Notes/note.txt"))
    val initial = file.readForEditor()
    application {
        Window(onCloseRequest = ::exitApplication, title = "Notes",
            state = rememberWindowState(width = 640.dp, height = 480.dp)) {
            NotesEditor(initial, file::saveFromEditor)
        }
    }
}
