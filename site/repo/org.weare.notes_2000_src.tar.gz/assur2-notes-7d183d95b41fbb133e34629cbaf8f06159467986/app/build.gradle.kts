import org.jetbrains.compose.desktop.application.dsl.TargetFormat

plugins {
    id("com.android.application") version "8.9.2"
    id("org.jetbrains.kotlin.multiplatform") version "2.1.20"
    id("org.jetbrains.kotlin.plugin.compose") version "2.1.20"
    id("org.jetbrains.compose") version "1.8.2"
}

val appVersion = providers.gradleProperty("releaseName").orElse("0.0.1")

kotlin {
    androidTarget()
    jvm("desktop")
    jvmToolchain(17)

    sourceSets {
        commonMain.dependencies {
            implementation(compose.material)
        }
        androidMain {
            kotlin.srcDir("src/jvmSharedMain/kotlin")
            dependencies { implementation("androidx.activity:activity-compose:1.10.1") }
        }
        val desktopMain by getting {
            kotlin.srcDir("src/jvmSharedMain/kotlin")
            dependencies { implementation(compose.desktop.currentOs) }
        }
        androidUnitTest {
            kotlin.srcDir("src/test/java")
            dependencies { implementation("junit:junit:4.13.2") }
        }
        androidInstrumentedTest {
            kotlin.srcDir("src/androidTest/java")
            dependencies {
                implementation("androidx.compose.ui:ui-test-junit4:1.8.2")
                implementation("androidx.test.ext:junit:1.2.1")
                implementation("androidx.test:runner:1.6.2")
            }
        }
    }
}

android {
    namespace = "org.weare.notes"
    compileSdk = 35
    defaultConfig {
        applicationId = "org.weare.notes"
        minSdk = 26
        targetSdk = 35
        versionCode = providers.gradleProperty("releaseCode").orElse("1").get().toInt()
        versionName = appVersion.get()
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }
    sourceSets["main"].apply {
        manifest.srcFile("src/main/AndroidManifest.xml")
        res.srcDirs("src/main/res")
    }
    buildFeatures { compose = true }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

compose.desktop {
    application {
        mainClass = "org.weare.notes.DesktopKt"
        nativeDistributions {
            targetFormats(TargetFormat.Msi)
            packageName = "Notes"
            packageVersion = appVersion.get()
        }
    }
}
