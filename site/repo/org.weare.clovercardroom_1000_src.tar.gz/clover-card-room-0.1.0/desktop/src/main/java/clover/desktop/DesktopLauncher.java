package clover.desktop;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import clover.CardRoom;

public final class DesktopLauncher {
    public static void main(String[] args) {
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
        config.setTitle("Clover Card Room");
        config.setWindowedMode(1152, 720);
        config.setWindowSizeLimits(800, 500, -1, -1);
        config.setWindowIcon("clover.png");
        config.disableAudio(true);
        config.useVsync(true);
        config.setIdleFPS(30);
        new Lwjgl3Application(new CardRoom(), config);
    }
}
