package clover;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public final class GameChecks {
    public static void main(String[] args) {
        pokerRanking();
        solitaireMoves();
        klaverBonuses();
        for (int seed = 0; seed < 100; seed++) {
            pokerMatch(seed);
            trickMatch(false, seed);
            trickMatch(true, seed);
            switchyardMatch(seed);
        }
        System.out.println("All five games passed. Ran 400 seeded matches and focused rule checks.");
    }

    private static void pokerRanking() {
        List<Card> wheel = List.of(c(0, 14), c(1, 2), c(2, 3), c(3, 4), c(0, 5));
        List<Card> sixHigh = List.of(c(0, 2), c(1, 3), c(2, 4), c(3, 5), c(0, 6));
        List<Card> fullHouse = List.of(c(0, 13), c(1, 13), c(2, 13), c(0, 7), c(1, 7));
        List<Card> flush = List.of(c(0, 14), c(0, 10), c(0, 8), c(0, 3), c(0, 2));
        require(Poker.name(wheel).equals("Straight") && Poker.rank(wheel) < Poker.rank(sixHigh), "Wheel");
        require(Poker.rank(fullHouse) > Poker.rank(flush), "Full house beats flush");
    }

    private static void pokerMatch(int seed) {
        Poker poker = new Poker(new Random(seed));
        for (int step = 0; step < 2000; step++) {
            int balance = Arrays.stream(poker.chips).sum();
            int onTable = poker.phase == Poker.Phase.BET || poker.phase == Poker.Phase.DRAW ? poker.pot : 0;
            require(balance + onTable == 400, "Poker chip conservation");
            for (int chip : poker.chips) require(chip >= 0, "Negative chips");
            Set<Card> unique = new HashSet<>(poker.deck);
            for (List<Card> hand : poker.hands) {
                for (Card card : hand) require(unique.add(card), "Poker duplicate card");
            }
            switch (poker.phase) {
                case BET, DRAW -> poker.bot();
                case SHOWDOWN -> poker.nextDeal();
                case OVER -> { return; }
            }
        }
        throw new AssertionError("Poker did not finish");
    }

    private static void klaverBonuses() {
        List<TrickGame.Play> jacks = new ArrayList<>();
        for (int suit = 0; suit < 4; suit++) jacks.add(new TrickGame.Play(suit, c(suit, 11)));
        require(TrickGame.roem(jacks, Card.CLUBS) == 200, "Four jacks");
        List<TrickGame.Play> marriage = List.of(new TrickGame.Play(0, c(0, 11)),
            new TrickGame.Play(1, c(0, 12)), new TrickGame.Play(2, c(0, 13)), new TrickGame.Play(3, c(1, 7)));
        require(TrickGame.roem(marriage, Card.CLUBS) == 40, "Trump run and stuk");
    }

    private static void trickMatch(boolean klaver, int seed) {
        TrickGame table = new TrickGame(klaver, new Random(seed));
        for (int step = 0; step < 2500; step++) {
            switch (table.phase) {
                case TRUMP -> table.botTrump();
                case PASS -> table.pass(new ArrayList<>(table.hands.get(0).subList(0, 3)));
                case PLAY -> {
                    List<Card> legal = table.legal();
                    require(!legal.isEmpty(), "No legal trick play");
                    if (!klaver && table.tricks == 0 && table.trick.isEmpty()) {
                        require(legal.equals(List.of(c(Card.CLUBS, 2))), "Hearts opening lead");
                    }
                    table.botPlay();
                }
                case TRICK -> table.collect();
                case ROUND, OVER -> {
                    require(Arrays.stream(table.roundPoints).sum() == (klaver ? 162 : 26), "Deal total");
                    require(table.hands.stream().allMatch(List::isEmpty), "Unused trick cards");
                    if (table.phase == TrickGame.Phase.OVER) {
                        require(!klaver || table.deal == 16, "Klaverjassen match length");
                        return;
                    }
                    table.nextDeal();
                }
            }
        }
        throw new AssertionError("Trick-taking match did not finish");
    }

    private static void solitaireMoves() {
        Solitaire game = new Solitaire(new Random(1));
        List<Card> originalStock = new ArrayList<>(game.stock);
        for (int i = 0; i < originalStock.size(); i++) require(game.draw(), "Solitaire draw");
        require(game.draw() && game.stock.equals(originalStock), "Stock order after recycling");
        game.undo();
        require(game.stock.isEmpty(), "Undo recycling");
        List<Card> first = game.piles.get(0);
        first.clear();
        first.add(c(Card.HEARTS, 14));
        Solitaire.Source ace = new Solitaire.Source(0, 0);
        require(!game.move(ace, Solitaire.FIRST_FOUNDATION + Card.DIAMONDS), "Wrong foundation suit");
        require(game.move(ace, Solitaire.FIRST_FOUNDATION + Card.HEARTS), "Place ace");
        require(game.built() == 1, "Foundation count");
        List<Card> second = game.piles.get(1);
        second.clear();
        second.add(c(0, 9));
        second.add(c(Card.HEARTS, 2));
        require(game.move(new Solitaire.Source(1, 1), Solitaire.FIRST_FOUNDATION + Card.HEARTS), "Build onto ace");
        require(game.hidden[1] == 0, "Flip uncovered card");
        game.undo();
        require(game.hidden[1] == 1 && game.built() == 1, "Undo flip and build");
    }

    private static void switchyardMatch(int seed) {
        Switchyard yard = new Switchyard(new Random(seed));
        for (int step = 0; step < 500; step++) {
            int cards = yard.supply.size() + yard.spent.size();
            for (List<Integer> stock : yard.stocks) cards += stock.size();
            for (List<Integer> hand : yard.hands) cards += hand.size();
            require(cards == 50, "Switchyard card conservation");
            require(yard.actions >= 0 && yard.actions <= 3, "Switchyard action limit");
            if (yard.winner >= 0) {
                require(yard.stocks.get(yard.winner).isEmpty(), "Switchyard winner still has stock");
                return;
            }
            yard.bot();
        }
        throw new AssertionError("Switchyard stalled");
    }

    private static Card c(int suit, int rank) {
        return new Card(suit, rank);
    }

    private static void require(boolean valid, String rule) {
        if (!valid) throw new AssertionError(rule);
    }
}
