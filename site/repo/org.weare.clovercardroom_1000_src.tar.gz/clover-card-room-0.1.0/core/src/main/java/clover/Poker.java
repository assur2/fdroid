package clover;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

final class Poker {
    enum Phase { BET, DRAW, SHOWDOWN, OVER }
    static final int STAKE = 5;
    static final String[] RANKS = {"High card", "One pair", "Two pair", "Three of a kind",
        "Straight", "Flush", "Full house", "Four of a kind", "Straight flush"};

    final List<List<Card>> hands = new ArrayList<>();
    final List<Card> deck = new ArrayList<>();
    final int[] chips = {100, 100, 100, 100};
    final int[] paid = new int[4];
    final String[] action = new String[4];
    final boolean[] playing = new boolean[4];
    final boolean[] acted = new boolean[4];
    final Random random;
    int deal, turn, pot, bet, raises, street;
    Phase phase;
    String result;

    Poker(Random random) {
        this.random = random;
        for (int i = 0; i < 4; i++) hands.add(new ArrayList<>());
        nextDeal();
    }

    void nextDeal() {
        int eligible = 0;
        for (int chip : chips) if (chip >= STAKE) eligible++;
        if (eligible < 2 || chips[0] < STAKE || deal == 12) {
            phase = Phase.OVER;
            int high = Arrays.stream(chips).max().orElse(0);
            List<String> leaders = new ArrayList<>();
            for (int seat = 0; seat < 4; seat++) {
                if (chips[seat] == high) leaders.add(TrickGame.SEATS[seat]);
            }
            String finish = leaders.size() > 1 ? " tie" : leaders.get(0).equals("You") ? " win" : " wins";
            result = leaders.stream().collect(Collectors.joining(" / ")) + finish + " with " + high + " chips.";
            return;
        }

        deal++;
        street = pot = 0;
        result = "";
        deck.clear();
        deck.addAll(Card.deck(2, random));
        for (int seat = 0; seat < 4; seat++) {
            List<Card> hand = hands.get(seat);
            hand.clear();
            playing[seat] = chips[seat] >= STAKE;
            action[seat] = playing[seat] ? "Ante 5" : "Sitting out";
            if (!playing[seat]) continue;
            chips[seat] -= STAKE;
            pot += STAKE;
            for (int i = 0; i < 5; i++) hand.add(Card.pop(deck));
            hand.sort(Card.ORDER);
        }
        openBetting();
    }

    private void openBetting() {
        Arrays.fill(paid, 0);
        Arrays.fill(acted, false);
        bet = raises = 0;
        turn = nextSeat((deal - 2 + 4) % 4);
        phase = Phase.BET;
    }

    int due() {
        return bet - paid[turn];
    }

    boolean canRaise() {
        if (phase != Phase.BET || raises == 2) return false;
        for (int seat = 0; seat < 4; seat++) {
            if (playing[seat] && paid[seat] + chips[seat] < bet + STAKE) return false;
        }
        return true;
    }

    void wager(boolean raise) {
        if (phase != Phase.BET || raise && !canRaise()) return;
        if (raise) {
            bet += STAKE;
            raises++;
            Arrays.fill(acted, false);
        }
        int amount = due();
        chips[turn] -= amount;
        paid[turn] += amount;
        pot += amount;
        action[turn] = raise ? (raises == 1 ? "Bet " : "Raised to ") + bet
            : amount > 0 ? "Called " + amount : "Checked";
        acted[turn] = true;
        advanceBetting();
    }

    void fold() {
        if (phase != Phase.BET) return;
        playing[turn] = false;
        action[turn] = "Folded";
        advanceBetting();
    }

    private void advanceBetting() {
        int active = 0;
        for (boolean seat : playing) if (seat) active++;
        if (active == 1) {
            award(Collections.singletonList(nextSeat(turn)), false);
            return;
        }
        for (int seat = nextSeat(turn), i = 0; i < active; i++, seat = nextSeat(seat)) {
            if (!acted[seat] || paid[seat] < bet) {
                turn = seat;
                return;
            }
        }
        if (street == 0) {
            phase = Phase.DRAW;
            turn = nextSeat((deal - 2 + 4) % 4);
        } else {
            long high = -1;
            List<Integer> winners = new ArrayList<>();
            for (int seat = 0; seat < 4; seat++) {
                if (!playing[seat]) continue;
                long value = rank(hands.get(seat));
                if (value > high) {
                    high = value;
                    winners.clear();
                }
                if (value == high) winners.add(seat);
            }
            award(winners, true);
        }
    }

    private int nextSeat(int seat) {
        do {
            seat = (seat + 1) % 4;
        } while (!playing[seat]);
        return seat;
    }

    void draw(List<Card> discard) {
        List<Card> hand = hands.get(turn);
        if (phase != Phase.DRAW || discard.size() > 3 || !hand.containsAll(discard)
            || discard.stream().distinct().count() != discard.size()) return;
        hand.removeAll(discard);
        while (hand.size() < 5) hand.add(Card.pop(deck));
        hand.sort(Card.ORDER);
        action[turn] = discard.isEmpty() ? "Stood pat" : "Drew " + discard.size();
        turn = nextSeat(turn);
        if (turn == nextSeat((deal - 2 + 4) % 4)) {
            street = 1;
            openBetting();
        }
    }

    private void award(List<Integer> winners, boolean reveal) {
        List<String> names = new ArrayList<>();
        for (int i = 0; i < winners.size(); i++) {
            int seat = winners.get(i);
            chips[seat] += pot / winners.size() + (i < pot % winners.size() ? 1 : 0);
            names.add(TrickGame.SEATS[seat]);
        }
        String finish = winners.size() > 1 ? " split " : winners.get(0) == 0 ? " win " : " wins ";
        result = names.stream().collect(Collectors.joining(" / ")) + finish + pot
            + (reveal ? " with " + name(hands.get(winners.get(0))).toLowerCase(java.util.Locale.ROOT) : " chips");
        phase = Phase.SHOWDOWN;
        if (!reveal) Arrays.fill(playing, false);
    }

    void bot() {
        List<Card> hand = hands.get(turn);
        int category = (int) (rank(hand) >>> 20);
        if (phase == Phase.DRAW) {
            List<Card> discard = new ArrayList<>();
            if (category < 4) {
                int[] count = new int[15];
                for (Card card : hand) count[card.rank()]++;
                List<Card> sorted = new ArrayList<>(hand);
                sorted.sort(java.util.Comparator.comparingInt(Card::rank));
                for (Card card : sorted) {
                    if (count[card.rank()] == 1 && discard.size() < 3) discard.add(card);
                }
            }
            draw(discard);
        } else {
            boolean raise = canRaise() && random.nextInt(100) < (category >= 3 ? 80 : category == 2 ? 40 : 9);
            if (!raise && due() > 0 && category == 0 && random.nextInt(100) < (street == 0 ? 35 : 78)) fold();
            else wager(raise);
        }
    }

    static String name(List<Card> hand) {
        return RANKS[(int) (rank(hand) >>> 20)];
    }

    static long rank(List<Card> hand) {
        int[] counts = new int[15];
        boolean flush = true;
        for (Card card : hand) {
            counts[card.rank()]++;
            flush &= card.suit() == hand.get(0).suit();
        }
        int straight = 0;
        for (int top = 14; top >= 6; top--) {
            if (counts[top] * counts[top - 1] * counts[top - 2] * counts[top - 3] * counts[top - 4] == 1) {
                straight = top;
                break;
            }
        }
        if (counts[14] * counts[5] * counts[4] * counts[3] * counts[2] == 1) straight = 5;

        int[] ranks = new int[5];
        int index = 0;
        int four = 0, three = 0, pairs = 0;
        for (int number = 4; number >= 1; number--) {
            for (int value = 14; value >= 2; value--) {
                if (counts[value] != number) continue;
                if (number == 4) four++;
                if (number == 3) three++;
                if (number == 2) pairs++;
                ranks[index++] = value;
            }
        }
        int category = 0;
        if (flush && straight > 0) category = 8;
        else if (four > 0) category = 7;
        else if (three > 0 && pairs > 0) category = 6;
        else if (flush) category = 5;
        else if (straight > 0) category = 4;
        else if (three > 0) category = 3;
        else if (pairs > 0) category = pairs;
        if (category == 4 || category == 8) return ((long) category << 20) | ((long) straight << 16);
        long value = category;
        for (int rank : ranks) value = (value << 4) | rank;
        return value;
    }
}
