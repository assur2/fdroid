package clover;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Random;

final class Solitaire {
    static final int WASTE = 7, FIRST_FOUNDATION = 8;
    record Source(int pile, int index) {}
    private record Snapshot(List<List<Card>> piles, List<Card> stock, int[] hidden, int moves) {}

    final List<List<Card>> piles = new ArrayList<>();
    final List<Card> stock;
    final int[] hidden = new int[7];
    final Deque<Snapshot> history = new ArrayDeque<>();
    int moves;

    Solitaire(Random random) {
        stock = Card.deck(2, random);
        for (int pile = 0; pile < 12; pile++) {
            List<Card> cards = new ArrayList<>();
            if (pile < WASTE) {
                hidden[pile] = pile;
                for (int i = 0; i <= pile; i++) cards.add(Card.pop(stock));
            }
            piles.add(cards);
        }
    }

    boolean draw() {
        List<Card> waste = piles.get(WASTE);
        if (stock.isEmpty() && waste.isEmpty()) return false;
        remember();
        if (stock.isEmpty()) {
            while (!waste.isEmpty()) stock.add(Card.pop(waste));
        } else {
            waste.add(Card.pop(stock));
        }
        return true;
    }

    boolean canPick(Source source) {
        if (source.pile < 0 || source.pile >= piles.size()) return false;
        int count = piles.get(source.pile).size();
        return source.index >= 0 && source.index < count
            && (source.pile < 7 ? source.index >= hidden[source.pile] : source.index == count - 1);
    }

    boolean canMove(Source source, int to) {
        if (to == WASTE || to < 0 || to >= 12 || source.pile == to || !canPick(source)) return false;
        List<Card> from = piles.get(source.pile);
        List<Card> destination = piles.get(to);
        Card card = from.get(source.index);
        if (to >= FIRST_FOUNDATION) {
            return source.index == from.size() - 1 && card.suit() == to - FIRST_FOUNDATION
                && (destination.isEmpty() ? card.rank() == 14 : card.rank() == destination.size() + 1);
        }
        if (destination.isEmpty()) return card.rank() == 13;
        Card top = destination.get(destination.size() - 1);
        int rank = card.rank() == 14 ? 1 : card.rank();
        return top.red() != card.red() && top.rank() == rank + 1;
    }

    boolean move(Source source, int to) {
        if (!canMove(source, to)) return false;
        remember();
        List<Card> from = piles.get(source.pile);
        List<Card> run = from.subList(source.index, from.size());
        piles.get(to).addAll(run);
        run.clear();
        if (source.pile < 7 && !from.isEmpty() && from.size() == hidden[source.pile]) hidden[source.pile]--;
        return true;
    }

    private void remember() {
        List<List<Card>> copies = new ArrayList<>();
        for (List<Card> pile : piles) copies.add(new ArrayList<>(pile));
        history.push(new Snapshot(copies, new ArrayList<>(stock), hidden.clone(), moves));
        moves++;
    }

    void undo() {
        if (history.isEmpty()) return;
        Snapshot state = history.pop();
        piles.clear();
        piles.addAll(state.piles);
        stock.clear();
        stock.addAll(state.stock);
        System.arraycopy(state.hidden, 0, hidden, 0, 7);
        moves = state.moves;
    }

    int built() {
        int count = 0;
        for (int i = FIRST_FOUNDATION; i < 12; i++) count += piles.get(i).size();
        return count;
    }
}
