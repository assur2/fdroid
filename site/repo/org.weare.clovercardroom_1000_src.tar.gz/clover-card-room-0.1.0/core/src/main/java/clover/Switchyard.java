package clover;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

final class Switchyard {
    static final String[] SEATS = {"You", "West", "East"};
    static final int[] START = {1, 10};
    static final int MAX_ACTIONS = 3;
    static final int STOCK = -1;

    final List<List<Integer>> stocks = new ArrayList<>();
    final List<List<Integer>> hands = new ArrayList<>();
    final List<Integer> supply = new ArrayList<>();
    final List<Integer> spent = new ArrayList<>();
    final int[] next = START.clone();
    final Random random;
    int turn, actions, idleTurns, winner = -1;
    boolean stockPlayed, signal;
    String event = "Your dispatch";

    Switchyard(Random random) {
        this.random = random;
        for (int copy = 0; copy < 5; copy++) {
            for (int number = 1; number <= 10; number++) supply.add(number);
        }
        Collections.shuffle(supply, random);
        for (int seat = 0; seat < 3; seat++) {
            List<Integer> stock = new ArrayList<>();
            for (int i = 0; i < 8; i++) stock.add(Card.pop(supply));
            stocks.add(stock);
            hands.add(new ArrayList<>());
            refill(seat);
        }
        actions = MAX_ACTIONS;
    }

    private void refill(int seat) {
        List<Integer> hand = hands.get(seat);
        while (hand.size() < 4) {
            if (supply.isEmpty()) {
                supply.addAll(spent);
                spent.clear();
                Collections.shuffle(supply, random);
            }
            if (supply.isEmpty()) break;
            hand.add(Card.pop(supply));
        }
    }

    int top(int seat) {
        List<Integer> stock = stocks.get(seat);
        return stock.isEmpty() ? 0 : stock.get(stock.size() - 1);
    }

    int number(int source) {
        return source == STOCK ? top(turn) : hands.get(turn).get(source);
    }

    boolean canRoute(int source, int route) {
        return winner < 0 && actions > 0 && (number(source) == next[route] || signal && source == STOCK);
    }

    boolean route(int source, int route) {
        if (!canRoute(source, route)) return false;
        int number = number(source);
        if (source == STOCK) {
            Card.pop(stocks.get(turn));
            stockPlayed = true;
            signal = false;
            if (stocks.get(turn).isEmpty()) winner = turn;
        } else {
            hands.get(turn).remove(source);
        }
        spent.add(number);
        next[route] = route == 0 ? (number == 10 ? 1 : number + 1) : (number == 1 ? 10 : number - 1);
        actions--;
        event = SEATS[turn] + " dispatched " + number + " on the " + (route == 0 ? "up" : "down") + " line.";
        return true;
    }

    void endTurn(int exchange) {
        if (winner >= 0) return;
        if (exchange >= 0 && exchange < hands.get(turn).size()) {
            spent.add(hands.get(turn).remove(exchange));
        }
        idleTurns = stockPlayed ? 0 : idleTurns + 1;
        turn = (turn + 1) % 3;
        refill(turn);
        signal = idleTurns >= 3;
        stockPlayed = false;
        actions = MAX_ACTIONS;
    }

    void bot() {
        for (int route = 0; route < 2; route++) {
            if (route(STOCK, route)) return;
        }
        List<Integer> hand = hands.get(turn);
        if (actions > 1) {
            for (int index = 0; index < hand.size(); index++) {
                for (int route = 0; route < 2; route++) {
                    if (hand.get(index) + (route == 0 ? 1 : -1) == top(turn) && route(index, route)) return;
                }
            }
        }
        for (int index = 0; index < hand.size(); index++) {
            for (int route = 0; route < 2; route++) {
                if (route(index, route)) return;
            }
        }
        endTurn(hand.isEmpty() ? -1 : random.nextInt(hand.size()));
    }
}
