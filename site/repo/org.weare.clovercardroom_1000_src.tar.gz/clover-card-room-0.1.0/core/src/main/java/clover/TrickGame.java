package clover;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

final class TrickGame {
    enum Phase { PASS, TRUMP, PLAY, TRICK, ROUND, OVER }
    record Play(int seat, Card card) {}

    private static final int[] TRUMP_ORDER = {7, 8, 12, 13, 10, 14, 9, 11};
    private static final int[] PLAIN_ORDER = {7, 8, 9, 11, 12, 13, 10, 14};
    private static final int[] TRUMP_POINTS = {0, 0, 3, 4, 10, 11, 14, 20};
    private static final int[] PLAIN_POINTS = {0, 0, 0, 2, 3, 4, 10, 11};
    static final String[] SEATS = {"You", "West", "North", "East"};

    final boolean klaver;
    final Random random;
    final List<List<Card>> hands = new ArrayList<>();
    final List<Play> trick = new ArrayList<>();
    final int[] score, roundPoints, meld = new int[2], trickCount;
    Phase phase;
    int deal, caller, trump, turn, tricks;
    boolean heartsBroken;
    String result = "";

    TrickGame(boolean klaver, Random random) {
        this.klaver = klaver;
        this.random = random;
        score = new int[klaver ? 2 : 4];
        roundPoints = new int[score.length];
        trickCount = new int[score.length];
        for (int i = 0; i < 4; i++) hands.add(new ArrayList<>());
        nextDeal();
    }

    void nextDeal() {
        deal++;
        trick.clear();
        Arrays.fill(roundPoints, 0);
        Arrays.fill(meld, 0);
        Arrays.fill(trickCount, 0);
        heartsBroken = false;
        tricks = 0;
        trump = -1;
        result = "";
        List<Card> deck = Card.deck(klaver ? 7 : 2, random);
        for (int seat = 0; seat < 4; seat++) {
            List<Card> hand = hands.get(seat);
            hand.clear();
            for (int i = 0; i < (klaver ? 8 : 13); i++) hand.add(Card.pop(deck));
            hand.sort(Card.ORDER);
        }
        if (klaver) {
            caller = (deal - 1) % 4;
            turn = caller;
            phase = Phase.TRUMP;
        } else if (passOffset() == 0) {
            startHearts();
        } else {
            phase = Phase.PASS;
            turn = 0;
        }
    }

    int passOffset() {
        return deal % 4;
    }

    String passDirection() {
        return new String[]{"Hold", "Left", "Across", "Right"}[passOffset()];
    }

    void pass(List<Card> selection) {
        if (phase != Phase.PASS || selection.size() != 3
            || selection.stream().distinct().count() != 3 || !hands.get(0).containsAll(selection)) return;
        List<List<Card>> outgoing = new ArrayList<>();
        outgoing.add(new ArrayList<>(selection));
        for (int seat = 1; seat < 4; seat++) {
            List<Card> candidates = new ArrayList<>(hands.get(seat));
            candidates.sort(Comparator.comparingInt(TrickGame::heartsDanger).reversed());
            outgoing.add(new ArrayList<>(candidates.subList(0, 3)));
        }
        for (int seat = 0; seat < 4; seat++) hands.get(seat).removeAll(outgoing.get(seat));
        for (int seat = 0; seat < 4; seat++) {
            List<Card> hand = hands.get((seat + passOffset()) % 4);
            hand.addAll(outgoing.get(seat));
            hand.sort(Card.ORDER);
        }
        startHearts();
    }

    private void startHearts() {
        for (int seat = 0; seat < 4; seat++) {
            if (hands.get(seat).contains(new Card(Card.CLUBS, 2))) turn = seat;
        }
        phase = Phase.PLAY;
    }

    void chooseTrump(int suit) {
        if (phase != Phase.TRUMP || suit < 0 || suit > 3) return;
        trump = suit;
        phase = Phase.PLAY;
    }

    void botTrump() {
        int bestSuit = 0;
        int bestWeight = -1;
        for (int suit = 0; suit < 4; suit++) {
            int weight = 0;
            for (Card card : hands.get(caller)) {
                if (card.suit() == suit) weight += points(card, suit) + 5;
            }
            if (weight > bestWeight) {
                bestWeight = weight;
                bestSuit = suit;
            }
        }
        chooseTrump(bestSuit);
    }

    List<Card> legal() {
        if (phase != Phase.PLAY) return Collections.emptyList();
        List<Card> hand = hands.get(turn);
        if (trick.isEmpty()) {
            if (klaver || heartsBroken) return hand;
            if (tricks == 0) return Collections.singletonList(new Card(Card.CLUBS, 2));
            List<Card> nonHearts = matching(hand, card -> card.suit() != Card.HEARTS);
            return nonHearts.isEmpty() ? hand : nonHearts;
        }

        int lead = trick.get(0).card.suit();
        List<Card> follow = matching(hand, card -> card.suit() == lead);
        if (!klaver) {
            if (!follow.isEmpty()) return follow;
            if (tricks > 0) return hand;
            List<Card> safe = matching(hand, card -> penalty(card) == 0);
            return safe.isEmpty() ? hand : safe;
        }

        Play high = winner();
        boolean trumped = high.card.suit() == trump;
        List<Card> higherTrumps = matching(hand, card -> card.suit() == trump
            && (!trumped || strength(card, trump, lead) > strength(high.card, trump, lead)));
        if (!follow.isEmpty()) {
            return lead == trump && !higherTrumps.isEmpty() ? higherTrumps : follow;
        }
        if (high.seat % 2 != turn % 2 && !higherTrumps.isEmpty()) return higherTrumps;
        if (trumped) {
            List<Card> avoidUndertrump = matching(hand, card -> card.suit() != trump
                || higherTrumps.contains(card));
            if (!avoidUndertrump.isEmpty()) return avoidUndertrump;
        }
        return hand;
    }

    private static List<Card> matching(List<Card> hand, java.util.function.Predicate<Card> filter) {
        List<Card> cards = new ArrayList<>();
        for (Card card : hand) if (filter.test(card)) cards.add(card);
        return cards;
    }

    boolean play(Card card) {
        if (!legal().contains(card) || !hands.get(turn).remove(card)) return false;
        trick.add(new Play(turn, card));
        if (!klaver && card.suit() == Card.HEARTS) heartsBroken = true;
        if (trick.size() == 4) phase = Phase.TRICK;
        else turn = (turn + 1) % 4;
        return true;
    }

    void botPlay() {
        List<Card> options = legal();
        if (options.isEmpty()) return;
        Card best = options.get(0);
        Play current = trick.isEmpty() ? null : winner();
        int lead = current == null ? -1 : trick.get(0).card.suit();
        int bestValue = Integer.MIN_VALUE;
        for (Card card : options) {
            int weight;
            if (klaver) {
                int value = strength(card, trump, lead < 0 ? card.suit() : lead);
                if (current == null) weight = value - (card.suit() == trump ? 27 : 0);
                else if (current.seat % 2 == turn % 2) weight = 4 * points(card, trump) - value;
                else if (value > strength(current.card, trump, lead)) weight = 80 + value;
                else weight = -5 * points(card, trump) - value;
            } else if (current == null) {
                weight = -heartsDanger(card);
            } else if (card.suit() == lead && card.rank() > current.card.rank()) {
                weight = -40 - heartsDanger(card);
                if (trick.size() == 3 && trick.stream().allMatch(play -> penalty(play.card) == 0)) {
                    weight = penalty(card) == 0 ? heartsDanger(card) : weight;
                }
            } else {
                weight = heartsDanger(card) + 8 * penalty(card);
            }
            if (weight > bestValue) {
                bestValue = weight;
                best = card;
            }
        }
        play(best);
    }

    Play winner() {
        int lead = trick.get(0).card.suit();
        return Collections.max(trick, Comparator.comparingInt(play -> strength(play.card, trump, lead)));
    }

    void collect() {
        if (phase != Phase.TRICK) return;
        turn = winner().seat;
        int side = klaver ? turn % 2 : turn;
        tricks++;
        trickCount[side]++;
        for (Play play : trick) roundPoints[side] += klaver ? points(play.card, trump) : penalty(play.card);
        if (klaver) meld[side] += roem(trick, trump);
        trick.clear();
        if (hands.get(turn).isEmpty()) finishDeal(side);
        else phase = Phase.PLAY;
    }

    private void finishDeal(int lastSide) {
        if (klaver) {
            roundPoints[lastSide] += 10;
            int declaring = caller % 2;
            int defending = 1 - declaring;
            int attack = roundPoints[declaring] + meld[declaring] + (trickCount[declaring] == 8 ? 100 : 0);
            int defense = roundPoints[defending] + meld[defending] + (trickCount[defending] == 8 ? 100 : 0);
            if (attack <= defense) {
                score[defending] += attack + defense;
                result = sideName(declaring) + " went nat. The other team scores " + (attack + defense) + ".";
            } else {
                score[declaring] += attack;
                score[defending] += defense;
                result = sideName(declaring) + (trickCount[declaring] == 8 ? " took all eight tricks. Pit +100." : " made trump.");
            }
            phase = deal == 16 ? Phase.OVER : Phase.ROUND;
            if (phase == Phase.OVER) result += score[0] == score[1] ? " Match drawn."
                : " " + sideName(score[0] > score[1] ? 0 : 1) + " win.";
        } else {
            int moon = -1;
            for (int seat = 0; seat < 4; seat++) if (roundPoints[seat] == 26) moon = seat;
            for (int seat = 0; seat < 4; seat++) {
                score[seat] += moon < 0 ? roundPoints[seat] : seat == moon ? 0 : 26;
            }
            result = moon < 0 ? "Points added. Lowest total wins." : SEATS[moon] + " shot the moon.";
            phase = Arrays.stream(score).max().orElse(0) >= 100 ? Phase.OVER : Phase.ROUND;
            if (phase == Phase.OVER) {
                int low = Arrays.stream(score).min().orElse(0);
                List<String> tied = new ArrayList<>();
                for (int seat = 0; seat < 4; seat++) if (score[seat] == low) tied.add(SEATS[seat]);
                String finish = tied.size() > 1 ? " tie" : score[0] == low ? " win" : " wins";
                result += " " + tied.stream().collect(Collectors.joining(" / ")) + finish + " with " + low + ".";
            }
        }
    }

    private static String sideName(int side) {
        return side == 0 ? "You and North" : "West and East";
    }

    private static int heartsDanger(Card card) {
        if (card.suit() == Card.SPADES && card.rank() >= 12) return 20 + card.rank();
        return card.rank() + (card.suit() == Card.HEARTS ? 3 : 0);
    }

    static int penalty(Card card) {
        if (card.suit() == Card.HEARTS) return 1;
        return card.suit() == Card.SPADES && card.rank() == 12 ? 13 : 0;
    }

    private static int rankIndex(int rank, int[] order) {
        for (int i = 0; i < order.length; i++) if (rank == order[i]) return i;
        throw new IllegalArgumentException("Invalid Klaverjassen rank");
    }

    static int strength(Card card, int trump, int lead) {
        if (trump < 0) return card.suit() == lead ? card.rank() : 0;
        if (card.suit() == trump) return 32 + rankIndex(card.rank(), TRUMP_ORDER);
        return card.suit() == lead ? 16 + rankIndex(card.rank(), PLAIN_ORDER) : 0;
    }

    static int points(Card card, int trump) {
        return card.suit() == trump ? TRUMP_POINTS[rankIndex(card.rank(), TRUMP_ORDER)]
            : PLAIN_POINTS[rankIndex(card.rank(), PLAIN_ORDER)];
    }

    static int roem(List<Play> trick, int trump) {
        int[] counts = new int[15];
        int[] masks = new int[4];
        for (Play play : trick) {
            Card card = play.card;
            counts[card.rank()]++;
            masks[card.suit()] |= 1 << card.rank();
        }
        int total = 0;
        if (counts[11] == 4) total += 200;
        for (int rank : new int[]{10, 12, 13, 14}) if (counts[rank] == 4) total += 100;
        for (int mask : masks) {
            int longest = 0;
            int run = 0;
            for (int rank = 7; rank <= 14; rank++) {
                run = (mask & (1 << rank)) == 0 ? 0 : run + 1;
                longest = Math.max(run, longest);
            }
            if (longest >= 3) total += longest == 4 ? 50 : 20;
        }
        int marriage = (1 << 12) | (1 << 13);
        if ((masks[trump] & marriage) == marriage) total += 20;
        return total;
    }
}
