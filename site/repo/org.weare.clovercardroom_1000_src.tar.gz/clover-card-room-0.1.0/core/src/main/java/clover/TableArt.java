package clover;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.NinePatch;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.Disposable;

final class TableArt implements Disposable {
    static final int WIDTH = 1152, HEIGHT = 720;
    static final Color INK = Color.valueOf("142824"), FELT = Color.valueOf("163D32");
    static final Color FRAME = Color.valueOf("102B25"), PANEL = Color.valueOf("20463B");
    static final Color LINE = Color.valueOf("3C6253"), PAPER = Color.valueOf("F8F0DC");
    static final Color GOLD = Color.valueOf("F1CA81"), MUTED = Color.valueOf("B8CABE");
    static final Color RED = Color.valueOf("AE3345"), DARK = Color.valueOf("18322B");
    static final Color WHITE = Color.WHITE;
    private static final Color BACK = Color.valueOf("286452");
    private static final Color SHADE = Color.valueOf("0E2D25");

    final SpriteBatch batch = new SpriteBatch();
    private final GlyphLayout layout = new GlyphLayout();
    private final Texture square, rounded;
    private final Texture[] suits = new Texture[4];
    private final NinePatch patch;
    private final BitmapFont body = font("body"), display = font("display");

    TableArt() {
        Pixmap pixel = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        pixel.setColor(WHITE);
        pixel.fill();
        square = new Texture(pixel);
        pixel.dispose();

        Pixmap corners = new Pixmap(25, 25, Pixmap.Format.RGBA8888);
        corners.setColor(WHITE);
        corners.fillRectangle(8, 0, 9, 25);
        corners.fillRectangle(0, 8, 25, 9);
        for (int x : new int[]{8, 16}) {
            for (int y : new int[]{8, 16}) corners.fillCircle(x, y, 8);
        }
        rounded = new Texture(corners);
        rounded.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        patch = new NinePatch(rounded, 9, 9, 9, 9);
        corners.dispose();
        for (int suit = 0; suit < 4; suit++) suits[suit] = suitTexture(suit);
    }

    private static BitmapFont font(String name) {
        BitmapFont font = new BitmapFont(Gdx.files.internal("fonts/" + name + ".fnt"));
        font.getRegion().getTexture().setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        font.setUseIntegerPositions(false);
        return font;
    }

    private static Texture suitTexture(int suit) {
        Pixmap pip = new Pixmap(96, 96, Pixmap.Format.RGBA8888);
        pip.setColor(WHITE);
        switch (suit) {
            case Card.CLUBS -> {
                pip.fillCircle(48, 26, 20);
                pip.fillCircle(28, 53, 20);
                pip.fillCircle(68, 53, 20);
                pip.fillTriangle(48, 45, 33, 88, 63, 88);
            }
            case Card.DIAMONDS -> {
                pip.fillTriangle(48, 5, 88, 48, 8, 48);
                pip.fillTriangle(8, 48, 88, 48, 48, 91);
            }
            case Card.SPADES -> {
                pip.fillCircle(30, 51, 22);
                pip.fillCircle(66, 51, 22);
                pip.fillTriangle(48, 5, 83, 37, 13, 37);
                pip.fillTriangle(48, 45, 31, 88, 65, 88);
            }
            case Card.HEARTS -> {
                pip.fillCircle(27, 32, 22);
                pip.fillCircle(69, 32, 22);
                pip.fillTriangle(8, 45, 88, 45, 48, 88);
                pip.fillRectangle(27, 27, 42, 21);
            }
            default -> throw new IllegalArgumentException("Unknown suit " + suit);
        }
        Texture texture = new Texture(pip);
        texture.setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        pip.dispose();
        return texture;
    }

    void rect(float x, float y, float w, float h, Color color) {
        batch.setColor(color);
        batch.draw(square, x, HEIGHT - y - h, w, h);
        batch.setColor(WHITE);
    }

    void box(float x, float y, float w, float h, Color color) {
        patch.setColor(color);
        patch.draw(batch, x, HEIGHT - y - h, w, h);
    }

    void border(float x, float y, float w, float h, Color stroke, Color fill) {
        box(x, y, w, h, stroke);
        box(x + 1, y + 1, w - 2, h - 2, fill);
    }

    private BitmapFont prepare(boolean heading, float scale, Color color) {
        BitmapFont font = heading ? display : body;
        font.getData().setScale(scale / (heading ? 66 : 44));
        font.setColor(color);
        return font;
    }

    void text(String value, float x, float y, float size, Color color) {
        prepare(false, size, color).draw(batch, value, x, HEIGHT - y);
    }

    void title(String value, float x, float y, float size, Color color) {
        prepare(true, size, color).draw(batch, value, x, HEIGHT - y);
    }

    void center(String value, float x, float y, float size, Color color, boolean heading) {
        BitmapFont font = prepare(heading, size, color);
        layout.setText(font, value);
        font.draw(batch, layout, x - layout.width / 2, HEIGHT - y);
    }

    void paragraph(String value, float x, float y, float size, Color color, float width) {
        BitmapFont font = prepare(false, size, color);
        font.draw(batch, value, x, HEIGHT - y, width, Align.left, true);
    }

    void suit(int suit, float x, float y, float size, Color color) {
        batch.setColor(color);
        batch.draw(suits[suit], x, HEIGHT - y - size, size, size);
        batch.setColor(WHITE);
    }

    void face(float x, float y, float w, float h, Card card, boolean selected, boolean available) {
        box(x + 1, y + 4, w, h, SHADE);
        border(x, y, w, h, selected ? GOLD : Color.valueOf("CFC9AF"),
            selected ? Color.valueOf("FFE2A6") : available ? PAPER : Color.valueOf("CCC9B8"));
        Color mark = card.red() ? RED : DARK;
        float s = Math.min(w * 0.27f, 28);
        title(card.label(), x + w * .11f, y + h * .10f, s, mark);
        suit(card.suit(), x + w * .12f, y + h * .29f, w * .20f, mark);
        float pip = Math.min(w * .45f, h * .39f);
        suit(card.suit(), x + (w - pip) / 2, y + h * .49f, pip, mark);
    }

    void back(float x, float y, float w, float h) {
        box(x + 1, y + 4, w, h, SHADE);
        box(x, y, w, h, PAPER);
        box(x + 4, y + 4, w - 8, h - 8, BACK);
        if (w < 32) return;
        border(x + 9, y + 9, w - 18, h - 18, GOLD, FELT);
        float size = Math.min(w, h) * 0.45f;
        suit(Card.CLUBS, x + (w - size) / 2, y + (h - size) / 2, size, GOLD);
    }

    void overlappedFace(float x, float y, float w, float h, Card card, boolean selected, float exposed) {
        border(x, y, w, h, selected ? GOLD : MUTED, selected ? Color.valueOf("FFE2A6") : PAPER);
        float size = Math.min(exposed - 1, 22);
        Color mark = card.red() ? RED : DARK;
        title(card.label(), x + 9, y + 3, size, mark);
        suit(card.suit(), x + 37, y + 2, Math.min(size, 19), mark);
    }

    void ticket(float x, float y, float w, float h, String number, boolean active, boolean selected) {
        box(x + 1, y + 4, w, h, SHADE);
        border(x, y, w, h, selected ? GOLD : LINE, active ? PAPER : PANEL);
        center(number, x + w / 2, y + h * 0.30f, Math.min(h * 0.48f, 49), active ? INK : MUTED, true);
    }

    @Override
    public void dispose() {
        for (Texture pip : suits) pip.dispose();
        square.dispose();
        rounded.dispose();
        body.dispose();
        display.dispose();
        batch.dispose();
    }
}
