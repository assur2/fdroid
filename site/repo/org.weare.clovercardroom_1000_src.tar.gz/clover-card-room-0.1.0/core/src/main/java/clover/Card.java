package clover;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Random;
import java.util.Collections;

record Card(int suit, int rank) {
    static final int CLUBS = 0, DIAMONDS = 1, SPADES = 2, HEARTS = 3;
    static final String[] SUITS = {"Clubs", "Diamonds", "Spades", "Hearts"};
    static final Comparator<Card> ORDER = Comparator.comparingInt(Card::suit).thenComparingInt(Card::rank);

    String label() {
        return switch (rank) {
            case 11 -> "J";
            case 12 -> "Q";
            case 13 -> "K";
            case 14 -> "A";
            default -> Integer.toString(rank);
        };
    }

    boolean red() {
        return suit == DIAMONDS || suit == HEARTS;
    }

    static List<Card> deck(int firstRank, Random random) {
        List<Card> deck = new ArrayList<>();
        for (int suit = 0; suit < 4; suit++) {
            for (int rank = firstRank; rank <= 14; rank++) {
                deck.add(new Card(suit, rank));
            }
        }
        Collections.shuffle(deck, random);
        return deck;
    }

    static <T> T pop(List<T> cards) {
        return cards.remove(cards.size() - 1);
    }
}
