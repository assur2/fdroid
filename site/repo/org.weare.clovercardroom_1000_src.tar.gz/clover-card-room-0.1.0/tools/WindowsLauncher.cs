using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

internal static class WindowsLauncher
{
    [STAThread]
    private static int Main()
    {
        string home = AppDomain.CurrentDomain.BaseDirectory;
        try
        {
            var start = new ProcessStartInfo
            {
                FileName = Path.Combine(home, "runtime", "bin", "CloverCardRoomJava.exe"),
                Arguments = "-cp \"" + Path.Combine(home, "app", "*") + "\" clover.desktop.DesktopLauncher",
                WorkingDirectory = home,
                UseShellExecute = false,
                CreateNoWindow = true
            };
            using (Process game = Process.Start(start))
            {
                game.WaitForExit();
                return game.ExitCode;
            }
        }
        catch (Exception error)
        {
            MessageBox.Show(error.Message, "Clover Card Room", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }
}
