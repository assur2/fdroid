$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
$build = Join-Path $project 'desktop/build/install/desktop/lib'
$compiler = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$jlink = Join-Path $env:JAVA_HOME 'bin/jlink.exe'
$dist = Join-Path $project 'dist'
$scratch = Join-Path $project ".tooling/windows-$([Guid]::NewGuid().ToString('N').Substring(0, 8))"
$package = Join-Path $scratch 'CloverCardRoom'
$runtime = Join-Path $package 'runtime'
$app = Join-Path $package 'app'
$archive = Join-Path $scratch 'CloverCardRoom-Windows-x64.zip'

if (-not (Test-Path "$build/desktop.jar")) {
    throw 'Build :desktop:installDist before packaging.'
}
New-Item -ItemType Directory -Path $app, $dist -Force | Out-Null
Get-ChildItem $build -Filter '*.jar' |
    Where-Object Name -NotMatch '-natives-(linux|macos|windows-x86)' |
    Copy-Item -Destination $app

& $jlink --add-modules java.desktop,java.management,jdk.unsupported,jdk.crypto.ec --strip-debug --compress=2 --no-header-files --no-man-pages --output $runtime
if ($LASTEXITCODE -ne 0) { throw 'Could not bundle the Java runtime.' }
Rename-Item -LiteralPath "$runtime/bin/javaw.exe" -NewName 'CloverCardRoomJava.exe'

$icon = (Resolve-Path "$PSScriptRoot/clover.ico").Path
$source = (Resolve-Path "$PSScriptRoot/WindowsLauncher.cs").Path
$launcher = Join-Path $package 'CloverCardRoom.exe'
& $compiler /nologo /target:winexe /platform:x64 /reference:System.Windows.Forms.dll "/win32icon:$icon" "/out:$launcher" $source
if ($LASTEXITCODE -ne 0) { throw 'Could not compile the Windows launcher.' }

Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($package, $archive, [System.IO.Compression.CompressionLevel]::Optimal, $true)
Move-Item -LiteralPath $archive -Destination "$dist/CloverCardRoom-Windows-x64.zip" -Force
Write-Output $package
