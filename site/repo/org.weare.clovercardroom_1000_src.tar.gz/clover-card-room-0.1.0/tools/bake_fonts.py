"""Bake the two OFL typefaces into libGDX BitmapFont assets with Pillow."""

import argparse
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont


def bake(source, target, size):
    font = ImageFont.truetype(source, size)
    ascent, descent = font.getmetrics()
    characters = " " + "".join(chr(code) for code in range(33, 127)) + "éÉ"
    atlas = Image.new("RGBA", (512, 1024), (255, 255, 255, 0))
    painter = ImageDraw.Draw(atlas)
    x, y, row_height = 2, 2, 0
    glyphs = []
    for char in characters:
        left, top, right, bottom = font.getbbox(char, anchor="ls")
        width, height = right - left, bottom - top
        if x + width + 2 > atlas.width:
            x, y, row_height = 2, y + row_height + 4, 0
        painter.text((x - left, y - top), char, font=font, anchor="ls", fill="white")
        glyphs.append(
            f"char id={ord(char)} x={x} y={y} width={width} height={height} "
            f"xoffset={left} yoffset={ascent + top} xadvance={round(font.getlength(char))} page=0 chnl=15"
        )
        x += width + 4
        row_height = max(row_height, height)
    if y + row_height > atlas.height:
        raise ValueError("Font atlas is too small")
    height = 256
    while height < y + row_height + 2:
        height *= 2
    atlas.crop((0, 0, atlas.width, height)).save(target.with_suffix(".png"))
    target.with_suffix(".fnt").write_text(
        f'info face="{target.stem}" size={size} bold=0 italic=0 padding=0,0,0,0 spacing=1,1\n'
        f"common lineHeight={ascent + descent} base={ascent} scaleW={atlas.width} scaleH={height} pages=1 packed=0\n"
        f'page id=0 file="{target.name}.png"\nchars count={len(glyphs)}\n'
        + "\n".join(glyphs) + "\n",
        encoding="utf-8",
    )


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", type=Path)
    parser.add_argument("target", type=Path)
    parser.add_argument("size", type=int)
    args = parser.parse_args()
    bake(args.source, args.target, args.size)
