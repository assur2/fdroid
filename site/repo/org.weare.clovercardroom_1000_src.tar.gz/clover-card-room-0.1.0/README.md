# Clover Card Room

Clover Card Room is an offline libGDX card collection for Windows and Android. Both builds use the same Java rules and mouse or touch controls.

| Table | Rules |
| --- | --- |
| Poker | Fixed-limit five-card draw with three computer opponents and play chips |
| Hearts | Four seats, rotating three-card passes, shooting the moon, and a 100-point finish |
| Klaverjassen | Sixteen deals with a computer partner, Amsterdam trick rules, Utrecht-style compulsory trump choice, and automatic roem |
| Solitaire | Draw-one Klondike with automatic flips and undo |
| Switchyard | An original stockpile race against two computer opponents, with ascending and descending routes |

Open a table to see its **Rules**. **Tables** takes you to the menu and keeps your seat available to resume while the app is open. **Restart** offers a fresh match or deal.

## Play

- On 64-bit Windows, extract the entire Windows ZIP and open `CloverCardRoom.exe` inside the extracted folder. The package includes a Java runtime.
- On Android 7.0 or newer, add the [Weare Apps repository](https://assur2.github.io/fdroid/repo/) to F-Droid and install Clover Card Room.

## Build from source on Windows

Install a JDK 17 and Android SDK Platform 34 with Build Tools 34.0.0. Set `JAVA_HOME` to the JDK and `ANDROID_HOME` to the SDK.

```powershell
.\gradlew.bat :core:check :desktop:installDist :android:assembleDebug
```

The Gradle desktop launcher is at `desktop/build/install/desktop/bin/desktop.bat`. The APK is at `android/build/outputs/apk/debug/android-debug.apk`.

After the Gradle build, run `.\tools\package-windows.ps1` on 64-bit Windows to create the portable ZIP with the bundled runtime.

Run the trials for the five game engines with `.\gradlew.bat :core:verifyGames`.

The project uses [libGDX](https://libgdx.com/). The play and scoring rules for Klaverjassen follow the [Pagat rules reference](https://www.pagat.com/jass/klaverjassen.html). The Atkinson Hyperlegible and Fraunces bitmap fonts ship with their SIL Open Font License files in `assets/fonts`.

Clover Card Room source code is licensed under GPL-3.0-only. See [LICENSE](LICENSE).
