# Android emulator

Clover Card Room uses AVD `CloverCardRoom_Pixel` and console port `5570`.
Use `adb -s emulator-5570` for commands and the hidden desktop conventions from the workspace instructions.
