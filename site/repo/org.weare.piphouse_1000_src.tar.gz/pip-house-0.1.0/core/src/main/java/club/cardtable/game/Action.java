package club.cardtable.game;

public class Action {
    public final String id, label;
    public Action(String id, String label) {
        this.id = id;
        this.label = label;
    }
}
