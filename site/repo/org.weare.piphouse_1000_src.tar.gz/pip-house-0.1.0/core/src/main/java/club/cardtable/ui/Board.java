package club.cardtable.ui;

import club.cardtable.game.Tile;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Pixmap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.nio.ByteBuffer;

/** The table is painted once per interaction. Both platform launchers use these same pixels. */
public final class Board {
    public static final int W = 1280, H = 800;
    final Pixmap page = new Pixmap(W, H, Pixmap.Format.RGBA8888);
    final List<Hit> hits = new ArrayList<>();
    private final FileHandle assets;
    private final Map<String, Pixmap> images = new HashMap<>();
    private final Map<String, Typeface> fonts = new HashMap<>();
    private final Map<String, Pixmap> glyphCache = new HashMap<>();

    public Board(FileHandle assets) {
        this.assets = assets;
        page.setFilter(Pixmap.Filter.BiLinear);
        fonts.put("serif", new Typeface(assets.child("serif.metrics")));
        fonts.put("sans", new Typeface(assets.child("sans.metrics")));
    }

    static final class Hit {
        final int x,y,w,h;
        final String id;
        Hit(String id, int x, int y, int w, int h) {
            this.id=id; this.x=x; this.y=y; this.w=w; this.h=h;
        }
        boolean contains(int px, int py) {
            return x<=px && px<x+w && y<=py && py<y+h;
        }
    }
    public void target(String id, int x, int y, int w, int h) {
        if (id != null) hits.add(new Hit(id,x,y,w,h));
    }
    Hit at(int x, int y) {
        for (int i=hits.size()-1; i>=0; i--) if (hits.get(i).contains(x,y)) return hits.get(i);
        return null;
    }
    private static final class Typeface {
        final float base;
        final Map<Character,float[]> glyphs = new HashMap<>();
        Typeface(FileHandle file) {
            String[] lines=file.readString("UTF-8").trim().split("\\r?\\n");
            base=Float.parseFloat(lines[0]);
            for (int i=1; i<lines.length; i++) {
                String[] fields=lines[i].split(" ");
                float[] glyph=new float[7];
                for (int j=0;j<7;j++) glyph[j]=Float.parseFloat(fields[j+1]);
                glyphs.put((char)Integer.parseInt(fields[0]),glyph);
            }
        }
        float[] get(char c) {
            float[] value=glyphs.get(c);
            return value==null ? glyphs.get('?') : value;
        }
    }
    private Pixmap image(String name) {
        Pixmap pix=images.get(name);
        if (pix==null) {
            pix=new Pixmap(assets.child(name));
            images.put(name,pix);
        }
        return pix;
    }
    public void begin(int color) {
        hits.clear();
        page.setColor((color<<8)|255);
        page.fill();
    }
    public Pixmap pixels() { return page; }
    public void rect(int x,int y,int w,int h,int rgb) {
        if(w<=0 || h<=0) return;
        page.setColor((rgb<<8)|255); page.fillRectangle(x,y,w,h);
    }
    public void line(int x1,int y1,int x2,int y2,int rgb) {
        page.setColor((rgb<<8)|255); page.drawLine(x1,y1,x2,y2);
    }
    void edge(int x,int y,int w,int h,int rgb) {
        page.setColor((rgb<<8)|255); page.drawRectangle(x,y,w,h);
    }
    void rounded(int x,int y,int w,int h,int r,int rgb) {
        rect(x+r,y,w-r*2,h,rgb); rect(x,y+r,w,h-r*2,rgb);
        page.setColor((rgb<<8)|255);
        page.fillCircle(x+r,y+r,r); page.fillCircle(x+w-r-1,y+r,r);
        page.fillCircle(x+r,y+h-r-1,r); page.fillCircle(x+w-r-1,y+h-r-1,r);
    }
    public int width(String value,int size,String font) {
        Typeface face=fonts.get(font); float result=0;
        for(int i=0;i<value.length();i++) result+=face.get(value.charAt(i))[6];
        return Math.round(result * size / face.base);
    }
    public void text(String value,int x,int baseline,int size,String font,String color) {
        Typeface face=fonts.get(font);
        float pen=x, scale=size/face.base;
        for(int i=0;i<value.length();i++) {
            char character=value.charAt(i);
            float[] g=face.get(character);
            if(character!=' ') {
                String key=font+":"+color+":"+size+":"+character;
                Pixmap glyph=glyphCache.get(key);
                if(glyph==null) {
                    glyph=sampleGlyph(image(font+"-paper.png"),g,scale,color);
                    glyphCache.put(key,glyph);
                }
                page.drawPixmap(glyph,Math.round(pen+g[4]*scale),Math.round(baseline+g[5]*scale));
            }
            pen+=g[6]*scale;
        }
    }
    // Area filtering keeps the hairlines of small print legible at every table size.
    private Pixmap sampleGlyph(Pixmap atlas,float[] g,float scale,String color) {
        int sw=(int)g[2],sh=(int)g[3];
        int w=Math.max(1,Math.round(sw*scale)),h=Math.max(1,Math.round(sh*scale));
        Pixmap result=new Pixmap(w,h,Pixmap.Format.RGBA8888);
        int rgb;
        switch(color) {
            case "paper":rgb=0xFFF4DD;break;
            case "soft":rgb=0x597062;break;
            case "mint":rgb=0xB2CEB8;break;
            case "gold":rgb=0xF4C66D;break;
            case "red":rgb=0xB54432;break;
            default:rgb=0x1B332D;
        }
        ByteBuffer source=atlas.getPixels(),target=result.getPixels();
        for(int y=0;y<h;y++) for(int x=0;x<w;x++) {
            double left=x*(double)sw/w,right=(x+1)*(double)sw/w;
            double top=y*(double)sh/h,bottom=(y+1)*(double)sh/h;
            double alpha=0;
            for(int sy=(int)top;sy<Math.min(sh,Math.ceil(bottom));sy++) {
                double dy=Math.min(bottom,sy+1)-Math.max(top,sy);
                for(int sx=(int)left;sx<Math.min(sw,Math.ceil(right));sx++) {
                    int offset=(((int)g[1]+sy)*atlas.getWidth()+(int)g[0]+sx)*4+3;
                    alpha+=(source.get(offset)&255)*dy*(Math.min(right,sx+1)-Math.max(left,sx));
                }
            }
            target.put((byte)(rgb>>16)).put((byte)(rgb>>8)).put((byte)rgb)
                  .put((byte)Math.round(alpha/((right-left)*(bottom-top))));
        }
        target.rewind();
        return result;
    }
    public void center(String value,int xCenter,int baseline,int size,String font,String color) {
        text(value,xCenter-width(value,size,font)/2,baseline,size,font,color);
    }
    void right(String value,int right,int baseline,int size,String font,String color) {
        text(value,right-width(value,size,font),baseline,size,font,color);
    }
    int wrap(String value,int x,int y,int maxWidth,int size,int leading,String color) {
        for(String paragraph : value.split("\\n\\s*\\n")) {
            StringBuilder current=new StringBuilder();
            for(String word : paragraph.trim().split("\\s+")) {
                String candidate=current.length()==0?word:current+" "+word;
                if(current.length()>0 && width(candidate,size,"sans")>maxWidth) {
                    text(current.toString(),x,y,size,"sans",color);
                    current.setLength(0); y+=leading;
                }
                if(current.length()>0) current.append(' ');
                current.append(word);
            }
            if(current.length()>0) { text(current.toString(),x,y,size,"sans",color); y+=leading; }
            y+=leading/2;
        }
        return y;
    }
    void picture(String file,int x,int y,int w,int h) {
        Pixmap pix=image(file);
        page.drawPixmap(pix,0,0,pix.getWidth(),pix.getHeight(),x,y,w,h);
    }
    void cover(String file,int x,int y,int w,int h,float anchorY) {
        Pixmap pix=image(file);
        float scale=Math.max(w/(float)pix.getWidth(),h/(float)pix.getHeight());
        int sw=Math.min(pix.getWidth(),Math.round(w/scale)), sh=Math.min(pix.getHeight(),Math.round(h/scale));
        page.drawPixmap(pix,(pix.getWidth()-sw)/2,Math.round((pix.getHeight()-sh)*anchorY),sw,sh,x,y,w,h);
    }
    public void suit(char suit,String color,int x,int y,int size) {
        picture("suit-"+suit+"-"+color+".png",x,y,size,size);
    }
    void arrow(int x,int y,int size,int color) {
        for (int d=0;d<2;d++) {
            line(x,y+d,x+size,y+d,color);
            line(x+size/2,y-size/2+d,x+size,y+d,color);
            line(x+size/2,y+size/2+d,x+size,y+d,color);
        }
    }
    public void card(Tile tile,int x,int y,int w,int h) {
        if(tile.selected) rounded(x-3,y-3,w+6,h+6,6,0xF4C66D);
        String f=tile.face;
        if(f.equals("empty")) {
            rounded(x,y,w,h,4,0x507868);
            rounded(x+2,y+2,w-4,h-4,3,0x254B3C);
            if(tile.note.matches("[0-9]+")) center(tile.note,x+w/2,y+h/2+w/6,w/2,"serif","mint");
            else {int m=Math.max(4,w/10); line(x+w/2-m,y+h/2,x+w/2+m,y+h/2,0x70937B);
                line(x+w/2,y+h/2-m,x+w/2,y+h/2+m,0x70937B);}
        } else if(f.equals("back")) {
            rounded(x+1,y+2,w,h,4,0x122F26);
            rounded(x,y,w,h,4,0xECE0C3);
            picture("back.png",x+2,y+2,w-4,h-4);
        } else if(f.matches("[0-9]+|wild")) {
            int color=f.equals("wild")?0x70577E: new int[]{0x365F83,0xB74C36,0x39816B}[(Integer.parseInt(f)-1)/4];
            rounded(x+1,y+2,w,h,4,0x17352D); rounded(x,y,w,h,4,0xF8EFD7);
            rounded(x+3,y+3,w-6,h-6,2,color);
            String mark=f.equals("wild")?"W":f;
            center(mark,x+w/2,y+h/2+Math.round(w*0.19f),Math.round(w*.65f),"serif","paper");
            text(mark,x+5,y+Math.max(12,w/5),Math.max(10,w/5),"sans","paper");
            if(f.equals("wild") && w>=50) center("WILD",x+w/2,y+h-7,11,"sans","paper");
        } else {
            rounded(x+1,y+2,w,h,4,0x14362B);
            rounded(x,y,w,h,4,0xFFF5DE);
            char symbol=f.charAt(f.length()-1);
            String rank=f.substring(0,f.length()-1);
            String color=(symbol=='H'||symbol=='D')?"red":"ink";
            int idx=Math.max(11,Math.round(w*.29f)), idxSuit=Math.max(6,w/7);
            text(rank,x+4,y+idx,idx,"serif",color);
            suit(symbol,color,x+5+w/40,y+idx+2,idxSuit);
            if(w>=48 && (rank.equals("K")||rank.equals("Q")||rank.equals("J"))) {
                int pw=Math.round(w*.63f), ph=Math.min(h-10,Math.round(pw*1.37f));
                cover(rank+".jpg",x+w-pw-5,y+(h-ph)/2,pw,ph,.5f);
            } else if (rank.equals("A") || w<43) {
                int s=(int)(w*.44f); suit(symbol,color,x+(w-s)/2,y+(h-s)/2+2,s);
            } else {
                drawPips(rank,symbol,color,x,y,w,h);
            }
        }
        target(tile.id==null?null:"move:"+tile.id,x,y,w,h);
    }
    private void drawPips(String rank,char symbol,String color,int x,int y,int w,int h) {
        int n;
        try { n=Integer.parseInt(rank); } catch(NumberFormatException ex) { n=1; }
        int pip=Math.max(7,(int)(w*.22f));
        if(n<=3) {
            for(int i=0;i<n;i++) {
                float v=n==1?.5f:.22f+.56f*i/(n-1);
                suit(symbol,color,x+w/2-pip/2,y+Math.round(h*v)-pip/2,pip);
            }
            return;
        }
        int pairs=n>=8?4:n>=6?3:2;
        for(int j=0;j<pairs;j++) {
            int yy=y+Math.round(h*(.19f+.62f*j/(pairs-1)))-pip/2;
            for(float fx:new float[]{.41f,.76f}) suit(symbol,color,x+Math.round(w*fx)-pip/2,yy,pip);
        }
        int extra=n-pairs*2;
        for(int i=0;i<extra;i++) {
            float fy=n==7?.345f:extra==1?.5f:.34f+i*.32f;
            suit(symbol,color,x+Math.round(w*.585f)-pip/2,y+Math.round(h*fy)-pip/2,pip);
        }
    }
    public void dispose() {
        page.dispose();
        for(Pixmap p:images.values()) p.dispose();
        for(Pixmap p:glyphCache.values()) p.dispose();
    }
}
