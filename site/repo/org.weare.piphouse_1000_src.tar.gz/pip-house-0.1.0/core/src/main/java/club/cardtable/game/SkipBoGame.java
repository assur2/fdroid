package club.cardtable.game;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/** Two-player Skip-Bo. A zero is a physical wild card, including in the recycle pile. */
public final class SkipBoGame implements Game {
    private static final int HUMAN = 0;
    private static final int COMPUTER = 1;
    private static final int STOCK = 5;
    private static final int DISCARD = 6;
    private static final int BLOCKED = 2;
    private static final int NO_CARD = -1;
    private final Random random;
    private final Player[] players = {new Player(), new Player()};
    private final List<List<Integer>> builds = fourPiles();
    private final List<Integer> deck = new ArrayList<>();
    private final List<Integer> recycle = new ArrayList<>();
    private int selected;
    private int result;
    private int turn;
    private String message;
    private int deals;

    private static List<List<Integer>> fourPiles() {
        List<List<Integer>> piles = new ArrayList<>();
        for (int i = 0; i < 4; i++) piles.add(new ArrayList<Integer>());
        return piles;
    }

    private static final class Player {
        final List<Integer> hand = new ArrayList<>();
        final List<Integer> stock = new ArrayList<>();
        final List<List<Integer>> discards = fourPiles();

        int card(int source) {
            if (source == STOCK) return top(stock);
            if (source >= DISCARD && source < DISCARD + 4) return top(discards.get(source - DISCARD));
            return source >= 0 && source < hand.size() ? hand.get(source) : NO_CARD;
        }

        int take(int source) {
            if (source == STOCK) return pop(stock);
            if (source >= DISCARD) return pop(discards.get(source - DISCARD));
            return hand.remove(source);
        }

        void clear() {
            hand.clear(); stock.clear();
            for (List<Integer> pile : discards) pile.clear();
        }
    }

    public SkipBoGame(long seed) {
        random = new Random(seed);
        deal();
    }

    private static int top(List<Integer> cards) { return cards.isEmpty() ? NO_CARD : cards.get(cards.size() - 1); }
    private static int pop(List<Integer> cards) { return cards.remove(cards.size() - 1); }

    private void deal() {
        deck.clear(); recycle.clear();
        for (List<Integer> pile : builds) pile.clear();
        for (Player player : players) player.clear();
        for (int copy = 0; copy < 12; copy++) {
            for (int rank = 1; rank <= 12; rank++) deck.add(rank);
        }
        for (int copy = 0; copy < 18; copy++) deck.add(0);
        Collections.shuffle(deck, random);
        for (int i = 0; i < 30; i++) {
            for (Player player : players) player.stock.add(pop(deck));
        }
        selected = -1;
        result = -1;
        turn = 1;
        message = "Choose a card to build, or discard to end your turn.";
        if (deals++ % 2 == 1) computerTurn();
        refill(players[HUMAN]);
    }

    private void refill(Player player) {
        while (player.hand.size() < 5) {
            if (deck.isEmpty()) {
                if (recycle.isEmpty()) break;
                deck.addAll(recycle);
                recycle.clear();
                Collections.shuffle(deck, random);
            }
            player.hand.add(pop(deck));
        }
    }

    private boolean fits(int card, int target) {
        return card == 0 || card == builds.get(target).size() + 1;
    }

    private void play(int who, int source, int target) {
        Player player = players[who];
        List<Integer> stack = builds.get(target);
        stack.add(player.take(source));
        if (stack.size() == 12) {
            recycle.addAll(stack);
            stack.clear();
        }
        if (player.stock.isEmpty()) {
            result = who;
            message = who == HUMAN ? "You cleared your stock first. You win!" : "Robin cleared the last stock card and wins.";
        } else if (source < STOCK && player.hand.isEmpty()) {
            refill(player);
        }
    }

    private void pick(int source) {
        Player human = players[HUMAN];
        if (human.card(source) == NO_CARD) return;
        if (selected == source) {
            selected = -1;
            message = "Selection cleared.";
            return;
        }
        selected = source;
        message = source < STOCK ? "Choose a build pile, or a discard pile to end your turn." : "Choose a build pile for this card.";
    }

    private void build(int target) {
        if (selected < 0) {
            message = "Select a card from your stock, hand or discard piles first.";
            return;
        }
        if (!fits(players[HUMAN].card(selected), target)) {
            message = "This pile needs " + (builds.get(target).size() + 1) + " or a wild.";
            return;
        }
        play(HUMAN, selected, target);
        selected = -1;
        if (result < 0) message = "Play another card or discard to end your turn.";
    }

    private void discard(int target) {
        if (selected < 0 || selected >= STOCK) {
            pick(DISCARD + target);
            return;
        }
        Player human = players[HUMAN];
        human.discards.get(target).add(human.take(selected));
        endTurn();
    }

    private void endTurn() {
        selected = -1;
        computerTurn();
        if (result >= 0) return;
        turn++;
        refill(players[HUMAN]);
        if (bothBlocked()) {
            result = BLOCKED;
            message = "The draw pile is empty and neither player can move. Deal again.";
        }
    }

    private boolean bothBlocked() {
        if (!deck.isEmpty() || !recycle.isEmpty()) return false;
        for (Player player : players) {
            if (!player.hand.isEmpty()) return false;
            for (int source = STOCK; source < DISCARD + 4; source++) {
                for (int target = 0; target < 4; target++) if (fits(player.card(source), target)) return false;
            }
        }
        return true;
    }

    // Prefer immediately shedding stock, then cards that bring the next needed stock rank closer.
    private int valueOfPlay(Player player, int source, int target) {
        int card = player.card(source);
        int next = builds.get(target).size() + 1;
        int after = next % 12 + 1;
        int value = source == STOCK ? 1000 : (source >= DISCARD ? 14 : 10);
        if (source != STOCK && card == 0) value -= 8;
        if (source != STOCK && top(player.stock) == after) value += 70;
        if (player.hand.size() == 1 && source < STOCK) value += 45;
        for (int candidate : player.hand) if (candidate == after) { value += 8; break; }
        if (next == 12) value += 3;
        return value;
    }

    private int[] bestPlay(Player player) {
        int best = Integer.MIN_VALUE;
        int[] choice = null;
        for (int source = 0; source < DISCARD + 4; source++) {
            int card = player.card(source);
            if (card == NO_CARD) continue;
            for (int target = 0; target < 4; target++) {
                if (!fits(card, target)) continue;
                int score = valueOfPlay(player, source, target);
                if (score > best) { best = score; choice = new int[]{source, target}; }
            }
        }
        return choice;
    }

    private void computerDiscard(Player player) {
        int best = Integer.MIN_VALUE, index = 0, target = 0;
        for (int i = 0; i < player.hand.size(); i++) {
            int card = player.hand.get(i);
            for (int t = 0; t < 4; t++) {
                int existing = top(player.discards.get(t));
                int value = card;
                if (existing == card + 1) value += 100;
                else if (existing == card) value += 60;
                else if (existing == NO_CARD) value += 40;
                else if (existing > card) value += 15 - (existing - card);
                if (card == 0) value -= 100;
                if (value > best) { best = value; index = i; target = t; }
            }
        }
        player.discards.get(target).add(player.hand.remove(index));
    }

    private void computerTurn() {
        Player bot = players[COMPUTER];
        refill(bot);
        int count = 0;
        int[] choice;
        while ((choice = bestPlay(bot)) != null) {
            play(COMPUTER, choice[0], choice[1]);
            if (result >= 0) return;
            count++;
        }
        if (!bot.hand.isEmpty()) computerDiscard(bot);
        message = "Robin played " + count + (count == 1 ? " card. " : " cards. ") + "Your turn.";
    }

    private static String face(int card) {
        if (card == NO_CARD) return "empty";
        return card == 0 ? "wild" : Integer.toString(card);
    }

    @Override public View view() {
        View v = new View();
        Player human = players[HUMAN], bot = players[COMPUTER];
        v.phase = result < 0 ? "Your turn" : (result == BLOCKED ? "Draw" : "Game over");
        v.score = "Turn " + turn + "  ·  " + deck.size() + " in draw pile";
        v.status = message;
        Group opponent = v.group("Robin", "seat");
        opponent.note = bot.stock.size() + " in stock  ·  " + bot.hand.size() + " in hand";
        opponent.add(face(top(bot.stock)), null).note = "Stock";
        for (int i = 0; i < 4; i++) opponent.add(face(top(bot.discards.get(i))), null).note = "Discard " + (i + 1);
        for (int i = 0; i < 4; i++) {
            List<Integer> stack = builds.get(i);
            Group group = v.group("Build " + (i + 1), "build");
            group.note = "Next " + (stack.size() + 1);
            Tile tile = group.add(stack.isEmpty() ? "empty" : String.valueOf(stack.size()), "build/" + i);
            tile.note = String.valueOf(stack.size() + 1);
        }
        Group stock = v.group("Stock · " + human.stock.size(), "reserve");
        stock.add(face(top(human.stock)), "pick/" + STOCK).selected = selected == STOCK;
        for (int i = 0; i < 4; i++) {
            Group group = v.group("Discard " + (i + 1), "reserve");
            group.add(face(top(human.discards.get(i))), "discard/" + i).selected = selected == DISCARD + i;
        }
        Group hand = v.group("Your hand", "hand");
        for (int i = 0; i < human.hand.size(); i++) hand.add(face(human.hand.get(i)), "pick/" + i).selected = selected == i;
        if (result >= 0) v.action("deal", "Play again");
        else if (human.hand.isEmpty()) v.action("pass", "End turn");
        return v;
    }

    @Override public void act(String id) {
        if (id == null) return;
        if (result >= 0) { if (id.equals("deal")) deal(); return; }
        if (id.equals("pass") && players[HUMAN].hand.isEmpty()) { endTurn(); return; }
        String[] parts = id.split("/");
        if (parts.length != 2) return;
        try {
            int index = Integer.parseInt(parts[1]);
            if (parts[0].equals("pick") && index >= 0 && index <= STOCK) pick(index);
            else if (parts[0].equals("build") && index >= 0 && index < 4) build(index);
            else if (parts[0].equals("discard") && index >= 0 && index < 4) discard(index);
        } catch (NumberFormatException ignored) { }
    }

    @Override public String rules() {
        return "Race Robin to empty your 30-card stock. Both players share four build piles. Start each pile with a 1, then add numbers in order through 12. A wild takes the required number. Completed piles clear for reuse.\n\n"
                + "Select your exposed stock card, a card in your hand, or the top of one of your four discard piles. Tap a build pile to play it. Play as many cards as you like. If you play your entire hand, draw back to five immediately.\n\n"
                + "To end your turn, select a hand card and tap one of your discard piles. A discard can go on any number. Your next turn starts with a refill to five. The first empty stock wins.";
    }
}
