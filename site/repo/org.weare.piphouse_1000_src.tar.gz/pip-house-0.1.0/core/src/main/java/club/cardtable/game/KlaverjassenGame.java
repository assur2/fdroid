package club.cardtable.game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public final class KlaverjassenGame extends TrickGame {
    // Tables are indexed in natural sequence from seven through ace.
    private static final int[] PLAIN_ORDER = { 0, 1, 2, 6, 3, 4, 5, 7 };
    private static final int[] TRUMP_ORDER = { 0, 1, 6, 4, 7, 2, 3, 5 };
    private static final int[] PLAIN_POINTS = { 0, 0, 0, 10, 2, 3, 4, 11 };
    private static final int[] TRUMP_POINTS = { 0, 0, 14, 10, 20, 3, 4, 11 };
    private static final int MATCH_LENGTH = 16;
    private final int[] totals = new int[2], earned = new int[2], tricks = new int[2];
    private int first, bidder, declarer, passes, trump;

    public KlaverjassenGame(long seed) {
        super(seed);
        deal();
    }

    @Override void deal() {
        dealCards(7);
        Arrays.fill(earned, 0);
        Arrays.fill(tricks, 0);
        first = (dealNumber - 1) % 4;
        passes = 0;
        trump = declarer = -1;
        bidder = first;
        stage = Stage.BID;
        botBids();
    }

    private void accept(int suit) {
        declarer = bidder;
        trump = suit;
        startTrick(first);
    }

    private void pass() {
        passes++;
        bidder = (bidder + 1) % 4;
    }

    private void botBids() {
        while (stage == Stage.BID && bidder != 0) {
            int best = 0, bestScore = Integer.MIN_VALUE;
            for (int suit = 0; suit < 4; suit++) {
                int score = 0;
                for (int c : hands.get(bidder)) {
                    if (suit(c) == suit) score += 5 + TRUMP_POINTS[rank(c) - 7];
                    else if (rank(c) == 14) score += 6;
                }
                if (score > bestScore) { best = suit; bestScore = score; }
            }
            if (passes == 4 || bestScore >= 47) accept(best);
            else pass();
        }
    }

    @Override public void act(String id) {
        if (stage != Stage.BID) { handlePlay(id); return; }
        if ("pass".equals(id) && passes < 4) { pass(); botBids(); return; }
        for (int suit = 0; suit < 4; suit++) {
            if (bidId(suit).equals(id)) { accept(suit); return; }
        }
    }

    private String bidId(int suit) { return "bid-" + "CDSH".charAt(suit); }

    private int power(int card) {
        int[] order = suit(card) == trump ? TRUMP_ORDER : PLAIN_ORDER;
        return order[rank(card) - 7];
    }

    private int points(int card) {
        int[] table = suit(card) == trump ? TRUMP_POINTS : PLAIN_POINTS;
        return table[rank(card) - 7];
    }

    @Override int strength(int card, int led) {
        if (suit(card) == trump) return 20 + power(card);
        return suit(card) == led ? 10 + power(card) : 0;
    }

    @Override List<Integer> legal(int player) {
        List<Integer> hand = hands.get(player);
        if (trick.isEmpty()) return hand;
        int led = suit(trick.get(0));
        List<Integer> matching = ofSuit(hand, led);
        if (led != trump && !matching.isEmpty()) return matching;

        int best = winningIndex(), high = trick.get(best);
        boolean partnerWinning = (leader + best + 2) % 4 == player;
        List<Integer> goodTrumps = new ArrayList<>(), discards = new ArrayList<>();
        for (int card : hand) {
            if (suit(card) != trump) discards.add(card);
            else if (suit(high) != trump || power(card) > power(high)) goodTrumps.add(card);
        }
        if (led == trump) {
            if (!goodTrumps.isEmpty()) return goodTrumps;
            return matching.isEmpty() ? hand : matching;
        }
        if (partnerWinning) {
            // It is optional to overtake partner. An avoidable undertrump is still illegal.
            discards.addAll(goodTrumps);
            return discards.isEmpty() ? hand : discards;
        }
        if (!goodTrumps.isEmpty()) return goodTrumps;
        return discards.isEmpty() ? hand : discards;
    }

    private boolean topOfSuit(int player, int card) {
        List<Integer> hand = hands.get(player);
        int suit = suit(card);
        for (int rank = 7; rank <= 14; rank++) {
            int other = suit * 13 + rank - 2;
            if (!seen[other] && !hand.contains(other) && power(other) > power(card)) return false;
        }
        return true;
    }

    @Override int chooseCard(int player, List<Integer> options) {
        int best = options.get(0), bestScore = Integer.MIN_VALUE;
        int leadingCard = trick.isEmpty() ? -1 : trick.get(winningIndex());
        boolean partnerWinning = !trick.isEmpty() && (leader + winningIndex() + 2) % 4 == player;
        for (int card : options) {
            int value = points(card);
            int score;
            if (trick.isEmpty()) {
                boolean top = topOfSuit(player, card);
                boolean drawTrump = (player % 2 == declarer % 2) && countSuit(player, trump) > 1;
                score = (top ? 26 + value : -value) - countSuit(player, suit(card));
                if (suit(card) == trump) score += drawTrump && top ? 20 : -16;
            } else {
                int led = suit(trick.get(0));
                boolean takes = strength(card, led) > strength(leadingCard, led);
                if (partnerWinning) {
                    boolean safe = trick.size() == 3 || topOfSuit(player, leadingCard);
                    score = takes ? 8 - power(card) : 16 + (safe ? value : -value);
                } else if (takes) {
                    score = 25 + (trick.size() == 3 ? -power(card) : power(card));
                } else {
                    score = -3 * value - power(card);
                }
                if (suit(card) == trump && led != trump && !takes) score -= 10;
            }
            if (score > bestScore) { bestScore = score; best = card; }
        }
        return best;
    }

    private int roem() {
        int rank = rank(trick.get(0));
        boolean alike = true;
        boolean[][] held = new boolean[4][15];
        for (int card : trick) {
            if (rank(card) != rank) alike = false;
            held[suit(card)][rank(card)] = true;
        }
        if (alike) return 100;
        int result = held[trump][12] && held[trump][13] ? 20 : 0;
        for (int suit = 0; suit < 4; suit++) {
            int run = 0, longest = 0;
            for (int r = 7; r <= 14; r++) {
                run = held[suit][r] ? run + 1 : 0;
                longest = Math.max(longest, run);
            }
            if (longest == 4) result += 50;
            else if (longest == 3) result += 20;
        }
        return result;
    }

    @Override void award(int winner) {
        int team = winner % 2, meld = roem(), total = meld;
        for (int card : trick) total += points(card);
        if (tricksWon == 8) total += 10;
        earned[team] += total;
        tricks[team]++;
        message = won(winner) + " " + total + (total == 1 ? " point." : " points.");
        if (meld > 0) message += " Includes " + meld + " roem.";
        if (tricksWon != 8) return;

        int makers = declarer % 2, defenders = 1 - makers;
        String outcome;
        if (tricks[makers] == 8) {
            earned[makers] += 100;
            outcome = "Pit! All eight tricks.";
        } else if (earned[makers] <= earned[defenders]) {
            earned[defenders] += earned[makers];
            earned[makers] = 0;
            outcome = makers == 0 ? "Nat! Your contract fell." : "Nat! Their contract fell.";
        } else {
            outcome = makers == 0 ? "Your team made its contract." : "Their team made its contract.";
        }
        for (int i = 0; i < 2; i++) totals[i] += earned[i];
        message = outcome + "  Us " + earned[0] + " / Them " + earned[1] + ".";
        stage = Stage.DEAL;
        if (dealNumber == MATCH_LENGTH) {
            stage = Stage.MATCH;
            if (totals[0] == totals[1]) message = "The match is tied.";
            else message = totals[0] > totals[1] ? "You and North win the match." : "West and East win the match.";
        }
    }

    @Override void resetScores() { Arrays.fill(totals, 0); }

    @Override public View view() {
        View v = new View();
        v.phase = stage == Stage.BID ? "Choose trump" : phase(8);
        v.score = "Us " + totals[0] + "  /  Them " + totals[1] + "   |   Deal " + dealNumber + " of " + MATCH_LENGTH;
        if (stage == Stage.BID) {
            v.status = passes == 4 ? "Everyone passed. Choose a trump suit." : "Call a trump suit for your team, or pass.";
            for (int suit = 0; suit < 4; suit++) v.action(bidId(suit), SUITS[suit]);
            if (passes < 4) v.action("pass", "Pass");
        } else {
            String contract = SUITS[trump] + " trump";
            if (stage == Stage.PLAY) v.status = contract + "  /  " + playPrompt();
            else v.status = message;
            if (stage == Stage.PLAY || stage == Stage.TRICK) {
                v.phase = phase(8) + "  /  " + contract;
                if (stage == Stage.PLAY) v.status = playPrompt();
            }
        }
        for (int p = 1; p < 4; p++) {
            String note = p == 2 ? "Your partner" : "Opponent";
            if (p == declarer) note += "  /  Called trump";
            seat(v, p, note);
        }
        board(v, playable(), Collections.<Integer>emptySet(), "Your hand  /  Us " + earned[0] + " - Them " + earned[1]);
        playButtons(v);
        return v;
    }

    @Override public String rules() {
        return "You and North play West and East over 16 deals. Choose trump or pass. If all pass, the first bidder must choose.\n\n"
                + "Follow suit. On a trump lead, beat the highest trump if possible. "
                + "When void, trump or overtrump if an opponent leads the trick. You may discard if your partner is winning. "
                + "Undertrump only when forced. Trumps rank J, 9, A, 10, K, Q, 8, 7. Other suits rank A, 10, K, Q, J, 9, 8, 7.\n\n"
                + "A, 10, K, Q and J score 11, 10, 4, 3 and 2. Trump J scores 20 and trump 9 scores 14. The last trick adds 10. "
                + "Roem adds 20 or 50 for a suited run of three or four, 100 for four equal ranks, and 20 for trump K-Q. "
                + "The callers must outscore the defenders or surrender all points. Taking all eight as callers adds 100.";
    }
}
