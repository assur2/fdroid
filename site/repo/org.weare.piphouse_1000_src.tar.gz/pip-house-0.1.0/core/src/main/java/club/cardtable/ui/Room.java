package club.cardtable.ui;

import club.cardtable.game.*;
import java.util.Locale;
import java.util.Random;

/** Navigation and session state are independent of the platform window. */
public final class Room {
    public interface Store {
        String get(String key);
        void put(String key,String value);
    }

    static final String[] NAMES={"Poker","Hearts","Klaverjassen","Solitaire","Skip-Bo"};
    static final String[] STYLES={"No-limit Texas Hold’em","Trick avoidance","Amsterdam rules","Draw-one Klondike","Stockpile race"};
    static final String[] COUNTS={"4 players","4 players","2 vs 2","Solo","2 players"};
    static final String[] ART={"poker","hearts","klaverjassen","solitaire","skipbo"};
    static final int PAPER=0xF5F0E4, INK=0x1B332D, HAIR=0xC8C8B8, GREEN=0x163E31, GOLD=0xF4C66D;
    private final Board board;
    private final Store store;
    private final Random seeds;
    private final Game[] games=new Game[5];
    private final long[] gameSeeds=new long[5];
    private final StringBuilder[] logs=new StringBuilder[5];
    private int table=-1, guide=-1;
    private boolean confirmNew;
    private int focus=-1;
    private String hovered;
    private int hoverX=-1,hoverY=-1;

    public Room(Board board, Store store, long seed) {
        this.board=board; this.store=store; this.seeds=new Random(seed);
    }
    public Game currentGame() { return table<0?null:games[table]; }
    private static Game make(int i,long seed) {
        switch(i) {
            case 0:return new PokerGame(seed);
            case 1:return new HeartsGame(seed);
            case 2:return new KlaverjassenGame(seed);
            case 3:return new SolitaireGame(seed);
            case 4:return new SkipBoGame(seed);
            default:throw new IllegalArgumentException("Unknown game");
        }
    }
    private void reset(int i,long seed) {
        gameSeeds[i]=seed; games[i]=make(i,seed); logs[i]=new StringBuilder();
    }
    private void save() {
        store.put("table-v1-"+table,gameSeeds[table]+"\n"+logs[table]);
    }
    private boolean played(int i) {
        return games[i]!=null || !store.get("table-v1-"+i).isEmpty();
    }
    private void enter(int i) {
        table=i;
        if(games[i]!=null) return;
        String saved=store.get("table-v1-"+i);
        if(!saved.isEmpty()) {
            int split=saved.indexOf('\n');
            try {
                if(split<0) throw new IllegalArgumentException();
                reset(i,Long.parseLong(saved.substring(0,split)));
                String moves=saved.substring(split+1);
                if(!moves.isEmpty()) {
                    for(String id:moves.split("\n")) if(!id.isEmpty()) games[i].act(id);
                    logs[i].append(moves);
                }
                return;
            } catch(RuntimeException invalidSave) {
                // A fresh seed recovers from a truncated or incompatible local save.
            }
        }
        reset(i,seeds.nextLong()); save();
    }
    public boolean back() {
        focus=-1; hovered=null;
        if(confirmNew) {confirmNew=false; return true;}
        if(guide>=0) {guide=-1; return true;}
        if(table>=0) {table=-1; return true;}
        return false;
    }
    public void activate(String id) {
        focus=-1; hovered=null;
        if(id==null) return;
        if(id.equals("home")) {guide=-1;table=-1;confirmNew=false;return;}
        if(id.equals("help")) {guide=table<0?0:table;return;}
        if(id.equals("close")) {guide=-1;confirmNew=false;return;}
        if(id.equals("new")) { confirmNew=true;return; }
        if(id.equals("reset") && table>=0) {reset(table,seeds.nextLong());save();confirmNew=false;return;}
        if(id.startsWith("open:")) {guide=-1;enter(Integer.parseInt(id.substring(5)));return;}
        if(id.startsWith("rules:")) {guide=Integer.parseInt(id.substring(6));return;}
        if(table>=0 && id.startsWith("move:")) {
            String move=id.substring(5);
            games[table].act(move); logs[table].append(move).append('\n'); save();
        }
    }
    public String hitAt(int x,int y) {
        Board.Hit hit=board.at(x,y); return hit==null?null:hit.id;
    }
    public boolean hover(int x,int y) {
        String next=hitAt(x,y);
        boolean changed=!(next==null?hovered==null:next.equals(hovered));
        hoverX=x; hoverY=y; hovered=next; focus=-1;
        return changed;
    }
    public void tab(boolean reverse) {
        int n=board.hits.size();
        if(n>0) focus=focus<0?(reverse?n-1:0):(focus+n+(reverse?-1:1))%n;
        hovered=null;
    }
    public void enterFocused() {
        if(focus>=0 && focus<board.hits.size()) activate(board.hits.get(focus).id);
    }
    public void paint() {
        board.begin(PAPER);
        header();
        if(guide>=0) guide();
        else if(table<0) library();
        else if(confirmNew) confirmation();
        else play();
        Board.Hit active=null;
        if(focus>=0 && focus<board.hits.size()) active=board.hits.get(focus);
        else if(hovered!=null) {
            Board.Hit hit=board.at(hoverX,hoverY);
            if(hit!=null && hovered.equals(hit.id)) active=hit;
        }
        if(active!=null) {
            board.edge(active.x,active.y,active.w,active.h,0xBA882D);
            board.edge(active.x+1,active.y+1,active.w-2,active.h-2,0xBA882D);
        }
    }
    private void header() {
        Board b=board;
        b.picture("icon.png",56,18,40,40);
        b.text("Pip House",107,49,34,"serif","ink");
        b.target("home",52,10,224,56);
        int x=884;
        b.text("Game room",x,44,18,"sans","ink");
        if(guide<0 && table<0) b.rect(x,53,95,2,INK);
        b.target("home",x-12,10,124,55);
        b.line(1027,26,1027,47,HAIR);
        book(1068,29);
        b.text("How to play",1099,44,18,"sans","ink");
        b.target("help",1050,10,176,55);
        b.line(56,75,1223,75,HAIR);
    }
    private void book(int x,int y) {
        Board b=board;
        b.edge(x,y,11,15,INK);b.edge(x+10,y,11,15,INK);
        b.line(x+2,y+3,x+7,y+3,INK); b.line(x+13,y+3,x+18,y+3,INK);
    }
    private void button(String id,String label,int x,int y,int w,int h,boolean primary,boolean arrow) {
        Board b=board;
        if(primary) b.rounded(x,y,w,h,4,GOLD);
        else { b.rounded(x,y,w,h,4,0xB7BCAA); b.rounded(x+1,y+1,w-2,h-2,3,PAPER); }
        int size=18, tw=b.width(label,size,"sans"), total=tw+(arrow?30:0);
        int start=x+(w-total)/2;
        b.text(label,start,y+h/2+6,size,"sans","ink");
        if(arrow) b.arrow(start+tw+12,y+h/2,14,INK);
        b.target(id,x,y,w,h);
    }
    private void library() {
        Board b=board;
        b.text("The game room",56,148,65,"serif","ink");
        b.right("5 games   /   Offline play",1224,143,18,"sans","soft");
        int x=56, y=175, w=1168, h=291;
        b.picture("hero.jpg",x,y,w,h);
        b.suit('S',"gold",92,201,17);
        b.text("NO-LIMIT TEXAS HOLD’EM",119,216,15,"sans","gold");
        b.text("Poker",90,303,92,"serif","paper");
        b.text("Take a seat against three computer opponents.",94,343,21,"sans","paper");
        b.target("open:0",x,y,w,h);
        button("open:0",played(0)?"Resume table":"Play poker",94,376,184,54,true,true);
        b.text("More tables",56,520,35,"serif","ink");
        b.line(255,510,1223,510,HAIR);
        int[] colors={0,0xAE4331,0x3F7363,0x946A2F,0x4B6297};
        for(int i=1;i<5;i++) {
            int left=56+(i-1)*296;
            b.rect(left,543,280,220,0xC7C7B6);
            b.rect(left+1,544,278,218,0xFCF8ED);
            b.picture(ART[i]+"-print.jpg",left+1,544,278,136);
            b.text(NAMES[i],left+14,717,30,"serif","ink");
            b.text(STYLES[i],left+15,746,16,"sans","soft");
            b.arrow(left+243,708,17,colors[i]);
            b.target("open:"+i,left,543,280,220);
        }
    }
    private void play() {
        View v=games[table].view();
        Board b=board;
        b.text(NAMES[table],56,142,54,"serif","ink");
        int next=56+b.width(NAMES[table],54,"serif")+24;
        b.text(v.phase,next,135,20,"sans","soft");
        b.right(v.score,1224,135,20,"sans","ink");
        b.rounded(40,159,1200,504,9,0x12352B);
        b.rounded(44,163,1192,496,7,GREEN);
        b.edge(52,171,1176,480,0x547261);
        TableLayout.draw(b,table,v);
        b.wrap(v.status,56,707,1168,22,26,"ink");
        int right=1224;
        // Actions sit on their own line so long round summaries never cover them.
        for(int i=v.actions.size()-1;i>=0;i--) {
            Action a=v.actions.get(i);
            int width=Math.max(92,b.width(a.label,18,"sans")+40);
            right-=width;
            String target=table==3 && a.id.equals("deal")?"new":"move:"+a.id;
            button(target,a.label,right,746,width,44,i==0,false);
            right-=9;
        }
        if(table!=3) {
            b.text("New game",57,779,16,"sans","soft");
            b.target("new",47,746,116,44);
        }
    }
    private void guide() {
        Board b=board;
        b.text("How to play",56,151,62,"serif","ink");
        button("close",table>=0?"Back to table":"Back to room",1006,100,218,49,false,false);
        int tabY=178;
        for(int i=0;i<5;i++) {
            int x=56+i*235;
            boolean active=i==guide;
            b.rect(x,tabY,226,47,active?GREEN:0xE7E6D8);
            b.center(NAMES[i],x+113,tabY+30,20,"sans",active?"paper":"ink");
            b.target("rules:"+i,x,tabY,226,47);
        }
        b.cover(ART[guide]+".jpg",56,251,300,459,.5f);
        b.text(STYLES[guide].toUpperCase(Locale.ROOT),393,279,16,"sans","soft");
        b.text(NAMES[guide],390,339,58,"serif","ink");
        Game info=games[guide]!=null?games[guide]:make(guide,0);
        b.wrap(info.rules(),393,380,817,21,29,"ink");
        button("open:"+guide,played(guide)?"Resume table":"Play "+NAMES[guide],393,725,230,50,true,true);
    }
    private void confirmation() {
        Board b=board;
        b.text("Start a new game?",56,196,63,"serif","ink");
        b.text("This replaces your saved "+NAMES[table]+" table.",59,251,25,"sans","ink");
        button("close","Keep playing",60,300,182,52,true,false);
        button("reset","Start new game",257,300,209,52,false,false);
    }
}
