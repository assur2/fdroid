package club.cardtable.game;

import java.util.ArrayList;
import java.util.List;

public class View {
    public String phase = "", status = "", score = "";
    public final List<Group> groups = new ArrayList<>();
    public final List<Action> actions = new ArrayList<>();
    public Group group(String label, String layout) {
        Group group = new Group(label, layout);
        groups.add(group);
        return group;
    }
    public Action action(String id, String label) {
        Action action = new Action(id, label);
        actions.add(action);
        return action;
    }
}
