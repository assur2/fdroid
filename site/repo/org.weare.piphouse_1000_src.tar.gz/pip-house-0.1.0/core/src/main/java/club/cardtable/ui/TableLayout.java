package club.cardtable.ui;

import club.cardtable.game.Group;
import club.cardtable.game.Tile;
import club.cardtable.game.View;
import java.util.ArrayList;
import java.util.List;

/** Positions the same interactive card objects on the shared 1280 x 800 artboard. */
final class TableLayout {
    private static final int TRIM = 0x416354;
    private static final int GOLD = 0xEDC785;
    private static final int SLOT = 0x5C7867;

    static void draw(Board b, int game, View v) {
        if (game == 3) solitaire(b, v);
        else if (game == 4) skipBo(b, v);
        else seatedTable(b, game, v);
    }

    private static List<Group> groups(View view, String layout) {
        List<Group> found = new ArrayList<>();
        for (Group group : view.groups) if (group.layout.equals(layout)) found.add(group);
        return found;
    }

    private static void slot(Board b, int x, int y, int w, int h) {
        // Open corners give empty board spaces a lighter weight than real cards.
        int side = 13;
        b.line(x,y,x+side,y,SLOT); b.line(x,y,x,y+side,SLOT);
        b.line(x+w-side,y,x+w,y,SLOT); b.line(x+w,y,x+w,y+side,SLOT);
        b.line(x,y+h-side,x,y+h,SLOT); b.line(x,y+h,x+side,y+h,SLOT);
        b.line(x+w,y+h-side,x+w,y+h,SLOT); b.line(x+w-side,y+h,x+w,y+h,SLOT);
    }

    private static void label(Board b, String value, int x, int y) {
        b.text(value, x, y, 17, "sans", "mint");
    }

    private static void centeredLabel(Board b, String value, int x, int y) {
        b.center(value, x, y, 17, "sans", "mint");
    }

    private static void seatedTable(Board b, int game, View v) {
        List<Group> seats = groups(v,"seat");
        for (int i = 0; i < seats.size(); i++) {
            Group seat = seats.get(i);
            int x = 90 + i * 377;
            if (i > 0) b.line(x - 27, 196, x - 27, 257, TRIM);
            boolean show = seat.tiles.size() == 2 && !seat.tiles.get(0).face.equals("back");
            int gap = show ? 45 : 11;
            for (int j = 0; j < seat.tiles.size(); j++) b.card(seat.tiles.get(j), x+j*gap, 192, 42, 61);
            int textX = x + (show ? 100 : 71);
            b.text(seat.label, textX, 215, 26, "serif", "paper");
            label(b, seat.note, textX, 243);
        }
        b.line(82, 274, 1198, 274, TRIM);

        Group table = groups(v,"center").get(0);
        b.text(table.label, 90, 347, 27, "serif", "paper");
        if (!table.note.isEmpty()) b.text(table.note, 90, 379, 20, "sans", "gold");
        int spaces = game == 0 ? 5 : 4;
        int w = 81, h = 112, gap = 27;
        int first = 747 - (spaces*w + (spaces-1)*gap) / 2;
        for (int i = 0; i < spaces; i++) {
            int x = first + i * (w+gap);
            if (i < table.tiles.size()) {
                Tile t = table.tiles.get(i);
                b.card(t,x,292,w,h);
                if (!t.note.isEmpty()) centeredLabel(b,t.note,x+w/2,432);
            } else slot(b,x,292,w,h);
        }
        b.line(82, 454, 1198, 454, TRIM);

        Group hand = groups(v,"hand").get(0);
        String title = hand.label, detail = hand.note;
        int divider = title.indexOf("  /  ");
        if (divider >= 0) { detail = title.substring(divider + 5); title = title.substring(0,divider); }
        b.text(title, 90, 492, 27, "serif", "paper");
        if (!detail.isEmpty()) label(b,detail,105 + (int)b.width(title,27,"serif"),491);
        boolean active = false, inert = false;
        for (Tile t : hand.tiles) { if (t.id == null) inert = true; else active = true; }
        boolean restricted = game != 0 && inert && active && !v.phase.startsWith("Pass");
        if (restricted) {
            String key = "Playable cards";
            int keyX = 1198 - (int)b.width(key,17,"sans");
            b.rect(keyX - 25,483,15,3,GOLD);
            label(b,key,keyX,491);
        }
        int cardW = 78, cardH = 109, stride = 86;
        int start = 640 - (cardW + (hand.tiles.size() - 1)*stride)/2;
        for (int i = 0; i < hand.tiles.size(); i++) {
            Tile t = hand.tiles.get(i);
            int y = 524 - (t.selected ? 14 : restricted && t.id != null ? 7 : 0);
            int x = start + i*stride;
            b.card(t,x,y,cardW,cardH);
            if (t.selected || restricted && t.id != null) b.rect(x+4,y+cardH+2,cardW-8,3,GOLD);
        }
    }

    private static void solitaire(Board b, View v) {
        int firstCenter = 149, spacing = 164;
        List<Group> single = groups(v, "stocks");
        for (int i = 0; i < single.size(); i++) {
            Group pile = single.get(i);
            int center = firstCenter + (i < 2 ? i : i+1)*spacing;
            centeredLabel(b, pile.label, center,192);
            b.card(pile.tiles.get(0),center-31,201,62,85);
        }
        b.line(82,300,1198,300,TRIM);
        List<Group> columns = groups(v, "column");
        for (int i = 0; i < columns.size(); i++) {
            Group pile = columns.get(i);
            int center = firstCenter + i * spacing;
            centeredLabel(b,pile.label,center,325);
            int hidden = 0;
            while (hidden < pile.tiles.size() && pile.tiles.get(hidden).face.equals("back")) hidden++;
            int visible = pile.tiles.size()-hidden;
            // Long exposed runs continue in the adjoining lane inside the same column.
            // Each source retains a distinct touchable segment, including on a full king-to-ace run.
            boolean wrap = visible > 8;
            int w = wrap ? 67 : 86, h = wrap ? 91 : 117;
            int x = wrap ? center-69 : center-w/2;
            int top = 337;
            int backLayers = Math.min(3,hidden);
            for (int j = 0; j < backLayers; j++) b.card(pile.tiles.get(j),x,top+j*6,w,h);
            if (hidden > 0) {
                String count = String.valueOf(hidden);
                b.text(count, x-8-(int)b.width(count,14,"sans"),top+15,14,"sans","mint");
            }
            int y = top + backLayers*6;
            int laneLength = wrap ? (visible+1)/2 : visible;
            int dy = Math.min(32, (637-y-h)/Math.max(1,laneLength-1));
            for (int n = 0; n < visible; n++) {
                Tile t = pile.tiles.get(n+hidden);
                int cardX = x + (wrap && n >= laneLength ? w+5 : 0);
                int cardY = y + (n % laneLength)*dy;
                b.card(t,cardX,cardY,w,h);
                if (t.selected) b.rect(cardX-3,cardY+2,3,h-4,GOLD);
            }
        }
    }

    private static void skipBo(Board b, View v) {
        Group bot = groups(v,"seat").get(0);
        b.text(bot.label,90,213,28,"serif","paper");
        label(b,bot.note,90,242);
        for (int i = 0; i < bot.tiles.size(); i++) {
            Tile tile = bot.tiles.get(i);
            int cx = 505 + 147*i;
            b.card(tile,cx-24,178,48,66);
            centeredLabel(b,tile.note,cx,267);
        }
        b.line(82,281,1198,281,TRIM);
        List<Group> builds = groups(v,"build");
        for (int i = 0; i < builds.size(); i++) {
            Group pile = builds.get(i);
            int cx = 116+i*285;
            b.card(pile.tiles.get(0),cx,305,82,113);
            b.text(pile.label,cx+98,350,25,"serif","paper");
            b.text(pile.note,cx+98,378,18,"sans","gold");
        }
        b.line(82,441,1198,441,TRIM);
        b.line(636,468,636,627,TRIM);
        List<Group> reserve = groups(v,"reserve");
        for (int i = 0; i < reserve.size(); i++) {
            Group pile = reserve.get(i);
            int cx = 126+i*109;
            centeredLabel(b,pile.label,cx,495);
            Tile t = pile.tiles.get(0);
            int y = t.selected ? 506 : 516;
            b.card(t,cx-36,y,72,99);
            if (t.selected) b.rect(cx-32,y+101,64,3,GOLD);
        }
        Group hand = groups(v,"hand").get(0);
        b.text(hand.label,685,490,27,"serif","paper");
        for (int i = 0; i < hand.tiles.size(); i++) {
            Tile t = hand.tiles.get(i);
            int x = 686+i*102, y = t.selected ? 506 : 516;
            b.card(t,x,y,74,102);
            if (t.selected) b.rect(x+4,y+104,66,3,GOLD);
        }
    }
}
