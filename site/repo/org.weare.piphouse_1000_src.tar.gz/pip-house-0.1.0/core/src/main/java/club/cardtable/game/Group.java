package club.cardtable.game;

import java.util.ArrayList;
import java.util.List;

public class Group {
    public final String label, layout;
    public String note = "";
    public final List<Tile> tiles = new ArrayList<>();
    public Group(String label, String layout) {
        this.label = label;
        this.layout = layout;
    }
    public Tile add(String face, String id) {
        Tile tile = new Tile(face, id);
        tiles.add(tile);
        return tile;
    }
}
