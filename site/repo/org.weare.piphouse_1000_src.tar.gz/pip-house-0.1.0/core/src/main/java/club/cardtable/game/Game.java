package club.cardtable.game;

public interface Game {
    View view();
    void act(String id);
    String rules();
}
