package club.cardtable.ui;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.graphics.Cursor;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Matrix4;

/** Native desktop and Android entry point. The table fits a landscape window of any size. */
public final class PipHouse extends ApplicationAdapter {
    private Board board;
    private Room room;
    private SpriteBatch batch;
    private Texture texture;
    private int left, bottom, width, height;
    private boolean dirty=true;
    private String pressed;

    @Override public void create() {
        board=new Board(Gdx.files.internal(""));
        final Preferences preferences=Gdx.app.getPreferences("pip-house-tables");
        room=new Room(board,new Room.Store() {
            public String get(String key) {return preferences.getString(key,"");}
            public void put(String key,String value) {preferences.putString(key,value);preferences.flush();}
        },System.nanoTime());
        batch=new SpriteBatch();
        createTexture();
        Gdx.input.setCatchKey(Input.Keys.BACK,true);
        Gdx.input.setInputProcessor(new Controls());
        Gdx.graphics.setContinuousRendering(false);
        resize(Gdx.graphics.getWidth(),Gdx.graphics.getHeight());
    }
    @Override public void resize(int screenWidth,int screenHeight) {
        if(batch==null || screenWidth<=0 || screenHeight<=0) return;
        float scale=Math.min(screenWidth/(float)Board.W,screenHeight/(float)Board.H);
        width=Math.max(1,Math.round(Board.W*scale));
        height=Math.max(1,Math.round(Board.H*scale));
        left=(screenWidth-width)/2; bottom=(screenHeight-height)/2;
        batch.setProjectionMatrix(new Matrix4().setToOrtho2D(0,0,screenWidth,screenHeight));
        refresh();
    }
    private void refresh() {dirty=true;Gdx.graphics.requestRendering();}
    private void createTexture() {
        texture=new Texture(board.pixels());
        texture.setFilter(Texture.TextureFilter.Linear,Texture.TextureFilter.Linear);
    }
    @Override public void pause() {
        if(texture!=null) {texture.dispose();texture=null;}
    }
    @Override public void resume() {
        if(board!=null && texture==null) createTexture();
        refresh();
    }
    @Override public void render() {
        if(texture==null) return;
        if(dirty) {room.paint();texture.draw(board.pixels(),0,0);dirty=false;}
        Gdx.gl.glClearColor(.064f,.105f,.09f,1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
        batch.begin();
        batch.draw(texture,left,bottom,width,height);
        batch.end();
    }
    private int mapX(int x) {return (int)Math.floor((x-left)*(double)Board.W/width);}
    private int mapY(int y) {
        int top=Gdx.graphics.getHeight()-bottom-height;
        return (int)Math.floor((y-top)*(double)Board.H/height);
    }
    private final class Controls extends InputAdapter {
        @Override public boolean touchDown(int x,int y,int pointer,int button) {
            if(pointer!=0 || button!=Input.Buttons.LEFT) return false;
            pressed=room.hitAt(mapX(x),mapY(y)); return pressed!=null;
        }
        @Override public boolean touchUp(int x,int y,int pointer,int button) {
            if(pointer!=0 || button!=Input.Buttons.LEFT) return false;
            String target=room.hitAt(mapX(x),mapY(y));
            if(pressed!=null && pressed.equals(target)) {room.activate(pressed);refresh();}
            pressed=null; return true;
        }
        @Override public boolean touchCancelled(int x,int y,int pointer,int button) {pressed=null;return true;}
        @Override public boolean mouseMoved(int x,int y) {
            int px=mapX(x),py=mapY(y);
            if(room.hover(px,py)) refresh();
            if(Gdx.app.getType()==Application.ApplicationType.Desktop) {
                Gdx.graphics.setSystemCursor(room.hitAt(px,py)==null?Cursor.SystemCursor.Arrow:Cursor.SystemCursor.Hand);
            }
            return true;
        }
        @Override public boolean keyDown(int key) {
            switch(key) {
                case Input.Keys.ESCAPE:
                case Input.Keys.BACK:
                    if(!room.back()) Gdx.app.exit();
                    break;
                case Input.Keys.TAB:
                    room.tab(Gdx.input.isKeyPressed(Input.Keys.SHIFT_LEFT)||Gdx.input.isKeyPressed(Input.Keys.SHIFT_RIGHT));
                    break;
                case Input.Keys.ENTER:
                case Input.Keys.SPACE:
                    room.enterFocused();break;
                default:return false;
            }
            refresh();return true;
        }
    }
    @Override public void dispose() {
        if(texture!=null) texture.dispose();
        batch.dispose();board.dispose();
    }
}
