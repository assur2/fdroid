package club.cardtable.game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.TreeSet;

/** A four-seat, play-chip no-limit Texas Hold'em tournament. */
public final class PokerGame implements Game {
    private static final int SEATS = 4;
    private static final int BIG_BLIND = 20;
    private static final String[] NAMES = {"You", "Nora", "Felix", "Jules"};
    private static final String[] STREETS = {"Pre-flop", "Flop", "Turn", "River"};
    private static final String[] RANKS = {"2", "3", "4", "5", "6", "7", "8",
            "9", "10", "J", "Q", "K", "A"};
    private static final String SUITS = "CDHS";
    private static final String[] CLASSES = {"High card", "One pair", "Two pair",
            "Three of a kind", "Straight", "Flush", "Full house", "Four of a kind",
            "Straight flush"};

    private final Random random;
    private final int[] stack = new int[SEATS];
    private final int[] invested = new int[SEATS];    // Entire hand
    private final int[] wager = new int[SEATS];       // Current street
    private final int[] lastActedAt = new int[SEATS]; // -1 before the first action
    private final String[] lastAction = new String[SEATS];
    private final boolean[] folded = new boolean[SEATS];
    private final int[][] pocket = new int[SEATS][2];
    private final int[] board = new int[5];
    private final int[] deck = new int[52];
    private int deckIndex, boardSize, handNumber, street, dealer, smallBlind, bigBlind;
    private int actor, price, lastFullRaise, raiseTarget, raiseStep;
    private boolean complete, showCards, sizing;
    private String result;

    public PokerGame(long seed) {
        random = new Random(seed);
        startTable();
    }

    private void startTable() {
        Arrays.fill(stack, 1000);
        handNumber = 0;
        newHand();
    }

    private int nextFunded(int position) {
        for (int offset = 1; offset <= SEATS; offset++) {
            int next = (position + offset) % SEATS;
            if (stack[next] > 0) return next;
        }
        throw new IllegalStateException("No funded seat");
    }

    private int fundedCount() {
        int count = 0;
        for (int chips : stack) if (chips > 0) count++;
        return count;
    }

    private void newHand() {
        if (handNumber == 0) {
            dealer = 1;
            smallBlind = 2;
            bigBlind = 3;
        } else {
            int nextBig = nextFunded(bigBlind);
            if (fundedCount() == 2) {
                dealer = nextFunded(nextBig);
                smallBlind = dealer;
            } else {
                // A bust in the blinds can leave a dead button or small blind.
                dealer = smallBlind;
                smallBlind = bigBlind;
            }
            bigBlind = nextBig;
        }
        handNumber++;
        deckIndex = boardSize = street = 0;
        complete = showCards = sizing = false;
        result = "";
        Arrays.fill(invested, 0);
        Arrays.fill(wager, 0);
        Arrays.fill(lastActedAt, -1);
        Arrays.fill(lastAction, "");
        for (int seat = 0; seat < SEATS; seat++) {
            folded[seat] = stack[seat] == 0;
            Arrays.fill(pocket[seat], -1);
        }
        for (int i = 0; i < deck.length; i++) deck[i] = i;
        for (int i = deck.length - 1; i > 0; i--) {
            int j = random.nextInt(i + 1);
            int temp = deck[i];
            deck[i] = deck[j];
            deck[j] = temp;
        }
        for (int round = 0; round < 2; round++) {
            for (int offset = 1; offset <= SEATS; offset++) {
                int seat = (dealer + offset) % SEATS;
                if (!folded[seat]) pocket[seat][round] = deck[deckIndex++];
            }
        }
        if (!folded[smallBlind]) {
            pay(smallBlind, BIG_BLIND / 2);
            lastAction[smallBlind] = "Small blind";
        }
        pay(bigBlind, BIG_BLIND);
        lastAction[bigBlind] = "Big blind";
        price = lastFullRaise = BIG_BLIND;
        advance(bigBlind);
    }

    private void pay(int seat, int chips) {
        int paid = Math.min(stack[seat], chips);
        stack[seat] -= paid;
        wager[seat] += paid;
        invested[seat] += paid;
    }

    private int pot() {
        int chips = 0;
        for (int contribution : invested) chips += contribution;
        return chips;
    }

    private int contenders() {
        int players = 0;
        for (boolean discarded : folded) if (!discarded) players++;
        return players;
    }

    private int respondingOpponents(int seat) {
        int count = 0;
        for (int i = 0; i < SEATS; i++) {
            if (i != seat && !folded[i] && stack[i] > 0) count++;
        }
        return count;
    }

    private int amountToCall(int seat) {
        int effectivePrice = price;
        if (respondingOpponents(seat) == 0) {
            // A short big blind or an uncalled overbet cannot require excess chips.
            effectivePrice = 0;
            for (int i = 0; i < SEATS; i++) {
                if (i != seat && !folded[i]) effectivePrice = Math.max(effectivePrice, wager[i]);
            }
        }
        return Math.min(stack[seat], Math.max(0, effectivePrice - wager[seat]));
    }

    private boolean owesAction(int seat) {
        if (folded[seat] || stack[seat] == 0) return false;
        return amountToCall(seat) > 0 ||
                (lastActedAt[seat] < 0 && respondingOpponents(seat) > 0);
    }

    private int maxTarget(int seat) {
        return stack[seat] + wager[seat];
    }

    private int minTarget(int seat) {
        return Math.min(maxTarget(seat), price + lastFullRaise);
    }

    private boolean canRaise(int seat) {
        return respondingOpponents(seat) > 0 && maxTarget(seat) > price &&
                (lastActedAt[seat] < 0 || price - lastActedAt[seat] >= lastFullRaise);
    }

    private void call(int seat) {
        int chips = amountToCall(seat);
        pay(seat, chips);
        if (chips == 0) lastAction[seat] = "Check";
        else lastAction[seat] = stack[seat] == 0 ? "All-in " + wager[seat] : "Call " + chips;
        lastActedAt[seat] = price;
    }

    private void raise(int seat, int target) {
        if (!canRaise(seat) || target < minTarget(seat) || target > maxTarget(seat)) return;
        int increase = target - price;
        String verb = price == 0 ? "Bet " : "Raise to ";
        lastFullRaise = Math.max(lastFullRaise, increase);
        pay(seat, target - wager[seat]);
        price = lastActedAt[seat] = target;
        lastAction[seat] = stack[seat] == 0 ? "All-in " + target : verb + target;
    }

    private void fold(int seat) {
        folded[seat] = true;
        lastAction[seat] = "Fold";
    }

    /** Continues through computer actions and closed streets up to the next user decision. */
    private void advance(int previous) {
        while (true) {
            if (contenders() == 1) {
                finish(false);
                return;
            }
            int next = -1;
            for (int offset = 1; offset <= SEATS; offset++) {
                int candidate = (previous + offset) % SEATS;
                if (owesAction(candidate)) {
                    next = candidate;
                    break;
                }
            }
            if (next >= 0) {
                actor = next;
                if (actor == 0) return;
                botAct(actor);
                previous = actor;
                continue;
            }
            if (street == 3) {
                finish(true);
                return;
            }
            street++;
            deckIndex++; // Burn before the flop, turn, and river.
            int cards = street == 1 ? 3 : 1;
            for (int i = 0; i < cards; i++) board[boardSize++] = deck[deckIndex++];
            price = 0;
            lastFullRaise = BIG_BLIND;
            Arrays.fill(wager, 0);
            Arrays.fill(lastActedAt, -1);
            for (int i = 0; i < SEATS; i++) {
                if (!folded[i] && stack[i] > 0) lastAction[i] = "";
            }
            previous = dealer;
        }
    }

    private void botAct(int seat) {
        int due = amountToCall(seat);
        double equity = approximateEquity(seat);
        int possiblePot = 0;
        for (int chips : invested) possiblePot += Math.min(chips, invested[seat] + due);
        double potOdds = (double) due / Math.max(1, possiblePot + due);
        double style = seat == 1 ? 0.03 : seat == 2 ? -0.035 : 0;
        if (due > 0 && equity + style + random.nextDouble() * 0.07 < potOdds) {
            fold(seat);
            return;
        }
        double aggression = equity - 1.0 / contenders() + style;
        boolean valueBet = aggression > 0.12 && random.nextDouble() < aggression + 0.20;
        boolean bluff = due == 0 && lastActedAt[seat] < 0 && random.nextDouble() < 0.055;
        if (canRaise(seat) && (valueBet || bluff)) {
            int bet = Math.max(lastFullRaise, possiblePot / (equity > 0.7 ? 2 : 3));
            int target = Math.min(maxTarget(seat), price + bet);
            raise(seat, target);
        } else {
            call(seat);
        }
    }

    /** Sample only this player's cards and public information. */
    private double approximateEquity(int seat) {
        boolean[] seen = new boolean[52];
        seen[pocket[seat][0]] = seen[pocket[seat][1]] = true;
        for (int i = 0; i < boardSize; i++) seen[board[i]] = true;
        int[] unknown = new int[52 - 2 - boardSize];
        int count = 0;
        for (int card = 0; card < 52; card++) if (!seen[card]) unknown[count++] = card;
        int opponents = contenders() - 1;
        int needed = 5 - boardSize + opponents * 2;
        int[] seven = new int[7];
        System.arraycopy(board, 0, seven, 0, boardSize);
        double wins = 0;
        final int trials = 52;
        for (int sample = 0; sample < trials; sample++) {
            for (int i = 0; i < needed; i++) {
                int j = i + random.nextInt(unknown.length - i);
                int temp = unknown[j];
                unknown[j] = unknown[i];
                unknown[i] = temp;
            }
            int cursor = 0;
            for (int i = boardSize; i < 5; i++) seven[i] = unknown[cursor++];
            seven[5] = pocket[seat][0];
            seven[6] = pocket[seat][1];
            int own = evaluate(seven);
            int tied = 1;
            for (int i = 0; i < opponents; i++) {
                seven[5] = unknown[cursor++];
                seven[6] = unknown[cursor++];
                int rival = evaluate(seven);
                if (rival > own) {
                    tied = 0;
                    break;
                }
                if (rival == own) tied++;
            }
            if (tied > 0) wins += 1.0 / tied;
        }
        return wins / trials;
    }

    /**
     * Best five from seven. The category occupies the high nibble, followed by
     * tie-breaking ranks in descending significance.
     */
    static int evaluate(int[] cards) {
        int[] counts = new int[15];
        int[] suitMasks = new int[4];
        int all = 0;
        for (int card : cards) {
            int rank = card % 13 + 2;
            counts[rank]++;
            suitMasks[card / 13] |= 1 << rank;
            all |= 1 << rank;
        }
        int flush = 0;
        for (int mask : suitMasks) if (Integer.bitCount(mask) >= 5) flush = mask;
        int straightFlush = straightHigh(flush);
        if (straightFlush != 0) return (8 << 20) | (straightFlush << 16);
        int quad = 0, trip = 0, pair = 0, lowerPair = 0;
        for (int rank = 14; rank >= 2; rank--) {
            if (counts[rank] == 4) quad = rank;
            if (counts[rank] == 3 && trip == 0) trip = rank;
            else if (counts[rank] >= 2 && rank != quad) {
                if (pair == 0) pair = rank;
                else if (lowerPair == 0) lowerPair = rank;
            }
        }
        if (quad != 0) return (7 << 20) | (quad << 16) | (topRanks(all & ~(1 << quad), 1) << 12);
        if (trip != 0 && pair != 0) return (6 << 20) | (trip << 16) | (pair << 12);
        if (flush != 0) return (5 << 20) | topRanks(flush, 5);
        int straight = straightHigh(all);
        if (straight != 0) return (4 << 20) | (straight << 16);
        if (trip != 0) return (3 << 20) | (trip << 16) | (topRanks(all & ~(1 << trip), 2) << 8);
        if (lowerPair != 0) {
            int remaining = all & ~(1 << pair) & ~(1 << lowerPair);
            return (2 << 20) | (pair << 16) | (lowerPair << 12) | (topRanks(remaining, 1) << 8);
        }
        if (pair != 0) return (1 << 20) | (pair << 16) | (topRanks(all & ~(1 << pair), 3) << 4);
        return topRanks(all, 5);
    }

    private static int straightHigh(int mask) {
        if ((mask & (1 << 14)) != 0) mask |= 1 << 1;
        for (int high = 14; high >= 5; high--) {
            if (((mask >> (high - 4)) & 31) == 31) return high;
        }
        return 0;
    }

    private static int topRanks(int mask, int count) {
        int result = 0;
        for (int rank = 14; rank >= 2 && count > 0; rank--) {
            if ((mask & (1 << rank)) != 0) {
                result = (result << 4) | rank;
                count--;
            }
        }
        return result;
    }

    private void finish(boolean showdown) {
        complete = true;
        showCards = showdown;
        actor = -1;
        int[] scores = new int[SEATS];
        int[] wins = new int[SEATS];
        int[] seven = Arrays.copyOf(board, 7);
        TreeSet<Integer> levels = new TreeSet<Integer>();
        for (int i = 0; i < SEATS; i++) {
            if (invested[i] > 0) levels.add(invested[i]);
            if (!folded[i] && showdown) {
                seven[5] = pocket[i][0];
                seven[6] = pocket[i][1];
                scores[i] = evaluate(seven);
            }
        }
        // Each contribution level defines a pot with its own eligible players.
        int previous = 0;
        for (int level : levels) {
            int chips = 0, best = -1, contributors = 0, onlyContributor = -1;
            List<Integer> winners = new ArrayList<Integer>(SEATS);
            for (int offset = 1; offset <= SEATS; offset++) {
                int seat = (dealer + offset) % SEATS;
                if (invested[seat] < level) continue;
                contributors++;
                onlyContributor = seat;
                chips += level - previous;
                if (folded[seat] || scores[seat] < best) continue;
                if (scores[seat] > best) winners.clear();
                best = scores[seat];
                winners.add(seat);
            }
            if (contributors == 1) {
                stack[onlyContributor] += chips; // Return an uncalled bet.
                invested[onlyContributor] -= chips;
            } else if (!winners.isEmpty()) {
                for (int i = 0; i < winners.size(); i++) {
                    int share = chips / winners.size() + (i < chips % winners.size() ? 1 : 0);
                    stack[winners.get(i)] += share;
                    wins[winners.get(i)] += share;
                }
            } else {
                // An uncontested hand can end before the last player covers a blind.
                for (int i = 0; i < SEATS; i++) if (!folded[i]) {
                    stack[i] += chips;
                    wins[i] += chips;
                    break;
                }
            }
            previous = level;
        }
        StringBuilder summary = new StringBuilder();
        int winnerCount = 0, winner = -1;
        for (int i = 0; i < SEATS; i++) if (wins[i] > 0) {
            if (winnerCount > 0) summary.append(" · ");
            summary.append(NAMES[i]).append(i == 0 ? " win " : " wins ").append(wins[i]);
            winnerCount++;
            winner = i;
        }
        if (showdown && winnerCount == 1) {
            summary.append(" · ").append(CLASSES[scores[winner] >> 20]);
        } else if (winnerCount == 0) {
            for (int i = 0; i < SEATS; i++) if (!folded[i]) {
                summary.append(NAMES[i]).append(i == 0 ? " take" : " takes").append(" the hand");
                break;
            }
        }
        result = summary.toString();
    }

    private static String face(int card) {
        return RANKS[card % 13] + SUITS.charAt(card / 13);
    }

    private String position(int seat) {
        if (seat == dealer && seat == smallBlind) return "D / SB";
        if (seat == dealer) return "D";
        if (seat == smallBlind) return "SB";
        if (seat == bigBlind) return "BB";
        return "";
    }

    private boolean tableOver() {
        return stack[0] == 0 || fundedCount() < 2;
    }

    @Override public View view() {
        View view = new View();
        view.phase = complete ? (showCards ? "Showdown" : "Hand complete") : STREETS[street];
        view.score = "Hand " + handNumber + "  ·  Blinds 10 / 20";
        for (int i = 1; i < SEATS; i++) {
            Group group = view.group(NAMES[i], "seat");
            String position = position(i);
            String info = !lastAction[i].isEmpty() ? lastAction[i] : position;
            group.note = stack[i] + " chips" + (info.isEmpty() ? "" : " · " + info);
            if (pocket[i][0] < 0) {
                group.note = "Out";
            } else if (!folded[i]) {
                for (int card : pocket[i]) group.add(showCards ? face(card) : "back", null);
            }
        }
        Group center = view.group("Community cards", "center");
        center.note = "Pot " + pot();
        for (int i = 0; i < boardSize; i++) center.add(face(board[i]), null);
        Group hand = view.group("Your hand", "hand");
        hand.note = stack[0] + " chips" + (folded[0] ? " · Folded" : "");
        for (int card : pocket[0]) if (card >= 0) hand.add(face(card), null);
        if (complete) {
            view.status = result;
            if (tableOver()) {
                view.phase = stack[0] == 0 ? "Out of chips" : "Table champion";
                view.action("table", "New table");
            } else view.action("next", "Next hand");
        } else if (sizing) {
            view.status = "Choose your total bet  ·  " + minTarget(0) + " to " + maxTarget(0);
            if (raiseTarget > minTarget(0)) view.action("less", "-" + raiseStep);
            if (raiseTarget < maxTarget(0)) view.action("more", "+" + raiseStep);
            view.action("step", "Step " + raiseStep);
            if (raiseTarget != maxTarget(0)) view.action("max", "All-in");
            view.action("commit", (price == 0 ? "Bet " : "Raise to ") + raiseTarget);
            view.action("back", "Back");
        } else {
            int due = amountToCall(0);
            view.status = (due == 0 ? "Your move" : due + " to call") + "  ·  Pot " + pot();
            view.action("call", due == 0 ? "Check" : (due == stack[0] ? "Call all-in " : "Call ") + due);
            if (canRaise(0)) view.action("raise", price == 0 ? "Bet" : "Raise");
            view.action("fold", "Fold");
        }
        return view;
    }

    @Override public void act(String id) {
        if (id == null) return;
        if (complete) {
            if (tableOver() && "table".equals(id)) startTable();
            else if (!tableOver() && "next".equals(id)) newHand();
            return;
        }
        if (actor != 0) return;
        if (sizing) {
            switch (id) {
                case "less": raiseTarget = Math.max(minTarget(0), raiseTarget - raiseStep); return;
                case "more": raiseTarget = Math.min(maxTarget(0), raiseTarget + raiseStep); return;
                case "step": raiseStep = raiseStep == 1 ? 10 : raiseStep == 10 ? 100 : 1; return;
                case "max": raiseTarget = maxTarget(0); return;
                case "back": sizing = false; return;
                case "commit":
                    raise(0, raiseTarget);
                    sizing = false;
                    advance(0);
                    return;
                default: return;
            }
        }
        switch (id) {
            case "call": call(0); break;
            case "fold": fold(0); break;
            case "raise":
                if (canRaise(0)) {
                    sizing = true;
                    raiseTarget = minTarget(0);
                    raiseStep = 10;
                }
                return;
            default: return;
        }
        advance(0);
    }

    @Override public String rules() {
        return "Play no-limit Texas Hold'em against three opponents. Everyone begins with 1,000 play chips. "
                + "The rotating small and big blinds put in 10 and 20 before the deal.\n\n"
                + "Use any five of your two private cards and the five community cards. The flop reveals three cards, "
                + "followed by the turn and river. Each street has a betting round. Check to stay in for free, "
                + "call to match a bet, raise, or fold. When sizing a raise, Step cycles through 1, 10 and 100 chips.\n\n"
                + "From strongest to weakest, hands rank straight flush, four of a kind, full house, flush, straight, "
                + "three of a kind, two pair, one pair, high card. Ties share the pot. An all-in player can win only "
                + "the pots they contributed to. Win every chip to take the table.";
    }
}
