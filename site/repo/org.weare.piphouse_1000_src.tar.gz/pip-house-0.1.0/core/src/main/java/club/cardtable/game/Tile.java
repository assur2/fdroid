package club.cardtable.game;

public class Tile {
    public final String face, id;
    public String note = "";
    public boolean selected;
    public Tile(String face, String id) {
        this.face = face;
        this.id = id;
    }
}
