package club.cardtable.game;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Random;
import java.util.Set;

public final class HeartsGame extends TrickGame {
    private static final int HEARTS = 3;
    private static final int SPADES = 2;
    private static final int QUEEN_OF_SPADES = 36;
    private static final int[] PASS_STEP = { 1, 3, 2, 0 };
    private static final String[] PASS_NAME = { "left", "right", "across", "" };
    private final Set<Integer> selected = new LinkedHashSet<>();
    private final int[] penalties = new int[4];
    private final int[] totals = new int[4];
    private boolean heartsBroken;

    public HeartsGame(long seed) {
        super(seed);
        deal();
    }

    @Override void deal() {
        dealCards(2);
        Arrays.fill(penalties, 0);
        selected.clear();
        heartsBroken = false;
        if (PASS_STEP[passIndex()] == 0) openPlay();
        else stage = Stage.PASS;
    }

    private int passIndex() { return (dealNumber - 1) % 4; }

    private void openPlay() {
        for (int player = 0; player < 4; player++) {
            if (hands.get(player).contains(0)) {
                startTrick(player);
                return;
            }
        }
        throw new IllegalStateException("Missing two of clubs");
    }

    private int danger(int player, int c) {
        int rank = rank(c);
        if (c == QUEEN_OF_SPADES) return countSuit(player, SPADES) >= 5 ? 13 : 36;
        if (suit(c) == SPADES && rank >= 13 && !seen[QUEEN_OF_SPADES]) return rank + 12;
        return rank + (suit(c) == HEARTS ? 3 : 0) + (countSuit(player, suit(c)) <= 2 ? 3 : 0);
    }

    private void passCards() {
        List<List<Integer>> outgoing = new ArrayList<>();
        outgoing.add(new ArrayList<>(selected));
        for (int player = 1; player < 4; player++) {
            List<Integer> choices = new ArrayList<>(hands.get(player));
            final int seat = player;
            Collections.sort(choices, new Comparator<Integer>() {
                @Override public int compare(Integer a, Integer b) {
                    return Integer.compare(danger(seat, b), danger(seat, a));
                }
            });
            outgoing.add(new ArrayList<>(choices.subList(0, 3)));
        }
        int distance = PASS_STEP[passIndex()];
        for (int player = 0; player < 4; player++) hands.get(player).removeAll(outgoing.get(player));
        for (int player = 0; player < 4; player++) {
            int receiver = (player + distance) % 4;
            hands.get(receiver).addAll(outgoing.get(player));
            Collections.sort(hands.get(receiver));
        }
        selected.clear();
        openPlay();
    }

    private int points(int c) { return c == QUEEN_OF_SPADES ? 13 : suit(c) == HEARTS ? 1 : 0; }

    @Override List<Integer> legal(int player) {
        List<Integer> hand = hands.get(player);
        if (trick.isEmpty() && tricksWon == 0) return Collections.singletonList(0);
        if (trick.isEmpty() && heartsBroken) return hand;
        if (!trick.isEmpty()) {
            List<Integer> matching = ofSuit(hand, suit(trick.get(0)));
            if (!matching.isEmpty()) return matching;
            if (tricksWon > 0) return hand;
        }
        List<Integer> choices = new ArrayList<>();
        for (int c : hand) {
            boolean allowed = trick.isEmpty() ? suit(c) != HEARTS : points(c) == 0;
            if (allowed) choices.add(c);
        }
        return choices.isEmpty() ? hand : choices;
    }

    @Override int strength(int c, int led) { return suit(c) == led ? rank(c) : 0; }

    @Override int chooseCard(int player, List<Integer> legal) {
        int best = legal.get(0), highScore = Integer.MIN_VALUE;
        for (int c : legal) {
            int score;
            if (trick.isEmpty()) {
                score = -2 * rank(c) - countSuit(player, suit(c));
                if (c == QUEEN_OF_SPADES) score -= 40;
            } else if (suit(c) != suit(trick.get(0))) {
                score = 5 * points(c) + danger(player, c);
            } else if (rank(c) < rank(trick.get(winningIndex()))) {
                score = 100 + 3 * points(c) + rank(c);
            } else {
                boolean safeWin = tricksWon == 0 || (trick.size() == 3 && trickPoints() == 0);
                score = safeWin ? rank(c) : -rank(c);
                if (c == QUEEN_OF_SPADES) score -= 50;
            }
            if (score > highScore) { highScore = score; best = c; }
        }
        return best;
    }

    private int trickPoints() {
        int count = 0;
        for (int c : trick) count += points(c);
        return count;
    }

    @Override void onCard(int c) { if (suit(c) == HEARTS) heartsBroken = true; }

    @Override void award(int winner) {
        int points = trickPoints();
        penalties[winner] += points;
        message = won(winner) + " the trick" + (points == 0 ? "." : " for " + points + (points == 1 ? " point." : " points."));
        if (!hands.get(0).isEmpty()) return;
        int moon = -1;
        for (int i = 0; i < 4; i++) if (penalties[i] == 26) moon = i;
        for (int i = 0; i < 4; i++) totals[i] += moon < 0 ? penalties[i] : (i == moon ? 0 : 26);
        int low = Integer.MAX_VALUE, high = 0, countLow = 0, lowest = 0;
        for (int i = 0; i < 4; i++) {
            high = Math.max(high, totals[i]);
            if (totals[i] < low) { low = totals[i]; countLow = 1; lowest = i; }
            else if (totals[i] == low) countLow++;
        }
        if (high >= 100 && countLow == 1) {
            stage = Stage.MATCH;
            message = (lowest == 0 ? "You win" : NAMES[lowest] + " wins") + " with " + low + " points.";
        } else {
            stage = Stage.DEAL;
            message = moon < 0 ? "You took " + penalties[0] + (penalties[0] == 1 ? " point" : " points") + " this deal."
                    : NAMES[moon] + " shot the moon. Everyone else takes 26.";
        }
    }

    @Override public void act(String id) {
        if (stage != Stage.PASS) { handlePlay(id); return; }
        if ("pass".equals(id) && selected.size() == 3) { passCards(); return; }
        for (int c : hands.get(0)) {
            if (!cardId(c).equals(id)) continue;
            if (!selected.remove(c) && selected.size() < 3) selected.add(c);
            return;
        }
    }

    @Override void resetScores() { Arrays.fill(totals, 0); }

    @Override public View view() {
        View v = new View();
        v.phase = stage == Stage.PASS ? "Pass " + PASS_NAME[passIndex()] : phase(13);
        v.score = "Deal " + dealNumber + "  |  You " + totals[0] + " pts";
        v.status = stage == Stage.PASS ? "Choose three cards to pass " + PASS_NAME[passIndex()] + ".  " + selected.size() + " / 3"
                : stage == Stage.PLAY ? (trick.isEmpty() && tricksWon == 0 ? "Lead with the two of clubs." : playPrompt()) : message;
        List<Integer> enabled = stage == Stage.PASS ? new ArrayList<Integer>() : playable();
        if (stage == Stage.PASS) for (int c : hands.get(0)) {
            if (selected.size() < 3 || selected.contains(c)) enabled.add(c);
        }
        for (int p = 1; p < 4; p++) seat(v, p, totals[p] + " pts  /  " + penalties[p] + " taken");
        board(v, enabled, selected, "Your hand  /  " + penalties[0] + " taken");
        if (stage == Stage.PASS && selected.size() == 3) v.action("pass", "Pass cards");
        playButtons(v);
        return v;
    }

    @Override public String rules() {
        return "Lowest score wins. Pass three cards left, right, then across on successive deals. Keep your hand on the fourth.\n\n"
                + "The two of clubs opens. Follow suit if you can. Highest card of the led suit wins. "
                + "Each heart costs 1 point and the queen of spades costs 13. Avoid points on the first trick if possible. "
                + "A discarded heart breaks hearts. Before then, lead a heart only with an all-heart hand.\n\n"
                + "Take all 26 points to give 26 to each opponent instead. The match ends at 100 with a unique low score.";
    }
}

/** Clockwise seats start at the human player. The complete trick stays on view until collected. */
abstract class TrickGame implements Game {
    enum Stage { PASS, BID, PLAY, TRICK, DEAL, MATCH }
    static final String[] NAMES = { "You", "West", "North", "East" };
    static final String[] SUITS = { "Clubs", "Diamonds", "Spades", "Hearts" };
    private static final String[] RANKS = { "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K", "A" };
    final List<List<Integer>> hands = new ArrayList<>();
    final List<Integer> trick = new ArrayList<>(4);
    final boolean[] seen = new boolean[52];
    final Random random;
    Stage stage;
    int dealNumber, leader, turn, tricksWon;
    String message = "";

    TrickGame(long seed) {
        random = new Random(seed);
        for (int i = 0; i < 4; i++) hands.add(new ArrayList<Integer>());
    }

    abstract void deal();
    abstract void resetScores();
    abstract List<Integer> legal(int player);
    abstract int strength(int c, int led);
    abstract int chooseCard(int player, List<Integer> choices);
    abstract void award(int winner);
    void onCard(int c) {}

    static int suit(int c) { return c / 13; }
    static int rank(int c) { return c % 13 + 2; }
    static String face(int c) { return RANKS[c % 13] + "CDSH".charAt(suit(c)); }
    static String cardId(int c) { return "card-" + face(c); }
    static String won(int winner) { return winner == 0 ? "You won" : NAMES[winner] + " won"; }

    void dealCards(int lowestRank) {
        dealNumber++;
        tricksWon = 0;
        message = "";
        trick.clear();
        Arrays.fill(seen, false);
        for (List<Integer> hand : hands) hand.clear();
        List<Integer> deck = new ArrayList<>();
        for (int c = 0; c < 52; c++) if (rank(c) >= lowestRank) deck.add(c);
        Collections.shuffle(deck, random);
        for (int i = 0; i < deck.size(); i++) hands.get(i % 4).add(deck.get(i));
        for (List<Integer> hand : hands) Collections.sort(hand);
    }

    static List<Integer> ofSuit(List<Integer> cards, int suit) {
        List<Integer> found = new ArrayList<>();
        for (int c : cards) if (suit(c) == suit) found.add(c);
        return found;
    }

    int countSuit(int player, int suit) {
        int n = 0;
        for (int c : hands.get(player)) if (suit(c) == suit) n++;
        return n;
    }

    int winningIndex() {
        int led = suit(trick.get(0)), best = 0;
        for (int i = 1; i < trick.size(); i++) {
            if (strength(trick.get(i), led) > strength(trick.get(best), led)) best = i;
        }
        return best;
    }

    void startTrick(int first) {
        trick.clear();
        turn = leader = first;
        stage = Stage.PLAY;
        runBots();
    }

    private void runBots() {
        while (stage == Stage.PLAY && turn != 0) place(chooseCard(turn, legal(turn)));
    }

    private void place(int card) {
        hands.get(turn).remove(Integer.valueOf(card));
        trick.add(card);
        seen[card] = true;
        onCard(card);
        turn = (turn + 1) % 4;
        if (trick.size() == 4) {
            turn = (leader + winningIndex()) % 4;
            tricksWon++;
            stage = Stage.TRICK;
            award(turn);
        }
    }

    void handlePlay(String id) {
        if (stage == Stage.TRICK && "next".equals(id)) { startTrick(turn); return; }
        if (stage == Stage.DEAL && "deal".equals(id)) { deal(); return; }
        if (stage == Stage.MATCH && "restart".equals(id)) {
            resetScores();
            dealNumber = 0;
            deal();
            return;
        }
        if (stage != Stage.PLAY || turn != 0) return;
        for (int c : legal(0)) {
            if (cardId(c).equals(id)) { place(c); runBots(); return; }
        }
    }

    List<Integer> playable() {
        return stage == Stage.PLAY && turn == 0 ? legal(0) : Collections.<Integer>emptyList();
    }

    String phase(int count) {
        if (stage == Stage.DEAL) return "Deal complete";
        if (stage == Stage.MATCH) return "Match complete";
        return "Trick " + (stage == Stage.TRICK ? tricksWon : tricksWon + 1) + " of " + count;
    }

    String playPrompt() {
        if (trick.isEmpty()) return "Your lead. Choose a card.";
        if (countSuit(0, suit(trick.get(0))) > 0) return "Follow " + SUITS[suit(trick.get(0))].toLowerCase(java.util.Locale.ROOT) + ".";
        return "Choose a card from your hand.";
    }

    void seat(View v, int p, String note) {
        Group group = v.group(NAMES[p], "seat");
        group.note = note;
        if (!hands.get(p).isEmpty()) group.add("back", null);
    }

    void board(View v, List<Integer> enabled, Set<Integer> selected, String handLabel) {
        Group center = v.group("The trick", "center");
        for (int i = 0; i < trick.size(); i++) {
            Tile t = center.add(face(trick.get(i)), null);
            t.note = NAMES[(leader + i) % 4];
        }
        Group hand = v.group(handLabel, "hand");
        for (int card : hands.get(0)) {
            Tile tile = hand.add(face(card), enabled.contains(card) ? cardId(card) : null);
            tile.selected = selected.contains(card);
        }
    }

    void playButtons(View v) {
        if (stage == Stage.TRICK) v.action("next", "Next trick");
        if (stage == Stage.DEAL) v.action("deal", "Next deal");
        if (stage == Stage.MATCH) v.action("restart", "New match");
    }
}
