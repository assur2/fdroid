package club.cardtable.game;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;
import java.util.Random;

/** Draw-one Klondike, with unlimited redeals through the stock. */
public final class SolitaireGame implements Game {
    private static final int WASTE = 7;
    private static final int FOUNDATION = 8;
    private static final int STOCK = 12;
    private final Random random;
    private final Deque<Position> history = new ArrayDeque<>();
    private Position board;
    private int source = -1;
    private int start;
    private String message;

    private static final class Position {
        final List<List<Integer>> piles = new ArrayList<>();
        final int[] covered = new int[7];
        int moves;

        Position() {
            for (int i = 0; i <= STOCK; i++) piles.add(new ArrayList<Integer>());
        }

        Position(Position other) {
            for (List<Integer> pile : other.piles) piles.add(new ArrayList<>(pile));
            System.arraycopy(other.covered, 0, covered, 0, covered.length);
            moves = other.moves;
        }
    }

    public SolitaireGame(long seed) {
        random = new Random(seed);
        deal();
    }

    private void deal() {
        board = new Position();
        List<Integer> deck = pile(STOCK);
        for (int i = 0; i < 52; i++) deck.add(i);
        Collections.shuffle(deck, random);
        for (int row = 0; row < 7; row++) {
            for (int col = row; col < 7; col++) pile(col).add(pop(deck));
        }
        for (int col = 0; col < 7; col++) board.covered[col] = col;
        history.clear();
        source = -1;
        message = "Choose a face-up card or draw from the stock.";
    }

    private List<Integer> pile(int id) { return board.piles.get(id); }
    private static int pop(List<Integer> cards) { return cards.remove(cards.size() - 1); }
    private static int rank(int card) { return card % 13 + 1; }
    private static int suit(int card) { return card / 13; }
    private static boolean red(int card) { return suit(card) == 1 || suit(card) == 2; }
    private int top(int id) { return pile(id).get(pile(id).size() - 1); }

    private static boolean stacks(int upper, int lower) {
        return rank(upper) + 1 == rank(lower) && red(upper) != red(lower);
    }

    private boolean selectable(int id, int index) {
        if (id < 0 || id >= STOCK || index < 0 || index >= pile(id).size()) return false;
        if (id >= WASTE) return index == pile(id).size() - 1;
        if (index < board.covered[id]) return false;
        for (int i = index + 1; i < pile(id).size(); i++) {
            if (!stacks(pile(id).get(i), pile(id).get(i - 1))) return false;
        }
        return true;
    }

    private boolean canMove(int from, int index, int to) {
        if (from == to || to < 0 || to == WASTE || to >= STOCK || !selectable(from, index)) return false;
        int first = pile(from).get(index);
        if (to < WASTE) return pile(to).isEmpty() ? rank(first) == 13 : stacks(first, top(to));
        return index == pile(from).size() - 1 && suit(first) == to - FOUNDATION && rank(first) == pile(to).size() + 1;
    }

    private void checkpoint() {
        if (history.size() == 100) history.removeLast();
        history.push(new Position(board));
        board.moves++;
    }

    private void move(int from, int index, int to) {
        checkpoint();
        List<Integer> run = pile(from).subList(index, pile(from).size());
        pile(to).addAll(run);
        run.clear();
        if (from < WASTE && board.covered[from] > 0 && pile(from).size() == board.covered[from]) {
            board.covered[from]--;
        }
        source = -1;
        message = won() ? "All four suits complete. You win!" : "Choose a card or draw from the stock.";
    }

    private void draw() {
        if (pile(STOCK).isEmpty() && pile(WASTE).isEmpty()) return;
        checkpoint();
        source = -1;
        if (pile(STOCK).isEmpty()) {
            while (!pile(WASTE).isEmpty()) pile(STOCK).add(pop(pile(WASTE)));
            message = "Stock recycled. Draw to turn over its first card.";
        } else {
            pile(WASTE).add(pop(pile(STOCK)));
            message = "Play the waste card or choose another move.";
        }
    }

    private void undo() {
        if (history.isEmpty()) return;
        board = history.pop();
        source = -1;
        message = "Move undone.";
    }

    private boolean won() {
        for (int i = FOUNDATION; i < STOCK; i++) if (pile(i).size() != 13) return false;
        return true;
    }

    private void touch(int id, int index) {
        if (id == STOCK) { draw(); return; }
        if (source >= 0 && canMove(source, start, id)) { move(source, start, id); return; }
        if (id == source && index == start) {
            source = -1;
            message = "Selection cleared.";
            return;
        }
        if (selectable(id, index)) {
            source = id;
            start = index;
            message = "Choose a foundation or column for your selection.";
        }
    }

    private static String cardName(int card) {
        String[] ranks = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        String[] suits = {"clubs", "diamonds", "hearts", "spades"};
        return ranks[rank(card) - 1] + " of " + suits[suit(card)];
    }

    private void hint() {
        int best = -1;
        int bestTo = -1;
        source = -1;
        for (int from = 0; from <= WASTE; from++) {
            int first = from == WASTE ? Math.max(0, pile(from).size() - 1) : board.covered[from];
            for (int index = first; index < pile(from).size(); index++) {
                for (int to = 0; to < STOCK; to++) {
                    if (!canMove(from, index, to)) continue;
                    if (to < WASTE && pile(to).isEmpty() && index == 0 && from < WASTE) continue;
                    int priority = to >= FOUNDATION ? 6 : 1;
                    if (from < WASTE && index > 0 && index == board.covered[from]) priority += 7;
                    if (from == WASTE) priority += 2;
                    if (priority > best) {
                        best = priority; source = from; start = index; bestTo = to;
                    }
                }
            }
        }
        if (best >= 0) {
            String target = bestTo >= FOUNDATION ? "its foundation" : "column " + (bestTo + 1);
            message = "Move the " + cardName(pile(source).get(start)) + " to " + target + ".";
        } else if (!pile(STOCK).isEmpty()) message = "Draw a card from the stock.";
        else if (!pile(WASTE).isEmpty()) message = "Recycle the waste to look through the stock again.";
        else message = "Try undoing a move or moving a foundation card back to a column.";
    }

    private static String face(int card) {
        String[] ranks = {"A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"};
        return ranks[card % 13] + "CDHS".charAt(suit(card));
    }

    private void single(View view, String label, int id) {
        Group group = view.group(label, "stocks");
        int index = pile(id).size() - 1;
        String value = index < 0 ? "empty" : (id == STOCK ? "back" : face(top(id)));
        String action = null;
        if (id == STOCK) action = "draw";
        else if (index >= 0 || id >= FOUNDATION) action = "pile/" + id + "/" + index;
        Tile tile = group.add(value, action);
        tile.selected = source == id;
    }

    @Override public View view() {
        View v = new View();
        v.phase = won() ? "Deal complete" : "Draw one";
        v.status = message;
        int settled = 0;
        for (int id = FOUNDATION; id < STOCK; id++) settled += pile(id).size();
        v.score = settled + " / 52 home  ·  " + board.moves + " moves";
        single(v, pile(STOCK).isEmpty() && !pile(WASTE).isEmpty() ? "Recycle" : "Stock · " + pile(STOCK).size(), STOCK);
        single(v, "Waste", WASTE);
        String[] suits = {"Clubs", "Diamonds", "Hearts", "Spades"};
        for (int i = 0; i < 4; i++) single(v, suits[i], FOUNDATION + i);
        for (int id = 0; id < 7; id++) {
            Group group = v.group("Column " + (id + 1), "column");
            if (pile(id).isEmpty()) group.add("empty", "pile/" + id + "/-1");
            for (int i = 0; i < pile(id).size(); i++) {
                if (i < board.covered[id]) group.add("back", null);
                else {
                    Tile tile = group.add(face(pile(id).get(i)), "pile/" + id + "/" + i);
                    tile.selected = id == source && i >= start;
                }
            }
        }
        if (!won()) v.action("hint", "Hint");
        if (!history.isEmpty()) v.action("undo", "Undo");
        v.action("deal", "New deal");
        return v;
    }

    @Override public void act(String id) {
        if (id == null) return;
        if (id.equals("deal")) { deal(); return; }
        if (id.equals("undo")) { undo(); return; }
        if (won()) return;
        if (id.equals("hint")) { hint(); return; }
        if (id.equals("draw")) { draw(); return; }
        String[] parts = id.split("/");
        if (parts.length != 3 || !parts[0].equals("pile")) return;
        try {
            int pileId = Integer.parseInt(parts[1]);
            int index = Integer.parseInt(parts[2]);
            if (pileId >= 0 && pileId < STOCK && index >= -1 && index < pile(pileId).size()) touch(pileId, index);
        } catch (NumberFormatException ignored) { }
    }

    @Override public String rules() {
        return "Move all 52 cards to the four suit foundations, starting with each ace and finishing with its king.\n\n"
                + "On the seven columns, place a card on the next higher rank of the opposite color. Tap a face-up card to select it and the run beneath it, then tap the destination. Only kings and their runs can fill an empty column.\n\n"
                + "Draw one card at a time from the stock. Play the top waste card, or tap the empty stock to recycle the waste. Foundation cards can return to columns. Use Hint to select a suggested move or Undo to take a move back.";
    }
}
