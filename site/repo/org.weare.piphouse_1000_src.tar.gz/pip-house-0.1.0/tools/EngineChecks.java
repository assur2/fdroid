package club.cardtable.game;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

/** Standalone Windows/headless rules checks. No graphics or platform backend is required. */
public final class EngineChecks {
    private static final Random PICK = new Random(253711);
    private static int trickCount, skipGames, solitaireMoves, pokerHands;

    private static void check(boolean condition, String detail) {
        if (!condition) throw new AssertionError(detail);
    }

    @SuppressWarnings("unchecked")
    private static <T> T field(Object object, String key) {
        try {
            Field f = object.getClass().getDeclaredField(key);
            f.setAccessible(true);
            return (T) f.get(object);
        } catch (ReflectiveOperationException e) { throw new AssertionError(key, e); }
    }

    private static boolean button(View v, String id) {
        for (Action a : v.actions) if (a.id.equals(id)) return true;
        return false;
    }

    private static int rank(int c) { return c % 13 + 2; }
    private static int suit(int c) { return c / 13; }

    // Independent ordered strings express the different winning orders in the two trick games.
    private static int trickValue(int c, int led, int trump) {
        String ranks = trump < 0 ? "23456789TJQKA" : suit(c) == trump ? "78QKTA9J" : "789JQKTA";
        int power = ranks.indexOf("23456789TJQKA".charAt(rank(c) - 2));
        return (suit(c) == trump ? 40 : suit(c) == led ? 20 : 0) + (suit(c) == trump || suit(c) == led ? power : 0);
    }

    private static int klaverPoints(int c, int trump) {
        switch (rank(c)) {
            case 9: return suit(c) == trump ? 14 : 0;
            case 10: return 10;
            case 11: return suit(c) == trump ? 20 : 2;
            case 12: return 3;
            case 13: return 4;
            case 14: return 11;
            default: return 0;
        }
    }

    private static int roem(List<Integer> cards, int trump) {
        Set<Integer> ranks = new HashSet<>();
        for (int c : cards) ranks.add(rank(c));
        if (ranks.size() == 1) return 100;
        int award = cards.contains(trump * 13 + 10) && cards.contains(trump * 13 + 11) ? 20 : 0;
        for (int c : cards) {
            if (rank(c) > 12 || !cards.contains(c + 1) || !cards.contains(c + 2)) continue;
            if (rank(c) < 12 && cards.contains(c + 3)) return award + 50;
        }
        for (int c : cards) if (rank(c) <= 12 && cards.contains(c + 1) && cards.contains(c + 2)) return award + 20;
        return award;
    }

    private static int penalty(int card) { return card == 36 ? 13 : suit(card) == 3 ? 1 : 0; }

    /** Reconstruct each player's hand immediately before their play and check all four choices. */
    private static int verifyTrick(TrickGame g, Set<Integer> played, int trump, boolean broken) {
        check(g.trick.size() == 4, "Four plays in a trick");
        int led = suit(g.trick.get(0)), best = 0, points = 0;
        for (int i = 0; i < 4; i++) {
            int c = g.trick.get(i), p = (g.leader + i) % 4, winner = (g.leader + best) % 4;
            check(played.add(c), "Played a card twice");
            List<Integer> hand = new ArrayList<>(g.hands.get(p));
            hand.add(c);
            boolean canFollow = false, canOver = false, canDiscard = false, nonPoint = false, nonHeart = false;
            int prev = g.trick.get(best);
            for (int other : hand) {
                canFollow |= suit(other) == led;
                canDiscard |= suit(other) != trump;
                canOver |= suit(other) == trump && trickValue(other, led, trump) > trickValue(prev, led, trump);
                nonPoint |= penalty(other) == 0;
                nonHeart |= suit(other) != 3;
            }
            if (i > 0 && canFollow) check(suit(c) == led, "Follow suit");
            if (trump < 0) {
                if (g.tricksWon == 1 && i == 0) check(c == 0, "Opening two of clubs");
                if (g.tricksWon == 1 && !canFollow && nonPoint) check(penalty(c) == 0, "First trick point discard");
                if (i == 0 && !broken && nonHeart) check(suit(c) != 3, "Premature heart lead");
                points += penalty(c);
            } else {
                if (i > 0 && (led == trump || (!canFollow && winner % 2 != p % 2)) && canOver) {
                    check(suit(c) == trump && trickValue(c, led, trump) > trickValue(prev, led, trump), "Compulsory overtrump");
                }
                if (i > 0 && !canFollow && led != trump && suit(prev) == trump && suit(c) == trump && canDiscard) {
                    check(trickValue(c, led, trump) > trickValue(prev, led, trump), "Avoidable undertrump");
                }
                points += klaverPoints(c, trump);
            }
            if (trickValue(c, led, trump) > trickValue(prev, led, trump)) best = i;
        }
        check(g.turn == (g.leader + best) % 4, "Wrong trick winner");
        if (trump >= 0) points += roem(g.trick, trump) + (g.tricksWon == 8 ? 10 : 0);
        Set<Integer> all = new HashSet<>(played);
        for (List<Integer> hand : g.hands) for (int c : hand) check(all.add(c), "Card held by two players or already played");
        check(all.size() == (trump < 0 ? 52 : 32), "Trick game card conservation");
        trickCount++;
        return points;
    }

    private static void trickMatch(TrickGame g) {
        boolean hearts = g instanceof HeartsGame, broken = false;
        Set<Integer> played = new HashSet<>();
        int[] deal = new int[4], scores = new int[4], tricks = new int[4];
        for (int safety = 0; safety < 5000; safety++) {
            View v = g.view();
            switch (g.stage) {
                case PASS:
                    int left = 3;
                    Group hand = v.groups.get(v.groups.size() - 1);
                    List<Tile> choices = new ArrayList<>(hand.tiles);
                    Collections.shuffle(choices, PICK);
                    Set<Integer> passed = new HashSet<>();
                    for (Tile tile : choices) {
                        g.act(tile.id);
                        for (int card : g.hands.get(0)) if (TrickGame.cardId(card).equals(tile.id)) passed.add(card);
                        if (--left == 0) break;
                    }
                    check(button(g.view(), "pass"), "Selecting three cards enables passing");
                    g.act("pass");
                    int receiver = new int[]{1,3,2}[(g.dealNumber - 1) % 4];
                    Set<Integer> received = new HashSet<>(g.hands.get(receiver));
                    for (int i = 0; i < g.trick.size(); i++) if ((g.leader + i) % 4 == receiver) received.add(g.trick.get(i));
                    check(received.containsAll(passed), "All three cards must travel in the correct direction");
                    break;
                case BID: g.act(v.actions.get(PICK.nextInt(v.actions.size())).id); break;
                case PLAY:
                    List<String> actions = new ArrayList<>();
                    for (Group group : v.groups) if (group.layout.equals("hand")) {
                        for (Tile tile : group.tiles) if (tile.id != null) actions.add(tile.id);
                    }
                    check(!actions.isEmpty(), "Human must have a legal move");
                    g.act(actions.get(PICK.nextInt(actions.size())));
                    break;
                default:
                    int trump = hearts ? -1 : EngineChecks.<Integer>field(g, "trump");
                    int award = verifyTrick(g, played, trump, broken);
                    int winner = hearts ? g.turn : g.turn % 2;
                    deal[winner] += award;
                    tricks[winner]++;
                    for (int c : g.trick) broken |= suit(c) == 3;
                    if (g.stage == TrickGame.Stage.TRICK) { g.act("next"); break; }
                    if (hearts) {
                        int moon = -1, total = 0;
                        for (int p = 0; p < 4; p++) { total += deal[p]; if (deal[p] == 26) moon = p; }
                        check(total == 26 && played.size() == 52, "Hearts deal score");
                        for (int p = 0; p < 4; p++) scores[p] += moon < 0 ? deal[p] : (p == moon ? 0 : 26);
                    } else {
                        check(played.size() == 32, "Klaverjassen hand length");
                        int caller = EngineChecks.<Integer>field(g, "declarer") % 2, opponent = 1 - caller;
                        if (tricks[caller] == 8) deal[caller] += 100;
                        if (deal[caller] <= deal[opponent]) { deal[opponent] += deal[caller]; deal[caller] = 0; }
                        scores[0] += deal[0]; scores[1] += deal[1];
                    }
                    int[] totals = field(g, "totals");
                    for (int p = 0; p < totals.length; p++) check(totals[p] == scores[p], "Cumulative match points");
                    if (g.stage == TrickGame.Stage.MATCH) {
                        if (hearts) check(Arrays.stream(scores).max().getAsInt() >= 100, "Hearts target");
                        else check(g.dealNumber == 16, "Pitje length");
                        g.act("restart");
                        check(g.dealNumber == 1, "New match");
                        return;
                    }
                    Arrays.fill(deal, 0); Arrays.fill(tricks, 0);
                    broken = false; played.clear(); g.act("deal");
            }
        }
        throw new AssertionError("Trick match stalled");
    }

    private static boolean red(int card) { return suit(card) == 1 || suit(card) == 2; }

    private static String position(Object board) {
        return field(board, "piles") + Arrays.toString((int[]) field(board, "covered")) + field(board, "moves");
    }

    private static void verifySolitaire(Object board) {
        List<List<Integer>> piles = field(board, "piles");
        int[] covered = field(board, "covered");
        Set<Integer> cards = new HashSet<>();
        for (int p = 0; p < 13; p++) {
            List<Integer> pile = piles.get(p);
            for (int i = 0; i < pile.size(); i++) {
                int c = pile.get(i);
                check(c >= 0 && c < 52 && cards.add(c), "Solitaire duplicate");
                if (p < 7 && i > covered[p]) {
                    int lower = pile.get(i - 1);
                    check(c % 13 + 1 == lower % 13 && red(c) != red(lower), "Tableau ordering");
                }
                if (p >= 8 && p < 12) check(suit(c) == p - 8 && c % 13 == i, "Foundation ordering");
            }
            if (p < 7) check(covered[p] >= 0 && covered[p] <= Math.max(0, pile.size() - 1), "Automatic flip");
        }
        check(cards.size() == 52, "Solitaire card conservation");
    }

    private static void solitaire(long seed) {
        SolitaireGame g = new SolitaireGame(seed);
        Object initial = field(g, "board");
        String initialState = position(initial);
        // An exposed card can never move to another suit's foundation.
        List<List<Integer>> initialPiles = field(initial,"piles");
        int invalidFoundation = 8 + (suit(initialPiles.get(0).get(0)) + 1) % 4;
        g.act("pile/0/0"); g.act("pile/" + invalidFoundation + "/-1");
        check(initialState.equals(position(field(g,"board"))), "Illegal foundation move changed board");
        g.act("pile/0/0");
        ArrayList<Integer> stock = new ArrayList<>(EngineChecks.<List<List<Integer>>>field(initial, "piles").get(12));
        for (int i = 0; i < 25; i++) g.act("draw");
        check(stock.equals(EngineChecks.<List<List<Integer>>>field(field(g, "board"), "piles").get(12)), "Waste recycle order");
        for (int i = 0; i < 25; i++) g.act("undo");
        check(initialState.equals(position(field(g, "board"))), "Undo entire stock cycle");
        for (int step = 0; step < 220; step++) {
            Object board = field(g, "board");
            verifySolitaire(board);
            String before = position(board);
            List<List<Integer>> piles = field(board, "piles");
            int[] covered = field(board, "covered");
            List<String[]> moves = new ArrayList<>();
            for (int p = 0; p < 12; p++) {
                List<Integer> pile = piles.get(p);
                int from = p < 7 ? covered[p] : Math.max(0, pile.size() - 1);
                for (int i = from; i < pile.size(); i++) {
                    int first = pile.get(i);
                    for (int dest = 0; dest < 12; dest++) {
                        if (p == dest || dest == 7) continue;
                        List<Integer> target = piles.get(dest);
                        boolean fits = dest >= 8 ? (i == pile.size() - 1 && suit(first) == dest - 8 && first % 13 == target.size())
                                : target.isEmpty() ? first % 13 == 12
                                : first % 13 + 1 == target.get(target.size() - 1) % 13 && red(first) != red(target.get(target.size() - 1));
                        if (fits) moves.add(new String[]{"pile/" + p + "/" + i, "pile/" + dest + "/" + (target.size() - 1)});
                    }
                }
            }
            if (!moves.isEmpty() && PICK.nextInt(4) != 0) {
                String[] move = moves.get(PICK.nextInt(moves.size()));
                g.act(move[0]); g.act(move[1]);
                check(!before.equals(position(field(g, "board"))), "Legal solitaire move rejected " + Arrays.toString(move));
                solitaireMoves++;
            } else g.act("draw");
            verifySolitaire(field(g, "board"));
            if (PICK.nextInt(8) == 0 && !before.equals(position(field(g, "board")))) {
                g.act("undo");
                check(before.equals(position(field(g, "board"))), "Undo restored wrong position");
            }
        }
    }

    private static void solitaireFinish() {
        SolitaireGame g = new SolitaireGame(228);
        Object board = field(g, "board");
        List<List<Integer>> piles = field(board, "piles");
        for (List<Integer> pile : piles) pile.clear();
        Arrays.fill((int[])field(board,"covered"), 0);
        for (int c = 0; c < 52; c++) piles.get(c == 51 ? 0 : 8 + suit(c)).add(c);
        verifySolitaire(board);
        String before = position(board);
        g.act("pile/0/0"); g.act("pile/11/11");
        check(g.view().phase.equals("Deal complete"), "Finishing fourth foundation");
        verifySolitaire(field(g,"board"));
        g.act("undo");
        check(before.equals(position(field(g,"board"))), "Undo winning tableau move");
    }

    private static void skipCheck(SkipBoGame g) {
        int[] count = new int[13];
        List<List<Integer>> builds = field(g, "builds");
        List<List<Integer>> cards = new ArrayList<>(builds);
        cards.add(field(g, "deck")); cards.add(field(g, "recycle"));
        for (Object p : (Object[])field(g, "players")) {
            List<Integer> hand = field(p, "hand");
            check(hand.size() <= 5, "Skip-Bo hand limit");
            cards.add(hand); cards.add(field(p, "stock"));
            cards.addAll(EngineChecks.<List<List<Integer>>>field(p, "discards"));
        }
        for (List<Integer> pile : cards) for (int c : pile) count[c]++;
        for (int i = 0; i < 13; i++) check(count[i] == (i == 0 ? 18 : 12), "Skip-Bo physical card count");
        for (List<Integer> pile : builds) {
            check(pile.size() < 12, "Completed build must recycle");
            for (int i = 0; i < pile.size(); i++) check(pile.get(i) == i + 1 || pile.get(i) == 0, "Build sequence");
        }
    }

    private static void skipBo(long seed) {
        SkipBoGame g = new SkipBoGame(seed);
        for (int step = 0; step < 5000; step++) {
            skipCheck(g);
            View v = g.view();
            if (button(v, "deal")) {
                Object[] players = field(g, "players");
                check(EngineChecks.<List<Integer>>field(players[0], "stock").isEmpty()
                        || EngineChecks.<List<Integer>>field(players[1], "stock").isEmpty(), "Skip-Bo stock winner");
                g.act("deal"); skipCheck(g); skipGames++; return;
            }
            Group hand = null;
            List<Tile> sources = new ArrayList<>(), builds = new ArrayList<>();
            for (Group group : v.groups) {
                if (group.layout.equals("reserve")) sources.add(group.tiles.get(0));
                if (group.layout.equals("build")) builds.add(group.tiles.get(0));
                if (group.layout.equals("hand")) { hand = group; sources.addAll(group.tiles); }
            }
            Tile source = null, dest = null;
            for (Tile s : sources) {
                for (Tile b : builds) if (s.face.equals("wild") || s.face.equals(b.note)) { source = s; dest = b; break; }
                if (source != null) break;
            }
            if (source != null) { g.act(source.id); g.act(dest.id); }
            else if (hand != null && !hand.tiles.isEmpty()) {
                g.act(hand.tiles.get(PICK.nextInt(hand.tiles.size())).id);
                g.act("discard/" + PICK.nextInt(4));
            } else { check(button(v, "pass"), "Empty hand pass"); g.act("pass"); }
        }
        throw new AssertionError("Skip-Bo stuck");
    }

    private static int pokerCard(String card) {
        return "CDHS".indexOf(card.charAt(1)) * 13 + "23456789TJQKA".indexOf(card.charAt(0));
    }

    private static void pokerEvaluation() {
        int[] categories = new int[9], five = new int[5];
        for (five[0] = 0; five[0] < 48; five[0]++)
            for (five[1] = five[0] + 1; five[1] < 49; five[1]++)
                for (five[2] = five[1] + 1; five[2] < 50; five[2]++)
                    for (five[3] = five[2] + 1; five[3] < 51; five[3]++)
                        for (five[4] = five[3] + 1; five[4] < 52; five[4]++)
                            categories[PokerGame.evaluate(five) >>> 20]++;
        check(Arrays.equals(categories, new int[]{1302540,1098240,123552,54912,10200,5108,3744,624,40}), "Five-card category census");
        List<Integer> deck = new ArrayList<>();
        for (int i = 0; i < 52; i++) deck.add(i);
        for (int trial = 0; trial < 4000; trial++) {
            Collections.shuffle(deck, PICK);
            int[] seven = new int[7];
            for (int n = 0; n < 7; n++) seven[n] = deck.get(n);
            int best = 0;
            for (int omit1 = 0; omit1 < 7; omit1++) for (int omit2 = omit1 + 1; omit2 < 7; omit2++) {
                int k = 0;
                for (int i = 0; i < 7; i++) if (i != omit1 && i != omit2) five[k++] = seven[i];
                best = Math.max(best, PokerGame.evaluate(five));
            }
            check(PokerGame.evaluate(seven) == best, "Best five out of seven");
        }
    }

    private static void sidePot(boolean split) throws ReflectiveOperationException {
        PokerGame g = new PokerGame(322);
        int[][] pockets = field(g, "pocket");
        String[] fixed = {"AS","AH","KS","KH","QS","QH","JS","JH"};
        for (int i = 0; i < 8; i++) pockets[i / 2][i % 2] = pokerCard(fixed[i]);
        String[] community = split ? new String[]{"2C","3C","4C","5C","6C"} : new String[]{"2C","4D","6H","8S","TC"};
        int[] board = field(g, "board"), stack = field(g, "stack"), paid = field(g, "invested");
        for (int i = 0; i < 5; i++) board[i] = pokerCard(community[i]);
        Arrays.fill(stack, 0);
        boolean[] folded = field(g,"folded");
        Arrays.fill(folded, false);
        int[] contributions = split ? new int[]{1,1,1,0} : new int[]{10,30,50,50};
        System.arraycopy(contributions, 0, paid, 0, 4);
        if (split) folded[2] = folded[3] = true;
        Method finish = PokerGame.class.getDeclaredMethod("finish", boolean.class);
        finish.setAccessible(true);
        finish.invoke(g, true);
        // Dealer is seat one on the first deal. Seat zero is the first eligible clockwise winner.
        check(Arrays.equals(stack, split ? new int[]{2,1,0,0} : new int[]{40,60,40,0}), "Side pots and odd-chip ties");
    }

    private static void pokerPlay(long seed) {
        PokerGame g = new PokerGame(seed);
        for (int step = 0; step < 600; step++) {
            View v = g.view();
            int[] chips = field(g,"stack"), paid = field(g,"invested");
            boolean complete = field(g,"complete");
            int total = 0;
            for (int i = 0; i < 4; i++) {
                check(chips[i] >= 0 && paid[i] >= 0, "Negative chips");
                total += chips[i] + (complete ? 0 : paid[i]);
            }
            check(total == 4000, "Lost chips");
            if (complete) { pokerHands++; g.act(button(v,"next") ? "next" : "table"); continue; }
            check(button(v,"call") && button(v,"fold"), "Poker action missing");
            int behavior = PICK.nextInt(10);
            if (behavior < 2) g.act("fold");
            else if (behavior < 6 && button(v,"raise")) {
                g.act("raise");
                check(button(g.view(),"commit"), "Bet sizing");
                g.act("step"); g.act("more"); g.act("less");
                if (behavior == 2) g.act("max");
                if (behavior == 3) { g.act("back"); g.act("call"); } else g.act("commit");
            } else g.act("call");
        }
    }

    public static void main(String[] args) throws Exception {
        for (int seed = 0; seed < 10; seed++) {
            trickMatch(new HeartsGame(seed)); trickMatch(new KlaverjassenGame(seed));
            solitaire(seed); skipBo(seed);
        }
        System.out.println("20 trick-game matches, " + trickCount + " independently scored tricks");
        solitaireFinish();
        System.out.println(solitaireMoves + " tableau/foundation moves checked, plus stock cycles, undo and winning move");
        System.out.println(skipGames + " complete Skip-Bo games, each state checked for all 162 cards");
        pokerEvaluation(); sidePot(false); sidePot(true);
        for (int seed = 0; seed < 4; seed++) pokerPlay(seed);
        System.out.println("2,598,960 poker hands classified, 4,000 seven-card comparisons, side pots and split pots");
        System.out.println(pokerHands + " Hold'em hands completed with chip conservation");
    }
}
