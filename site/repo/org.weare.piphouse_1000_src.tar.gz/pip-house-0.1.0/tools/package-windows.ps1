param(
    [string]$Jdk,
    [ValidatePattern('^\d+\.\d+\.\d+$')]
    [string]$Version = '0.1.0',
    [switch]$DependenciesOnly
)

$ErrorActionPreference = 'Stop'
$project = Split-Path -Parent $PSScriptRoot
$build = Join-Path $project '.build'
$libs = Join-Path $build 'windows-libs'
$metadata = Join-Path $build 'windows-metadata'
$gdxVersion = '1.13.1'
$main = 'club.cardtable.desktop.DesktopLauncher'
$null = [IO.Directory]::CreateDirectory($libs)
$null = [IO.Directory]::CreateDirectory($metadata)

function Get-Artifact([string]$group, [string]$artifact, [string]$version, [string]$classifier, [string]$extension) {
    $name = "$artifact-$version"
    if ($classifier) { $name += "-$classifier" }
    $name += ".$extension"
    $directory = if ($extension -eq 'jar') { $libs } else { $metadata }
    $target = Join-Path $directory $name
    if (-not [IO.File]::Exists($target)) {
        $groupPath = $group.Replace('.', '/')
        $url = "https://repo.maven.apache.org/maven2/$groupPath/$artifact/$version/$name"
        $download = "$target.$([Guid]::NewGuid().ToString('N')).partial"
        try {
            & curl.exe --location --fail --silent --show-error --retry 2 --output $download $url
            if ($LASTEXITCODE -ne 0) { throw "Failed to download $name" }
            [IO.File]::Move($download, $target)
        } finally {
            if ([IO.File]::Exists($download)) { [IO.File]::Delete($download) }
        }
    }
    return $target
}

function Assert-ProjectPath([string]$path) {
    $root = [IO.Path]::GetFullPath($project).TrimEnd('\') + '\'
    if (-not [IO.Path]::GetFullPath($path).StartsWith($root, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Build output must be inside the project: $path"
    }
}

# Both published POMs pin concrete versions. Include the Java jars and the native libraries for x64 Windows.
$jars = [Collections.Generic.SortedSet[string]]::new([StringComparer]::Ordinal)
foreach ($module in @('gdx', 'gdx-backend-lwjgl3')) {
    $null = $jars.Add((Get-Artifact 'com.badlogicgames.gdx' $module $gdxVersion '' 'jar'))
    $pomFile = Get-Artifact 'com.badlogicgames.gdx' $module $gdxVersion '' 'pom'
    [xml]$pom = [IO.File]::ReadAllText($pomFile)
    foreach ($dependency in $pom.project.dependencies.dependency) {
        $classifier = [string]$dependency.classifier
        if ($classifier -and $classifier -ne 'natives-windows') { continue }
        if ($dependency.scope -in @('test', 'provided')) { continue }
        $null = $jars.Add((Get-Artifact $dependency.groupId $dependency.artifactId $dependency.version $classifier 'jar'))
    }
}
$null = $jars.Add((Get-Artifact 'com.badlogicgames.gdx' 'gdx-platform' $gdxVersion 'natives-desktop' 'jar'))
if ($DependenciesOnly) {
    Write-Output "Windows classpath ready: $libs\*"
    return
}

if (-not $Jdk) {
    $Jdk = Join-Path $build 'jdk'
    if (-not [IO.File]::Exists((Join-Path $Jdk 'bin/jpackage.exe'))) { $Jdk = $env:JAVA_HOME }
}
if (-not $Jdk -or -not [IO.File]::Exists((Join-Path $Jdk 'bin/jpackage.exe'))) {
    throw 'Set JAVA_HOME or pass -Jdk with the path to a 64-bit Windows JDK 17 installation.'
}
$bin = Join-Path $Jdk 'bin'
$assets = Join-Path $project 'assets'
$stage = Join-Path $build ('windows-' + [Guid]::NewGuid().ToString('N'))
$classes = Join-Path $stage 'classes'
$inputDir = Join-Path $stage 'app'
$images = Join-Path $stage 'images'
foreach ($directory in @($classes, $inputDir, $images)) { $null = [IO.Directory]::CreateDirectory($directory) }

$sourceRoots = @((Join-Path $project 'core/src/main/java'), (Join-Path $project 'desktop/src/main/java'))
$sources = @(Get-ChildItem -LiteralPath $sourceRoots -Recurse -File -Filter '*.java' | ForEach-Object { $_.FullName })
& (Join-Path $bin 'javac.exe') -encoding UTF-8 --release 8 -classpath "$libs\*" -d $classes @sources
if ($LASTEXITCODE -ne 0) { throw 'Java compilation failed.' }

$manifest = @('Manifest-Version: 1.0', "Main-Class: $main")
$names = @($jars | ForEach-Object { [IO.Path]::GetFileName($_) })
$manifest += 'Class-Path: ' + $names[0]
for ($i = 1; $i -lt $names.Length; $i++) { $manifest += '  ' + $names[$i] }
$manifest += ''
$manifestPath = Join-Path $stage 'MANIFEST.MF'
[IO.File]::WriteAllLines($manifestPath, [string[]]$manifest, [Text.Encoding]::ASCII)
foreach ($jarFile in $jars) { [IO.File]::Copy($jarFile, (Join-Path $inputDir ([IO.Path]::GetFileName($jarFile)))) }
& (Join-Path $bin 'jar.exe') --create --file (Join-Path $inputDir 'PipHouse.jar') --manifest $manifestPath -C $classes . -C $assets .
if ($LASTEXITCODE -ne 0) { throw 'Application JAR assembly failed.' }

# Windows icon directories accept a 256-pixel PNG payload. Preserve the original artwork and transparency.
$png = [IO.File]::ReadAllBytes((Join-Path $assets 'icon.png'))
if ($png.Length -lt 24 -or [BitConverter]::ToString($png, 16, 8) -ne '00-00-01-00-00-00-01-00') {
    throw 'assets/icon.png should be a 256 by 256 PNG.'
}
$icon = Join-Path $stage 'PipHouse.ico'
$writer = [IO.BinaryWriter]::new([IO.File]::Create($icon))
try {
    $writer.Write([byte[]](0,0,1,0,1,0,0,0,0,0,1,0,32,0))
    $writer.Write([int]$png.Length)
    $writer.Write([int]22)
    $writer.Write($png)
} finally { $writer.Dispose() }

& (Join-Path $bin 'jpackage.exe') --type app-image --name 'Pip House' --app-version $Version --input $inputDir --main-jar PipHouse.jar --main-class $main --dest $images --icon $icon --add-modules 'java.base,java.desktop,java.logging,java.management,jdk.unsupported,jdk.crypto.ec'
if ($LASTEXITCODE -ne 0) { throw 'Windows application image creation failed.' }

$image = Join-Path $images 'Pip House'
$zipName = 'Pip-House-Windows-x64.zip'
$zip = Join-Path $stage $zipName
Add-Type -AssemblyName System.IO.Compression.FileSystem
[IO.Compression.ZipFile]::CreateFromDirectory($image, $zip, [IO.Compression.CompressionLevel]::Optimal, $true)
$dist = Join-Path $project 'dist'
$null = [IO.Directory]::CreateDirectory($dist)
$windows = Join-Path $dist 'windows'
$archive = Join-Path $dist $zipName
if ([IO.Directory]::Exists($windows) -and -not [IO.File]::Exists((Join-Path $windows 'app/Pip House.cfg'))) {
    throw "Output already exists and does not look like a Pip House app image: $windows"
}
# Preserve earlier output while publishing and restore it if a locked file prevents publication.
$oldImage = Join-Path $stage 'previous-windows'
$oldArchive = Join-Path $stage ('previous-' + $zipName)
foreach ($path in @($windows, $archive, $image, $zip, $oldImage, $oldArchive, $stage)) { Assert-ProjectPath $path }
$imagePublished = $false
try {
    if ([IO.Directory]::Exists($windows)) { [IO.Directory]::Move($windows, $oldImage) }
    if ([IO.File]::Exists($archive)) { [IO.File]::Move($archive, $oldArchive) }
    [IO.Directory]::Move($image, $windows)
    $imagePublished = $true
    [IO.File]::Move($zip, $archive)
} catch {
    if ($imagePublished) { [IO.Directory]::Move($windows, $image) }
    if ([IO.File]::Exists($oldArchive)) { [IO.File]::Move($oldArchive, $archive) }
    if ([IO.Directory]::Exists($oldImage)) { [IO.Directory]::Move($oldImage, $windows) }
    throw
}
Remove-Item -LiteralPath $stage -Recurse -Force
Write-Output (Join-Path $windows 'Pip House.exe')
Write-Output $archive
