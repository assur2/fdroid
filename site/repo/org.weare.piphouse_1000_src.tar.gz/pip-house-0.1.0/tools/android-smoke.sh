#!/usr/bin/env bash
set -euo pipefail
serial=emulator-5558
package=org.weare.piphouse
bash gradlew :android:assembleDebug
adb -s "$serial" install -r android/build/outputs/apk/debug/android-debug.apk
adb -s "$serial" shell am start -W -n "$package/.AndroidLauncher" | tee "$RUNNER_TEMP/pip-house-launch.txt"
grep -F 'Status: ok' "$RUNNER_TEMP/pip-house-launch.txt"
sleep 4
adb -s "$serial" shell pidof "$package"
adb -s "$serial" shell input keyevent KEYCODE_HOME
adb -s "$serial" shell am start -W -n "$package/.AndroidLauncher"
adb -s "$serial" shell pidof "$package"
