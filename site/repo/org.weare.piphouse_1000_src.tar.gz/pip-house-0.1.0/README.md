# Pip House

An offline card room for Windows x64 and Android. All five games use the same libGDX rules and renderer on both platforms. Each table saves locally after every move and resumes when you return.

## Play

On Windows, launch **dist/windows/Pip House.exe**. To take the game to another Windows computer, extract **dist/Pip-House-Windows-x64.zip** and keep the executable beside its `app` and `runtime` directories. Java is included.

On Android 6.0 or later, add the Weare Apps repository to F-Droid, search for **Pip House**, and select **Install**. The store package is `org.weare.piphouse` and uses landscape orientation. It installs separately from the original debug build and starts with its own saved tables. [Weare Apps repository](https://assur2.github.io/fdroid/repo/)

Click or tap a table to play. **How to play** opens the rulebook. **Game room** returns to the collection and keeps your place. On Windows, Tab and Shift+Tab cycle through controls, Enter or Space activates the focused item, and Escape goes back.

| Table | Rules |
| --- | --- |
| Poker | Four-player no-limit Texas Hold’em with 1,000 starting chips and 10/20 blinds. Play through showdowns, side pots and elimination. |
| Hearts | Four-player Hearts with rotating passes, shooting the moon and a 100-point finish. |
| Klaverjassen | Amsterdam partnership rules. You and North play 16 deals with trump selection, automatic roem and contract scoring. |
| Solitaire | Draw-one Klondike with stock recycling, movable runs, hints and undo. |
| Skip-Bo | Two-player race with 30-card stocks, four shared builds, personal discard piles and wild cards. |

The Klaverjassen table follows the Amsterdam contract and scoring rules published by Kaartbond Nederland. Skip-Bo uses Mattel’s two-player deal and stockpile rules. [Amsterdam rules](https://www.kaartbondnederland.nl/regelgeving/statuten/spelreglement-klaverjassen) · [Skip-Bo instructions](https://service.mattel.com/instruction_sheets/42050-Skip-Bo.pdf)

## Build

Use JDK 17 for development. The Gradle wrapper pins Gradle 8.9. Android builds use SDK Platform 35 and Build Tools 35.0.0. Set `JAVA_HOME` and `ANDROID_HOME` to your installations.

| Command on Windows | Result |
| --- | --- |
| `gradlew.bat :desktop:run` | Run the desktop game from source |
| `gradlew.bat :android:assembleDebug` | Build the Android APK under `android/build/outputs/apk/debug/` |
| `powershell -ExecutionPolicy Bypass -File tools/package-windows.ps1` | Create the self-contained Windows folder and portable ZIP in `dist` |

The Windows packaging script uses JDK 17’s jpackage and downloads the pinned desktop libraries from Maven Central. It accepts a JDK path through `-Jdk`.

## Screenshots and checks

The `screenshots` directory contains 1280 × 800 captures of the game room, five tables and rulebook. The desktop launcher's `--screenshots <directory>` option plays seeded sessions through the app’s hit targets and writes the shared renderer’s image buffer directly to PNGs. It runs without opening a window and uses an in-memory save store.

`tools/EngineChecks.java` exercises trick legality and scoring, Skip-Bo card conservation, Klondike moves and undo, and poker evaluation and settlement. Local gameplay checks ran on Windows. The Android package was built and its signature and contents verified.

The Windows launcher's `--self-test <directory>` option renders the game in an invisible OpenGL window, saves the app framebuffer to `frame.png`, and writes graphics-driver details to `result.txt`.

DM Sans and DM Serif Display are distributed under the SIL Open Font License. Their licenses are included in `assets`.

## F-Droid releases

Pip House is licensed under GPL-3.0-only. The private source repository builds Android and Windows on stable version tags. Each published Android release includes the signed APK and the corresponding tagged GPL source archive in the public Weare Apps catalog.

Run **Test Pip House** in GitHub Actions for the card-engine checks, Android tests, lint, unsigned release build and a staging access check. Select the emulator option to include an Android launch and resume check. Before tagging a release, run the read-only preflight from the approved Notes publisher tag and check every private source. The first release is `v0.1.0` with Android version code 1000.

The release workflow signs the Android build using the app’s dedicated key in the tag-restricted `android-release` environment. The pinned stage-release action stages the APK and tagged source in the private `fdroid-artifacts` branch. The shared Notes publisher verifies the app identity and signer and updates the feed using the existing repository key. [Publisher setup](https://github.com/assur2/fdroid/blob/main/SETUP.md)
