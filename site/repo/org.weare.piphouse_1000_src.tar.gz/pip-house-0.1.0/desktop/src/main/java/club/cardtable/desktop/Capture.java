package club.cardtable.desktop;

import club.cardtable.game.*;
import club.cardtable.ui.Board;
import club.cardtable.ui.Room;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Files;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.PixmapIO;
import com.badlogic.gdx.utils.GdxNativesLoader;
import java.util.HashMap;
import java.util.Map;

/** Deterministic app screenshots. Renders the live game board without creating a native window. */
public final class Capture {
    private final Board board;
    private final FileHandle destination;
    private final MemoryStore saves=new MemoryStore();
    private Room room;
    private static final class MemoryStore implements Room.Store {
        final Map<String,String> values=new HashMap<>();
        public String get(String key) {String s=values.get(key); return s==null?"":s;}
        public void put(String key,String value) {values.put(key,value);}
    }
    public static void run(String path) {
        GdxNativesLoader.load();
        Capture tool=new Capture(path);
        try {tool.capture();} finally {tool.board.dispose();}
    }
    private Capture(String path) {
        destination=new FileHandle(path);
        destination.mkdirs();
        board=new Board(new Lwjgl3Files().classpath(""));
        room=new Room(board,saves,20261126L);
    }
    private void press(String id) {
        room.paint();
        for(int y=3;y<Board.H;y+=7) for(int x=3;x<Board.W;x+=7) {
            if(id.equals(room.hitAt(x,y))) {room.activate(room.hitAt(x,y));return;}
        }
        throw new IllegalStateException("No live target for "+id);
    }
    private void shot(String filename) {
        room.paint();
        PixmapIO.writePNG(destination.child(filename+".png"),board.pixels());
    }
    private Group group(String layout) {
        for(Group g:room.currentGame().view().groups) if(g.layout.equals(layout)) return g;
        throw new IllegalStateException(layout);
    }
    private void playFirstCard() {
        for(Tile t:group("hand").tiles) if(t.id!=null) {press("move:"+t.id); return;}
        throw new IllegalStateException("No playable hand card");
    }
    private void capture() {
        shot("01-game-room");
        press("open:0");
        int attempts=0;
        while (room.currentGame().view().phase.equals("Pre-flop") && attempts++<15) press("move:call");
        if(group("center").tiles.isEmpty()) {
            // Some tables close preflop after all other seats fold.
            for(int i=0;i<12 && group("center").tiles.isEmpty();i++) {
                View v=room.currentGame().view();
                String id=v.actions.get(0).id;
                press("move:"+id);
            }
        }
        shot("02-poker");
        if(!room.back()) throw new AssertionError();
        press("open:1");
        Group hand=group("hand");
        for(int i=0;i<3;i++) press("move:"+hand.tiles.get(i).id);
        press("move:pass");
        playFirstCard();
        shot("03-hearts");
        room.back();
        press("open:2");
        press("move:"+room.currentGame().view().actions.get(0).id);
        playFirstCard();
        shot("04-klaverjassen");
        room.back();
        press("open:3");
        for(int i=0;i<3;i++) press("move:draw");
        shot("05-solitaire");
        String score=room.currentGame().view().score;
        String waste=group("stocks").label;
        // Reopen the same saved table in a fresh controller and confirm the replayed layout.
        room=new Room(board,saves,7);
        press("open:3");
        if(!room.currentGame().view().score.equals(score) || !group("stocks").label.equals(waste)) throw new AssertionError("Saved table did not restore");
        press("move:undo");
        room.back();
        press("open:4");
        for(int i=0;i<4;i++) {
            press("move:pick/0");press("move:discard/"+i);
        }
        shot("06-skip-bo");
        press("help");
        press("rules:2");
        shot("07-rulebook");
        press("close");
        press("new");press("close");
        if(room.currentGame()==null) throw new AssertionError();
        System.out.println("Captured the game room, five playable tables and the rulebook.");
    }
}
