package club.cardtable.desktop;

import club.cardtable.ui.PipHouse;
import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Files;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputProcessor;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;
import com.badlogic.gdx.files.FileHandle;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.PixmapIO;
import java.io.File;
import java.io.PrintWriter;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public final class DesktopLauncher {
    private DesktopLauncher() { }

    public static void main(String[] args) throws Exception {
        if (args.length == 2 && args[0].equals("--screenshots")) {
            Capture.run(args[1]);
            return;
        }
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
        config.setTitle("Pip House");
        config.setWindowedMode(1280, 800);
        config.setResizable(true);
        config.setWindowIcon("icon.png");
        config.useVsync(true);
        config.setForegroundFPS(60);
        config.disableAudio(true);
        if (args.length == 2 && args[0].equals("--self-test")) {
            FileHandle output = new FileHandle(new File(args[1]).getAbsoluteFile());
            output.mkdirs();
            config.setInitialVisible(false);
            config.setPauseWhenLostFocus(false);
            config.setPreferencesConfig(output.child("preferences").file().getAbsolutePath(), Files.FileType.Absolute);
            try {
                new Lwjgl3Application(new FrameCheck(output), config);
            } catch (Throwable failure) {
                try (PrintWriter log = new PrintWriter(output.child("error.txt").file(), "UTF-8")) {
                    failure.printStackTrace(log);
                }
                System.exit(1);
            }
            return;
        }
        new Lwjgl3Application(new PipHouse(), config);
    }

    /** Exercise normal game startup and inspect only the application's own OpenGL framebuffer. */
    private static final class FrameCheck extends ApplicationAdapter {
        private final PipHouse game = new PipHouse();
        private final FileHandle output;
        private boolean captured;

        FrameCheck(FileHandle output) { this.output = output; }
        @Override public void create() { game.create(); }
        @Override public void resize(int width, int height) { game.resize(width, height); }
        @Override public void dispose() { game.dispose(); }
        @Override public void render() {
            game.render();
            if (captured) return;
            captured = true;
            captureFrame("frame.png");

            // Use the same initial solitaire deal as the screenshot sequence for a direct pixel comparison.
            Random seeds = new Random(20261126L);
            long solitaireSeed = 0;
            for (int table = 0; table < 4; table++) solitaireSeed = seeds.nextLong();
            Preferences tables = Gdx.app.getPreferences("pip-house-tables");
            tables.putString("table-v1-3", solitaireSeed + "\n");
            tables.flush();
            tap(780, 620);
            game.render();
            for (int draw = 0; draw < 3; draw++) tap(149, 240);
            game.render();
            captureFrame("solitaire.png");
            if (!tables.getString("table-v1-3").equals(solitaireSeed + "\ndraw\ndraw\ndraw\n")) {
                throw new IllegalStateException("Solitaire draw actions did not reach the save store");
            }
            FileHandle save = output.child("preferences").child("pip-house-tables");
            if (!save.exists() || save.length() == 0) throw new IllegalStateException("Table save missing");
            output.child("result.txt").writeString(Gdx.graphics.getGLVersion().getDebugVersionString()
                    + "\nSaved table: " + save.file().getAbsolutePath(), false, "UTF-8");
            Gdx.app.exit();
        }

        private void tap(int boardX, int boardY) {
            int width = Gdx.graphics.getWidth(), height = Gdx.graphics.getHeight();
            float scale = Math.min(width / 1280f, height / 800f);
            int x = Math.round((width - 1280 * scale) / 2 + boardX * scale);
            int y = Math.round((height - 800 * scale) / 2 + boardY * scale);
            InputProcessor controls = Gdx.input.getInputProcessor();
            if (!controls.touchDown(x, y, 0, Input.Buttons.LEFT) || !controls.touchUp(x, y, 0, Input.Buttons.LEFT)) {
                throw new IllegalStateException("Game control unavailable at " + boardX + "," + boardY);
            }
        }

        private void captureFrame(String file) {
            int width = Gdx.graphics.getBackBufferWidth();
            int height = Gdx.graphics.getBackBufferHeight();
            Pixmap image = Pixmap.createFromFrameBuffer(0, 0, width, height);
            try {
                Set<Integer> colors = new HashSet<>();
                for (int y = 0; y < height; y += 16) {
                    for (int x = 0; x < width; x += 16) colors.add(image.getPixel(x, y));
                }
                if (colors.size() < 100) throw new IllegalStateException("Incomplete game frame");
                PixmapIO.writePNG(output.child(file), image, -1, true);
            } finally { image.dispose(); }
        }
    }
}
