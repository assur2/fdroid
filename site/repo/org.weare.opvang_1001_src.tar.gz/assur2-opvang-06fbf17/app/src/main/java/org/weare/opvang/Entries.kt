// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

internal data class Photo(val thumbnail: String, val original: String)
internal data class ReplyForm(val action: String, val token: String, val page: String)
internal data class Entry(
    val title: String = "",
    val lines: List<String> = emptyList(),
    val replies: List<String> = emptyList(),
    val photos: List<Photo> = emptyList(),
    val form: ReplyForm? = null
)

internal object Entries {
    private val stamp = Regex("""\b(?:\d{4}-\d{2}-\d{2}|\d{2}-\d{2}-\d{4}) \d{2}:\d{2}\b""")
    private val formats = listOf("yyyy-MM-dd HH:mm", "dd-MM-yyyy HH:mm").map(DateTimeFormatter::ofPattern)

    fun reports(doc: Document): List<Entry> = doc.select(".dr_entries").map { post ->
        val replies = post.selectFirst(".dr_notes")?.clone()
        replies?.select("form, script")?.remove()
        replies?.select("a")?.filter { it.text().equals("Verwijder", ignoreCase = true) }?.forEach { it.remove() }
        val photos = post.select(".dr_photo_entry").mapNotNull { frame ->
            val thumb = frame.selectFirst("img[src]")?.absUrl("src")?.let(Pages::path) ?: return@mapNotNull null
            val full = frame.selectFirst("a[data-photo-url]")?.absUrl("data-photo-url")?.let(Pages::path)
                ?: frame.selectFirst(".fp_dl a[href]")?.absUrl("href")?.let(Pages::path)
            Photo(thumb, full ?: thumb)
        }
        val form = post.selectFirst("form[method=post]:has(textarea[name=content])")?.let {
            val action = Pages.path(it.absUrl("action")) ?: return@let null
            val page = Pages.path(doc.location())?.substringBefore('?') ?: return@let null
            val csrf = it.selectFirst("input[name=authenticity_token]")?.attr("value").orEmpty()
            if (!action.startsWith("$page/") || !action.removePrefix("$page/").matches(Regex("[0-9]+/notes")) ||
                !page.endsWith("/daily_reports") || csrf.isEmpty()) return@let null
            ReplyForm(action, csrf, page)
        }
        Entry(post.selectFirst(".dr_date")?.text().orEmpty(),
            post.selectFirst(".dr_content")?.let(Pages::textLines).orEmpty(),
            replies?.let(Pages::textLines).orEmpty(), photos, form)
    }

    private fun datedGroups(lines: List<String>): List<Entry> {
        val entries = mutableListOf<Entry>()
        var title = ""
        val body = mutableListOf<String>()
        fun flush() {
            if (title.isNotBlank() || body.isNotEmpty()) entries += Entry(title, body.toList())
            body.clear()
        }
        for (line in lines) {
            if (stamp.find(line)?.range?.first == 0) {
                flush()
                title = line
            } else body += line
        }
        flush()
        return entries
    }

    fun chat(doc: Document): List<Entry> {
        val messages = doc.select(".chat-message")
        val entries = if (messages.isEmpty()) datedGroups(Pages.lines(doc, true)) else messages.map { msg ->
            val header = msg.selectFirst(".message-title")
            val body = msg.selectFirst(".message-text")
            val fallback = msg.clone().apply { select(".message-title").remove() }
            Entry(header?.text().orEmpty(), Pages.textLines(body ?: fallback))
        }
        // Reverse server order for equal timestamps, keeping every message body intact.
        return entries.asReversed().sortedByDescending { entry ->
            val value = stamp.find(entry.title)?.value
            formats.firstNotNullOfOrNull { fmt -> value?.let { runCatching { LocalDateTime.parse(it, fmt) }.getOrNull() } }
        }
    }

    fun general(doc: Document): List<Entry> {
        val root = Pages.content(doc)
        val entries = mutableListOf<Entry>()
        val pending = mutableListOf<String>()
        fun flush() {
            if (pending.isNotEmpty()) entries += Entry(lines = pending.toList())
            pending.clear()
        }
        fun visit(el: Element) {
            when {
                el.tagName() in setOf("tr","li","article","fieldset","dl") -> {
                    flush()
                    val lines = Pages.textLines(el)
                    if (lines.isNotEmpty()) entries += Entry(lines = lines)
                }
                el.tagName().matches(Regex("h[1-6]")) -> { flush(); pending += el.text() }
                el.children().any { it.isBlock } -> el.childNodes().forEach { node ->
                    if (node is Element) visit(node)
                    else if (node is org.jsoup.nodes.TextNode && !node.isBlank) pending += node.text().trim()
                }
                else -> {
                    pending += Pages.textLines(el)
                    flush()
                }
            }
        }
        visit(root)
        flush()
        return entries
    }
}



