package org.weare.opvang

import android.graphics.Bitmap
import androidx.activity.compose.setContent
import androidx.compose.material.MaterialTheme
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import java.util.concurrent.CopyOnWriteArrayList

class EntryCardTest {
    @get:Rule val ui = createAndroidComposeRule<MainActivity>()

    @Test fun openSecondPhotoThenNavigateWithinPost() {
        val requests = CopyOnWriteArrayList<String>()
        val bitmap = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888)
        val entry = Entry("Een bericht", listOf("Een fijne dag"), photos = listOf(
            Photo("/thumb-a", "/full-a"), Photo("/thumb-b", "/full-b")),
            form = ReplyForm("/report/1/notes", "fixture", "/report"))
        var reply: Entry? = null
        ui.activityRule.scenario.onActivity { activity ->
            activity.setContent {
                MaterialTheme {
                    EntryCard(entry, { path, _ -> requests += path; bitmap }) { reply = it }
                }
            }
        }
        ui.onNodeWithContentDescription("Foto 2").performClick()
        ui.onNodeWithText("Foto 2 van 2").assertIsDisplayed()
        ui.onNodeWithText("Volgende").assertIsNotEnabled()
        ui.onNodeWithText("Vorige").performClick()
        ui.onNodeWithText("Foto 1 van 2").assertIsDisplayed()
        ui.onNodeWithText("Vorige").assertIsNotEnabled()
        ui.onNodeWithText("Sluiten").performClick()
        ui.onNodeWithText("Reageer").performClick()
        ui.runOnIdle {
            assertEquals(entry, reply)
            assertTrue(requests.containsAll(listOf("/full-a", "/full-b")))
        }
    }
}

