package org.weare.opvang

import org.jsoup.Jsoup
import org.junit.Assert.*
import org.junit.Test

class EntriesTest {
    @Test fun reportsKeepPhotosCommentsAndFormsWithTheirOwnPost() {
        val page = "/parents/locations/1/children/2/daily_reports"
        fun report(number: Int) = """
            <div class='dr_entries'><div class='dr_date'>Dag $number</div>
            <div class='dr_content'><p>Bericht $number</p></div>
            <div class='dr_notes'><p>Reactie $number</p><a>Verwijder</a></div>
            <form method='post' action='$page/$number/notes'><input name='authenticity_token' value='test'>
            <textarea name='content'></textarea></form>
            <div class='dr_photo_entry'><a class='dr_photo' href='#' data-photo-url='/full/$number'>
            <img src='/thumb/$number'></a><div class='fp_dl'><a href='/download/$number'>download</a></div></div></div>"""
        val entries = Entries.reports(Jsoup.parse(report(1) + report(2), ORIGIN + page))
        assertEquals(2, entries.size)
        entries.forEachIndexed { i, entry ->
            val n = i + 1
            assertEquals(listOf("Bericht $n"), entry.lines)
            assertEquals(listOf("Reactie $n"), entry.replies)
            assertEquals(listOf(Photo("/thumb/$n", "/full/$n")), entry.photos)
            assertEquals(ReplyForm("$page/$n/notes", "test", page), entry.form)
        }
    }

    @Test fun newestFirstPreservesMultilineMessagesEvenIfServerOrderChanges() {
        fun msg(day: String, body: String) = "<div class='chat-message'><b class='message-title'>$day 12:00 - A</b><div class='message-text'>$body</div></div>"
        val first = msg("2026-01-12", "Een")
        val second = msg("2026-10-09", "Twee<br>Regel twee")
        for (html in listOf(first + second, second + first)) {
            val result = Entries.chat(Jsoup.parse(html))
            assertEquals(listOf(listOf("Twee", "Regel twee"), listOf("Een")), result.map { it.lines })
        }
    }

    @Test fun tableRowsRemainSeparateCards() {
        val page = Jsoup.parse("<main><table><tr><td>A</td><td>B</td></tr><tr><td>C</td><td>D</td></tr></table></main>")
        assertEquals(listOf(listOf("A · B"), listOf("C · D")), Entries.general(page).map { it.lines })
    }
}

