// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element

internal data class Photo(val thumbnail: String, val original: String)
internal data class ReplyForm(val action: String, val token: String, val page: String)
internal data class Entry(
    val title: String = "",
    val lines: List<String> = emptyList(),
    val replies: List<List<String>> = emptyList(),
    val photos: List<Photo> = emptyList(),
    val form: ReplyForm? = null,
    val attachments: List<Link> = emptyList(),
    val fields: List<Pair<String, String>> = emptyList()
)

internal object Entries {
    private val stamp = Regex("""\b(?:\d{4}-\d{2}-\d{2}|\d{2}-\d{2}-\d{4}) \d{2}:\d{2}\b""")
    private val formats = listOf("yyyy-MM-dd HH:mm", "dd-MM-yyyy HH:mm").map(DateTimeFormatter::ofPattern)

    fun reports(doc: Document): List<Entry> = doc.select(".dr_entries").map { post ->
        val photos = post.select(".dr_photo_entry").mapNotNull { frame ->
            val thumb = frame.selectFirst("img[src]")?.absUrl("src")?.let(Pages::path) ?: return@mapNotNull null
            val full = frame.selectFirst("a[data-photo-url]")?.absUrl("data-photo-url")?.let(Pages::path)
                ?: frame.selectFirst(".fp_dl a[href]")?.absUrl("href")?.let(Pages::path)
            Photo(thumb, full ?: thumb)
        }
        val page = Pages.path(doc.location())?.substringBefore('?')?.trimEnd('/')
        val form = post.select("form[action]:has(textarea[name=content])").firstNotNullOfOrNull { form ->
            val action = Pages.path(form.absUrl("action")) ?: return@firstNotNullOfOrNull null
            val parent = action.substringBeforeLast('/').substringBeforeLast('/')
            if (parent != page || !parent.endsWith("/daily_reports") ||
                !action.removePrefix("$parent/").matches(Regex("[0-9]+/notes"))) return@firstNotNullOfOrNull null
            val csrf = form.selectFirst("input[name=authenticity_token]")?.attr("value").orEmpty()
                .ifBlank { doc.selectFirst("meta[name=csrf-token]")?.attr("content").orEmpty() }
            if (csrf.isBlank()) null else ReplyForm(action, csrf, parent)
        }
        val postId = post.id().removePrefix("daily_report_")
        val pageToken = doc.selectFirst("meta[name=csrf-token]")?.attr("content").orEmpty()
        val replyForm = form ?: if (post.selectFirst(".react-link") != null && page?.endsWith("/daily_reports") == true &&
            postId.matches(Regex("[0-9]+")) && pageToken.isNotBlank()) {
            ReplyForm("$page/$postId/notes", pageToken, page)
        } else null
        val groups = post.select(".dr_notes").flatMap { container ->
            val notes = container.clone()
            notes.select("form,script").remove()
            notes.select("a").filter { it.text().equals("Verwijder", ignoreCase = true) }.forEach { it.remove() }
            val blocks = mutableListOf<MutableList<String>>()
            Pages.textLines(notes).forEach { line ->
                if (blocks.isEmpty() || (line.startsWith("Door ", ignoreCase = true) && stamp.containsMatchIn(line))) {
                    blocks.add(mutableListOf())
                }
                blocks.last().add(line)
            }
            blocks
        }
        Entry(post.selectFirst(".dr_date")?.text().orEmpty(),
            post.selectFirst(".dr_content")?.let(Pages::textLines).orEmpty(),
            groups, photos, replyForm)
    }

    private fun datedGroups(lines: List<String>): List<Entry> {
        val entries = mutableListOf<Entry>()
        var title = ""
        val body = mutableListOf<String>()
        fun flush() {
            if (title.isNotBlank() || body.isNotEmpty()) entries += Entry(title, body.toList())
            body.clear()
        }
        for (line in lines) {
            if (stamp.find(line)?.range?.first == 0) {
                flush()
                title = line
            } else body += line
        }
        flush()
        return entries
    }

    fun chat(doc: Document): List<Entry> {
        val messages = doc.select(".chat-message")
        val entries = if (messages.isEmpty()) datedGroups(Pages.lines(doc, true)) else messages.map { msg ->
            val header = msg.selectFirst(".message-title")
            val body = msg.selectFirst(".message-text")
            val fallback = msg.clone().apply { select(".message-title").remove() }
            val content = body ?: fallback
            val photos = content.select("img[src]").mapNotNull { img ->
                val thumbnail = Pages.mediaUrl(img.absUrl("src")) ?: return@mapNotNull null
                val original = img.closest("a[href]")?.absUrl("href")?.let(Pages::mediaUrl)
                Photo(thumbnail, original ?: thumbnail)
            }.distinct()
            Entry(header?.text().orEmpty(), Pages.textLines(content), photos = photos)
        }
        // Reverse server order for equal timestamps, keeping every message body intact.
        return entries.asReversed().sortedByDescending { entry ->
            val value = stamp.find(entry.title)?.value
            formats.firstNotNullOfOrNull { fmt -> value?.let { runCatching { LocalDateTime.parse(it, fmt) }.getOrNull() } }
        }
    }

    private fun attachment(anchor: Element): Link? {
        val url = Pages.mediaUrl(anchor.absUrl("href")) ?: return null
        val label = sequenceOf(anchor.text(), anchor.attr("title"), anchor.attr("download"),
            anchor.selectFirst("img")?.attr("alt").orEmpty()).firstOrNull { it.isNotBlank() } ?: "Open bestand"
        return Link(label, url)
    }

    fun newsletters(doc: Document): List<Entry> {
        val cards = mutableListOf<Entry>()
        for (table in doc.select("table")) {
            val rows = table.select("tr").filter { it.closest("table") === table }
            val header = rows.firstOrNull { row ->
                row.children().map { it.text().lowercase() }.containsAll(listOf("onderwerp", "bijlage"))
            } ?: continue
            val columns = header.children().map { it.text().lowercase() }
            for (row in rows.dropWhile { it !== header }.drop(1)) {
                val cells = columns.zip(row.children()).toMap()
                val subject = cells["onderwerp"]?.text().orEmpty()
                if (subject.equals("onderwerp", true) || row.select("td").isEmpty()) continue
                val fields = listOf("Verzonden op", "Locatie").mapNotNull { label ->
                    cells[label.lowercase()]?.text()?.takeIf { it.isNotBlank() }?.let { label to it }
                }
                cards += Entry(title = subject, lines = cells["tekst"]?.let(Pages::textLines).orEmpty(),
                    fields = fields, attachments = cells["bijlage"]?.select("a[href]")?.mapNotNull(::attachment).orEmpty())
            }
        }
        return cards
    }

    fun documents(doc: Document, current: Link): Page {
        val base = current.path.substringBefore("/documents_categories") + "/documents_categories"
        val entries = mutableListOf<Entry>()
        val folders = mutableListOf<Link>()
        for (a in Pages.content(doc).select("a[href]")) {
            val link = attachment(a) ?: continue
            val path = link.path.substringBefore('?')
            if (path.startsWith("$base/") && path != current.path && !path.removePrefix("$base/").contains('/')) {
                folders += link
            } else if ((Pages.isFile(link.path) || a.hasAttr("download")) && a.attr("data-method").isBlank() &&
                link.label != "Gebruiksvoorwaarden OuderApp") {
                entries += Entry(attachments = listOf(link))
            }
        }
        return Page(current.label, entries.distinct(), folders.distinct())
    }

    fun general(doc: Document): List<Entry> {
        val root = Pages.content(doc)
        val entries = mutableListOf<Entry>()
        val pending = mutableListOf<String>()
        fun flush() {
            if (pending.isNotEmpty()) entries += Entry(lines = pending.toList())
            pending.clear()
        }
        fun visit(el: Element) {
            when {
                el.tagName() in setOf("tr","li","article","fieldset","dl") -> {
                    flush()
                    val lines = Pages.textLines(el)
                    if (lines.isNotEmpty()) entries += Entry(lines = lines)
                }
                el.tagName().matches(Regex("h[1-6]")) -> { flush(); pending += el.text() }
                el.children().any { it.isBlock } -> el.childNodes().forEach { node ->
                    if (node is Element) visit(node)
                    else if (node is org.jsoup.nodes.TextNode && !node.isBlank) pending += node.text().trim()
                }
                else -> {
                    pending += Pages.textLines(el)
                    flush()
                }
            }
        }
        visit(root)
        flush()
        return entries
    }
}
