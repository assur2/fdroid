// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val model: PortalModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colors = lightColors(primary = Color(0xFF145E51), secondary = Color(0xFF176658))) {
                PortalScreen(model)
            }
        }
    }
}

internal class PortalModel : ViewModel() {
    private var portal = Portal()
    var photos = PhotoLoader(portal)
        private set
    var replyTo by mutableStateOf<Entry?>(null)
    var chatTo by mutableStateOf<Link?>(null)
    var download by mutableStateOf<Downloaded?>(null)
    var draft by mutableStateOf("")
    val pages = mutableStateListOf<Page>()
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var code by mutableStateOf("")
    var needsCode by mutableStateOf(false)
    var locations by mutableStateOf(emptyList<Location>())
    var error by mutableStateOf("")
    var busy by mutableStateOf(false)

    private fun run(block: suspend () -> Unit) {
        if (busy) return
        busy = true
        error = ""
        viewModelScope.launch {
            try { block() }
            catch (e: CancellationException) { throw e }
            catch (e: Expired) { logout(); error = e.message.orEmpty() }
            catch (e: Exception) {
                error = when {
                    e is java.io.IOException && e.javaClass == java.io.IOException::class.java -> e.message.orEmpty()
                    else -> "KOVnet kon het verzoek niet afronden. Controleer je verbinding en probeer opnieuw."
                }
            }
            finally { busy = false }
        }
    }

    fun submit(location: String? = null) = run {
        val result = if (location != null) Login.Ready else withContext(Dispatchers.IO) {
            portal.check(email.trim(), password, code)
        }
        when (result) {
            Login.Code -> needsCode = true
            is Login.Choose -> locations = result.locations
            Login.Ready -> {
                val home = withContext(Dispatchers.IO) { portal.login(email.trim(), password, code, location.orEmpty()) }
                pages.add(home)
                password = ""; code = ""; locations = emptyList(); needsCode = false
            }
        }
    }

    fun open(link: Link) = run { pages.add(withContext(Dispatchers.IO) { portal.page(link) }) }
    fun composeReply(entry: Entry) {
        replyTo = entry
        draft = ""
        error = ""
    }

    fun composeChat(link: Link) { closeReply(); chatTo = link }

    fun sendChat() {
        val link = chatTo ?: return
        val text = draft.trim()
        if (text.isBlank()) return
        run {
            try { withContext(Dispatchers.IO) { portal.sendMessage(link, text) } }
            catch (e: Expired) { throw e }
            catch (e: IOException) {
                error = "Verzending niet bevestigd. Controleer het gesprek voordat je opnieuw verzendt."
                return@run
            }
            closeReply()
            try { pages[pages.lastIndex] = withContext(Dispatchers.IO) { portal.page(link) } }
            catch (e: Expired) { throw e }
            catch (e: IOException) { error = "Bericht ingestuurd. Open het gesprek opnieuw om het te verversen." }
        }
    }

    fun attachment(link: Link, directory: File) = run {
        download = withContext(Dispatchers.IO) {
            directory.listFiles()?.filter { it.lastModified() < System.currentTimeMillis() - 86400000L }
                ?.forEach { it.delete() }
            portal.download(link, directory)
        }
    }

    fun closeReply() { chatTo = null; replyTo = null; draft = ""; error = "" }

    fun sendReply() {
        val entry = replyTo ?: return
        val form = entry.form ?: return
        val text = draft.trim()
        if (text.isEmpty()) return
        run {
            try {
                withContext(Dispatchers.IO) { portal.reply(form, text) }
            } catch (e: Expired) { throw e }
            catch (e: IOException) {
                error = "Verzending niet bevestigd. Controleer het Schriftje voordat je opnieuw verzendt."
                return@run
            }
            closeReply()
            val updated = try {
                withContext(Dispatchers.IO) { portal.page(Link("Schriftje", form.page)) }
            } catch (e: Expired) { throw e }
            catch (e: IOException) {
                error = "Reactie ingestuurd. Open het Schriftje opnieuw om de reacties te laden."
                return@run
            }
            pages[pages.lastIndex] = updated
            if (updated.entries.none { it.form?.action == form.action &&
                    it.replies.flatten().joinToString(" ").contains(text.replace(Regex("""\s+"""), " ")) }) {
                error = "KOVnet heeft de reactie nog niet in het Schriftje getoond."
            }
        }
    }

    fun saveFile(resolver: android.content.ContentResolver, uri: android.net.Uri, asset: Downloaded) = run {
        withContext(Dispatchers.IO) {
            val stream = resolver.openOutputStream(uri) ?: throw IOException("Opslaan mislukt.")
            stream.use { output -> asset.file.inputStream().use { it.copyTo(output) } }
        }
        download = null
    }

    fun back() { if (!busy && pages.size > 1) { pages.removeAt(pages.lastIndex); error = "" } }
    fun logout() {
        download = null; portal = Portal(); photos = PhotoLoader(portal); closeReply(); pages.clear(); email = ""; password = ""; code = ""
        needsCode = false; locations = emptyList(); error = ""
    }
}

@Composable
internal fun PortalScreen(model: PortalModel) {
    val page = model.pages.lastOrNull()
    BackHandler(enabled = model.pages.size > 1 || model.busy) { model.back() }
    Surface(modifier = Modifier.fillMaxSize()) {
        val context = LocalContext.current
        val save = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.data
            val asset = model.download
            if (uri != null && asset != null && result.resultCode == android.app.Activity.RESULT_OK) {
                model.saveFile(context.contentResolver, uri, asset)
            }
        }
        model.download?.let { asset ->
            AlertDialog(onDismissRequest = { model.download = null }, title = { Text(asset.name) },
                text = { TextButton(onClick = {
                    save.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType(asset.mime).putExtra(Intent.EXTRA_TITLE, asset.name))
                }) { Text("Kopie opslaan") } },
                confirmButton = { TextButton(onClick = {
                    val uri = FileProvider.getUriForFile(context, context.packageName + ".files", asset.file, asset.name)
                    try {
                        context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, asset.mime)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        model.download = null
                    } catch (_: ActivityNotFoundException) {
                        save.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                            .setType(asset.mime).putExtra(Intent.EXTRA_TITLE, asset.name))
                    }
                }) { Text("Openen") } }, dismissButton = {
                    TextButton(onClick = { model.download = null }) { Text("Sluiten") }
                })
        }
        if (model.replyTo != null || model.chatTo != null) {
            val chatting = model.chatTo != null
            AlertDialog(onDismissRequest = { if (!model.busy) model.closeReply() },
                title = { Text(if (chatting) "Nieuw chatbericht" else "Reageren") },
                text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(model.chatTo?.label ?: model.replyTo?.title.orEmpty())
                    OutlinedTextField(model.draft, { model.draft = it }, enabled = !model.busy,
                        label = { Text(if (chatting) "Je bericht" else "Je reactie") }, maxLines = 6)
                    if (model.error.isNotEmpty()) Text(model.error, color = MaterialTheme.colors.error)
                } },
                confirmButton = { TextButton({ if (chatting) model.sendChat() else model.sendReply() }, enabled = !model.busy && model.draft.isNotBlank()) { Text("Verzenden") } },
                dismissButton = { TextButton(model::closeReply, enabled = !model.busy) { Text("Annuleren") } })
        }
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            TopAppBar(title = { Text("Opvang") }, actions = {
                if (model.pages.size > 1) TextButton(onClick = model::back, enabled = !model.busy) { Text("Terug", color = Color.White) }
                if (page != null) TextButton(onClick = model::logout, enabled = !model.busy) { Text("Afmelden", color = Color.White) }
            })
            if (model.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (model.error.isNotEmpty()) Text(model.error, Modifier.padding(16.dp), color = MaterialTheme.colors.error)
            key(model.pages.size, page?.title) {
                LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (page == null) {
                        item { Text("Aanmelden bij KOVnet", style = MaterialTheme.typography.h5) }
                        if (model.locations.isEmpty()) {
                            item { OutlinedTextField(model.email, { model.email = it }, Modifier.fillMaxWidth(),
                                enabled = !model.busy, label = { Text("E-mailadres") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)) }
                            item { OutlinedTextField(model.password, { model.password = it }, Modifier.fillMaxWidth(),
                                enabled = !model.busy, label = { Text("Wachtwoord") }, singleLine = true,
                                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)) }
                            if (model.needsCode) item { OutlinedTextField(model.code, { model.code = it }, Modifier.fillMaxWidth(),
                                enabled = !model.busy, label = { Text("Verificatiecode") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)) }
                            item { Button(onClick = { model.submit() }, enabled = !model.busy && model.email.isNotBlank() &&
                                model.password.isNotBlank() && (!model.needsCode || model.code.isNotBlank())) { Text("Aanmelden") } }
                        } else {
                            item { Text("Kies je locatie") }
                            items(model.locations) { loc ->
                                OutlinedButton({ model.submit(loc.id) }, enabled = !model.busy) { Text(loc.name) }
                            }
                            item { TextButton(model::logout, enabled = !model.busy) { Text("Opnieuw aanmelden") } }
                        }
                    } else {
                        item { Text(if (page.title == "Opvang") "Ouderportaal" else page.title, style = MaterialTheme.typography.h5) }
                        if (page.entries.isEmpty() && page.links.isEmpty()) item { Text("Geen gegevens gevonden.") }
                        page.conversation?.let { link ->
                            item { Button({ model.composeChat(link) }, enabled = !model.busy) { Text("Nieuw bericht") } }
                        }
                        items(page.entries) { entry -> EntryCard(entry, model.photos::load, { model.attachment(it, File(context.cacheDir, "bijlagen")) }, model::composeReply) }
                        items(page.links) { link ->
                            OutlinedButton({ model.open(link) }, Modifier.fillMaxWidth(), enabled = !model.busy,
                                contentPadding = PaddingValues(14.dp)) { Text(link.label) }
                        }
                    }
                }
            }
        }
    }
}
