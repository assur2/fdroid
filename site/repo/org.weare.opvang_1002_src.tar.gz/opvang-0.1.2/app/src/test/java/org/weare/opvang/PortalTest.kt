package org.weare.opvang
import org.jsoup.Jsoup
import org.junit.Assert.*
import org.junit.Test

class PortalTest {
    @Test fun linksUseAuthenticatedLocationAndRejectForeignHosts() {
        val doc = Jsoup.parse("<a href='/chats/1_2'>Groep</a><a href='https://example.org/chats'>Chats</a>", ORIGIN)
        assertEquals(listOf(Link("Groep", "/chats/1_2")), Pages.links(doc))
        assertNull(Pages.path("https://app.kovnet.nl@example.org/home"))
    }
    @Test fun historyPreservesParagraphsAndTableRows() {
        val doc = Jsoup.parse("<p>Vandaag<br>Goedemorgen</p><table><tr><td>Maandag</td><td>08.30</td></tr></table><form>Zend</form>")
        assertEquals(listOf("Vandaag", "Goedemorgen", "Maandag · 08.30"), Pages.lines(doc, true))
    }
}
