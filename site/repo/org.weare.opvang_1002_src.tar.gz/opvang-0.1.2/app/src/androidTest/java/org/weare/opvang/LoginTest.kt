package org.weare.opvang
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Rule
import org.junit.Test

class LoginTest {
    @get:Rule val ui = createAndroidComposeRule<MainActivity>()
    @Test fun loginRequiresBothFields() {
        ui.onNodeWithText("Aanmelden").assertIsNotEnabled()
        ui.onNodeWithText("E-mailadres").performTextInput("ouder@example.org")
        ui.onNodeWithText("Wachtwoord").performTextInput("test")
        ui.onNodeWithText("Aanmelden").assertIsEnabled()
    }
}
