# Opvang

Opvang is een onafhankelijke, Nederlandstalige Android-lezer voor het KOVnet-ouderportaal. De Kotlin Compose-interface toont het oudermenu van het aangemelde account, de tekst en tabellen van de portaalonderdelen, het chatoverzicht, de huidige berichten en op verzoek oudere berichten. Formulieren invullen, bijlagen downloaden, berichten verzenden en realtime meldingen vallen buiten versie 0.1.0.

Aanmelden gebeurt rechtstreeks bij app.kovnet.nl. De app ondersteunt de code- en locatiekeuze van de webaanmelding. De sessie leeft in het geheugen. Afmelden of het beëindigen van het proces wist deze sessie. De HTML-interface van KOVnet kan veranderen.

## Installeren

Voeg de [Weare Apps-feed](https://assur2.github.io/fdroid/repo/) toe aan F-Droid en zoek naar **Opvang**.

## Bouwen en testen

Gebruik JDK 17, Gradle 8.11.1 en Android SDK 35. Bouw met `gradle :app:assembleDebug`. Onder Actions → Test Opvang kun je de unit-tests en lint handmatig starten. Kies de emulatoroptie voor de aanmeldschermtest. Voor een controle met een eigen account: meld aan, open Schriftje en Chats, kies een gesprek, laad oudere berichten, ga terug en meld af.

## Release

Een tag `vMAJOR.MINOR.PATCH` bouwt en ondertekent de APK met de eigen Opvang-sleutel. De catalogus koppelt de APK en het bronarchief van dezelfde tag. Licentie: GPL-3.0-only (zie LICENSE).
