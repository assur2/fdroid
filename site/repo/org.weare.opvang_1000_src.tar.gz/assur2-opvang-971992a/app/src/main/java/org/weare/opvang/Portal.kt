// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import java.io.IOException
import java.net.URI
import org.json.JSONObject
import org.jsoup.Connection
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.TextNode

internal const val ORIGIN = "https://app.kovnet.nl"
internal data class Link(val label: String, val path: String)
internal data class Page(val title: String, val lines: List<String>, val links: List<Link>)
internal class Expired : IOException("Je sessie is verlopen. Meld je opnieuw aan.")
internal data class Location(val id: String, val name: String)
internal sealed interface Login {
    data object Ready : Login
    data object Code : Login
    data class Choose(val locations: List<Location>) : Login
}

internal object Pages {
    val menu = setOf("Contracten", "Stamgegevens", "Wijziging aanvragen", "Vakantie opgeven",
        "Facturen", "Jaaroverzichten", "Schriftje", "Nieuwsbrieven", "Chats", "Documenten Ouders")

    fun path(url: String): String? {
        val uri = runCatching { URI(url) }.getOrNull() ?: return null
        if (uri.scheme != "https" || uri.rawAuthority != "app.kovnet.nl" || uri.rawPath.isNullOrBlank()) return null
        return uri.rawPath + (uri.rawQuery?.let { "?$it" } ?: "")
    }

    fun links(doc: Document): List<Link> = doc.select("a[href]").mapNotNull { a ->
        val label = a.text().trim()
        val path = path(a.absUrl("href")) ?: return@mapNotNull null
        if (label.isBlank()) null else Link(label, path)
    }.distinct()

    fun lines(doc: Document, fragment: Boolean = false): List<String> {
        val body = doc.body().clone()
        body.select("script, style, nav, header, footer, aside, form, noscript, #first_level, #menu, #footer, #header, .menu").remove()
        if (!fragment) body.select("ul").filter { list -> list.select("a").count { it.text() in menu } >= 3 }.forEach { it.remove() }
        val root = body.selectFirst("main, [role=main], #content, .main-content") ?: body
        val lines = mutableListOf<String>()
        val buffer = StringBuilder()
        fun flush() {
            buffer.toString().trim().takeIf { it.isNotEmpty() }?.let(lines::add)
            buffer.clear()
        }
        fun walk(node: org.jsoup.nodes.Node) {
            when (node) {
                is TextNode -> buffer.append(node.text().replace(Regex("\\s+"), " "))
                is Element -> {
                    if (node.tagName() == "tr") {
                        flush()
                        val row = node.children().map { it.text() }.filter { it.isNotBlank() }
                        if (row.isNotEmpty()) lines += row.joinToString(" · ")
                        return
                    }
                    val block = node.isBlock || node.tagName() == "br"
                    if (block) flush()
                    node.childNodes().forEach(::walk)
                    if (block) flush()
                }
            }
        }
        walk(root)
        flush()
        return lines.filterNot { it in menu || it in setOf("Home", "Sitemap", "Terug", "Uitloggen") }
    }
}

internal class Portal {
    private val session = Jsoup.newSession().userAgent("Opvang/0.1 (Android)")
        .timeout(20000).maxBodySize(8 * 1024 * 1024).followRedirects(false)
    private var fields = emptyMap<String, String>()
    private var token = ""

    private fun request(path: String, data: Map<String, String>? = null, ajax: Boolean = false): Connection.Response {
        var url = ORIGIN + path
        var payload = data
        repeat(8) {
            require(Pages.path(url) != null) { "Onverwachte doorverwijzing van KOVnet." }
            val call = session.newRequest().url(url).ignoreContentType(true)
            if (payload != null) call.method(Connection.Method.POST).data(requireNotNull(payload))
            if (ajax) {
                call.header("X-Requested-With", "XMLHttpRequest")
                if (token.isNotEmpty()) call.header("X-CSRF-Token", token)
            }
            val response = call.execute()
            if (response.statusCode() !in listOf(301,302,303,307,308)) return response
            val location = response.header("Location") ?: throw IOException("Doorverwijzing ontbreekt.")
            url = URI(url).resolve(location).toString()
            if (response.statusCode() !in listOf(307,308)) payload = null
        }
        throw IOException("Te veel doorverwijzingen.")
    }

    fun check(email: String, password: String, code: String): Login {
        if (fields.isEmpty()) {
            val doc = request("/signin").parse()
            val form = doc.selectFirst("form#login_form") ?: throw IOException("Aanmeldformulier niet herkend.")
            fields = form.select("input[name]").associate { it.attr("name") to it.attr("value") }
            token = doc.selectFirst("meta[name=csrf-token]")?.attr("content").orEmpty()
        }
        val args = mapOf("session[email]" to email, "session[password]" to password, "code" to code)
        val json = JSONObject(request("/check_users", args, true).body())
        return when (json.optString("result")) {
            "2fa" -> Login.Code
            "many" -> {
                val array = json.getJSONArray("locations")
                Login.Choose((0 until array.length()).map {
                    val loc = array.getJSONObject(it)
                    Location(loc.getString("id").toString(), loc.getString("name"))
                })
            }
            "one" -> Login.Ready
            "none" -> throw IOException("Controleer je e-mailadres en wachtwoord.")
            "2fa_error" -> throw IOException("De verificatiecode is niet geaccepteerd.")
            "2fa_blocked" -> throw IOException("KOVnet heeft verdere pogingen geblokkeerd.")
            else -> throw IOException("Onbekend antwoord van KOVnet.")
        }
    }

    fun login(email: String, password: String, code: String, location: String): Page {
        val doc = request("/signin", fields + mapOf("session[email]" to email, "session[password]" to password,
            "code" to code, "location_id" to location)).parse()
        if (doc.selectFirst("#login_form") != null) throw IOException("Aanmelden is niet gelukt.")
        val home = page(Link("Opvang", "/home"))
        if (home.links.isEmpty()) throw IOException("Het oudermenu is niet herkend.")
        fields = emptyMap()
        return home
    }

    fun page(link: Link): Page {
        val chat = Regex("/chats/([0-9]+_[0-9]+)").matchEntire(link.path)
        val path = chat?.let { "/chat_messages/" + it.groupValues[1] } ?: link.path
        val doc = request(path).parse()
        if (doc.selectFirst("#login_form") != null) throw Expired()
        val links = Pages.links(doc)
        if (link.path == "/home") return Page("Opvang", emptyList(), links.filter { it.label in Pages.menu })
        if (chat != null) return Page(link.label, Pages.lines(doc, true),
            listOf(Link("Toon oudere berichten", "/chat_older_messages/" + chat.groupValues[1])))
        if (link.path == "/chats") return Page("Chats", emptyList(), links.filter { Regex("/chats/[0-9]+_[0-9]+").matches(it.path) })
        return Page(link.label, Pages.lines(doc, link.path.startsWith("/chat_older_messages/")), emptyList())
    }
}

