// SPDX-License-Identifier: GPL-3.0-only
package org.weare.notes

import java.io.File

// Write next to the target so a failed save leaves the previous note intact.
internal class NoteFile(private val target: File) {
    fun read() = if (target.exists()) target.readText() else ""

    fun save(text: String) {
        val parent = requireNotNull(target.absoluteFile.parentFile)
        val draft = File.createTempFile("note-", ".tmp", parent)
        try {
            draft.writeText(text, Charsets.UTF_8)
            java.nio.file.Files.move(draft.toPath(), target.toPath(),
                java.nio.file.StandardCopyOption.ATOMIC_MOVE,
                java.nio.file.StandardCopyOption.REPLACE_EXISTING)
        } finally {
            draft.delete()
        }
    }
}
