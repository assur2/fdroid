# Opvang

Opvang is een onafhankelijke Nederlandstalige Android-app voor het KOVnet-ouderportaal. Chats toont recente en oudere berichten met foto's. In Schriftje kun je foto's vergroten, door de foto's van een bericht vegen en reageren. Nieuwsbrieven en Documenten bevatten bijlagen die je kunt openen of opslaan.

Standaard gebruikt Opvang de mobiele JSON-API van KOVnet op `https://app.kovnet.nl/api/v2/`. De app ondersteunt verificatiecodes en organisatiekeuze. Het sessietoken blijft in het geheugen. Een geopend chatgesprek ontvangt berichtmeldingen via Pusher en haalt de nieuwe inhoud bij KOVnet op. Je verstuurt een bericht of reactie zelf met de verzendknop.

De mobiele aanmelding van KOVnet gebruikt bij de eerste stap een HTTPS-GET met het e-mailadres en wachtwoord in de querystring. Opvang logt de aanvraag-URL niet. Via **Aanmelden via het webportaal** kun je de bestaande HTML-aanmelding gebruiken. Beide verbindingen gebruiken een aparte sessie. Afmelden wist de sessie en conceptberichten.

## Installeren

Voeg de [Weare Apps-feed](https://assur2.github.io/fdroid/repo/) toe aan F-Droid en zoek naar **Opvang**.

## Bouwen en testen

Gebruik JDK 17, Gradle 8.11.1 en Android SDK 35. Bouw met `gradle :app:assembleDebug`. Onder Actions → Test Opvang kun je de unit-tests en lint handmatig starten. Kies de emulatoroptie voor de aanmeldschermtest. Voor een controle met een eigen account: meld aan, open Schriftje en Chats, kies een gesprek, laad oudere berichten, ga terug en meld af.

## Release

Een tag `vMAJOR.MINOR.PATCH` bouwt en ondertekent de APK met de eigen Opvang-sleutel. De catalogus koppelt de APK en het bronarchief van dezelfde tag. Licentie: GPL-3.0-only (zie LICENSE).
