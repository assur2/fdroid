// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import java.io.IOException
import java.net.URI
import org.json.JSONObject
import org.jsoup.Connection
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.TextNode

internal const val ORIGIN = "https://app.kovnet.nl"
internal data class Link(val label: String, val path: String)
internal data class Page(val title: String, val entries: List<Entry>, val links: List<Link>, val conversation: Link? = null, val canSend: Boolean = true)
internal class Expired : IOException("Je sessie is verlopen. Meld je opnieuw aan.")
internal data class Downloaded(val file: java.io.File, val name: String, val mime: String)
internal data class Location(val id: String, val name: String)
internal sealed interface Login {
    data object Ready : Login
    data object Code : Login
    data class Choose(val locations: List<Location>) : Login
}

internal object Pages {
    val menu = listOf("Schriftje", "Chats", "Nieuwsbrieven", "Documenten Ouders",
        "Wijziging aanvragen", "Vakantie opgeven")

    fun path(url: String): String? {
        val uri = runCatching { URI(url) }.getOrNull() ?: return null
        if (uri.scheme != "https" || uri.rawAuthority != "app.kovnet.nl" || uri.rawPath.isNullOrBlank()) return null
        return uri.rawPath + (uri.rawQuery?.let { "?$it" } ?: "")
    }

    fun mediaUrl(url: String): String? {
        path(url)?.let { return it }
        val uri = runCatching { URI(url) }.getOrNull() ?: return null
        return url.takeIf { uri.scheme == "https" && uri.host != null && uri.userInfo == null }
    }

    fun isFile(path: String): Boolean = path.startsWith("https://kdvnet-filepicker-copy.s3.eu-central-1.amazonaws.com/") || path.startsWith("/file_storage_") ||
        path.substringBefore('?').substringAfterLast('.').lowercase() in
            setOf("pdf", "doc", "docx", "xls", "xlsx", "png", "jpg", "jpeg", "odt", "zip")

    fun links(doc: Document): List<Link> = doc.select("a[href]").mapNotNull { a ->
        val label = a.text().trim()
        val path = path(a.absUrl("href")) ?: return@mapNotNull null
        if (label.isBlank()) null else Link(label, path)
    }.distinct()

    fun content(doc: Document, fragment: Boolean = false): Element {
        val body = doc.body().clone()
        body.select("script, style, nav, header, footer, aside, form, noscript, #first_level, #menu, #footer, #header, .menu").remove()
        if (!fragment) body.select("ul").filter { list -> list.select("a").count { it.text() in menu } >= 3 }.forEach { it.remove() }
        return body.selectFirst("main, [role=main], #content, .main-content") ?: body
    }

    fun lines(doc: Document, fragment: Boolean = false) = textLines(content(doc, fragment))

    fun textLines(root: Element): List<String> {
        val lines = mutableListOf<String>()
        val buffer = StringBuilder()
        fun flush() {
            buffer.toString().trim().takeIf { it.isNotEmpty() }?.let(lines::add)
            buffer.clear()
        }
        fun walk(node: org.jsoup.nodes.Node) {
            when (node) {
                is TextNode -> buffer.append(node.text().replace(Regex("\\s+"), " "))
                is Element -> {
                    if (node.tagName() == "tr") {
                        flush()
                        val row = node.children().map { it.text() }.filter { it.isNotBlank() }
                        if (row.isNotEmpty()) lines += row.joinToString(" · ")
                        return
                    }
                    val block = node.isBlock || node.tagName() == "br"
                    if (block) flush()
                    node.childNodes().forEach(::walk)
                    if (block) flush()
                }
            }
        }
        walk(root)
        flush()
        return lines.filterNot { it in menu || it in setOf("Home", "Sitemap", "Terug", "Uitloggen") }
    }
}

internal class Portal(private val api: MobileApi? = MobileApi()) {
    private val session = Jsoup.newSession().userAgent("Opvang/0.1 (Android)")
        .timeout(20000).maxBodySize(8 * 1024 * 1024).followRedirects(false)
    private var fields = emptyMap<String, String>()
    private var token = ""

    private fun request(path: String, data: Map<String, String>? = null, ajax: Boolean = false): Connection.Response {
        var url = ORIGIN + path
        var payload = data
        repeat(8) {
            require(Pages.path(url) != null) { "Onverwachte doorverwijzing van KOVnet." }
            val call = session.newRequest().url(url).ignoreContentType(true)
            if (payload != null) call.method(Connection.Method.POST).data(requireNotNull(payload))
            if (ajax) {
                call.header("X-Requested-With", "XMLHttpRequest")
                val csrf = payload?.get("authenticity_token") ?: token
                if (csrf.isNotEmpty()) call.header("X-CSRF-Token", csrf)
            }
            val response = call.execute()
            if (response.statusCode() !in listOf(301,302,303,307,308)) return response
            val location = response.header("Location") ?: throw IOException("Doorverwijzing ontbreekt.")
            url = URI(url).resolve(location).toString()
            if (response.statusCode() !in listOf(307,308)) payload = null
        }
        throw IOException("Te veel doorverwijzingen.")
    }

    fun check(email: String, password: String, code: String): Login {
        api?.let { return it.check(email,password,code) }
        if (fields.isEmpty()) {
            val doc = request("/signin").parse()
            val form = doc.selectFirst("form#login_form") ?: throw IOException("Aanmeldformulier niet herkend.")
            fields = form.select("input[name]").associate { it.attr("name") to it.attr("value") }
            token = doc.selectFirst("meta[name=csrf-token]")?.attr("content").orEmpty()
        }
        val args = mapOf("session[email]" to email, "session[password]" to password, "code" to code)
        val json = JSONObject(request("/check_users", args, true).body())
        return when (json.optString("result")) {
            "2fa" -> Login.Code
            "many" -> {
                val array = json.getJSONArray("locations")
                Login.Choose((0 until array.length()).map {
                    val loc = array.getJSONObject(it)
                    Location(loc.getString("id").toString(), loc.getString("name"))
                })
            }
            "one" -> Login.Ready
            "none" -> throw IOException("Controleer je e-mailadres en wachtwoord.")
            "2fa_error" -> throw IOException("De verificatiecode is niet geaccepteerd.")
            "2fa_blocked" -> throw IOException("KOVnet heeft verdere pogingen geblokkeerd.")
            else -> throw IOException("Onbekend antwoord van KOVnet.")
        }
    }

    fun login(email: String, password: String, code: String, location: String): Page {
        api?.let { return it.login(location) }
        val doc = request("/signin", fields + mapOf("session[email]" to email, "session[password]" to password,
            "code" to code, "location_id" to location)).parse()
        if (doc.selectFirst("#login_form") != null) throw IOException("Aanmelden is niet gelukt.")
        val home = page(Link("Opvang", "/home"))
        if (home.links.isEmpty()) throw IOException("Het oudermenu is niet herkend.")
        fields = emptyMap()
        return home
    }

    fun reply(form: ReplyForm, text: String) {
        api?.let { return it.reply(form,text) }
        val response = request(form.action, mapOf("utf8" to "✓", "authenticity_token" to form.token,
            "content" to text), ajax = true)
        if (response.url().path == "/signin") throw Expired()
    }

    fun subscribe(chat: Link, changed: () -> Unit) = api?.subscribe(chat, changed)

    fun sendMessage(chat: Link, message: String) {
        api?.let { return it.sendMessage(chat,message) }
        val key = Regex("/chats/([0-9]+_[0-9]+)").matchEntire(chat.path)?.groupValues?.get(1)
            ?: throw IOException("Gesprek niet herkend.")
        val page = request(chat.path).parse()
        if (page.selectFirst("#login_form") != null) throw Expired()
        if (page.selectFirst("#send-message:not([disabled])") == null) throw IOException("Verzenden is niet beschikbaar.")
        val csrf = page.selectFirst("meta[name=csrf-token]")?.attr("content").orEmpty()
        val response = request("/chats/new_message", mapOf("chat_key" to key, "message" to message,
            "authenticity_token" to csrf), ajax = true)
        if (response.url().path == "/signin") throw Expired()
    }

    private fun mediaResponse(path: String, maxBytes: Int): Connection.Response {
        var url = if (path.startsWith("/")) ORIGIN + path else path
        repeat(8) {
            val uri = URI(url)
            require(uri.scheme == "https" && uri.host != null && uri.userInfo == null)
            // Storage redirects receive a fresh, cookie-free request.
            val connection = if (Pages.path(url) != null) session.newRequest().url(url) else Jsoup.connect(url)
            api?.authorizeMedia(url, connection)
            val response = connection.followRedirects(false).timeout(20000).maxBodySize(maxBytes)
                .ignoreContentType(true).execute()
            if (response.statusCode() in listOf(301, 302, 303, 307, 308)) {
                url = uri.resolve(response.header("Location") ?: throw IOException("Fotolink ontbreekt.")).toString()
            } else {
                if (response.contentType()?.startsWith("text/html", ignoreCase = true) == true) throw IOException("Bestand niet beschikbaar.")
                return response
            }
        }
        throw IOException("Te veel doorverwijzingen.")
    }

    fun imageBytes(path: String) = mediaResponse(path, 24 * 1024 * 1024).bodyAsBytes()

    fun download(link: Link, directory: java.io.File): Downloaded {
        val response = mediaResponse(link.path, 0)
        val type = response.contentType()?.substringBefore(';') ?: "application/octet-stream"
        val suggested = android.webkit.URLUtil.guessFileName(response.url().toString(),
            response.header("Content-Disposition"), type)
        val name = if (link.label.matches(Regex(""".+\.[a-zA-Z0-9]{1,6}"""))) link.label else suggested
        val mime = if (type == "application/octet-stream") {
            android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.').lowercase()) ?: type
        } else type
        directory.mkdirs()
        val file = java.io.File.createTempFile("bijlage-", ".tmp", directory)
        try {
            response.bodyStream().use { input -> file.outputStream().use { output -> input.copyTo(output) } }
        } catch (e: Exception) { file.delete(); throw e }
        return Downloaded(file, name.substringAfterLast('/').substringAfterLast('\\'), mime)
    }

    private fun readPage(path: String): Document = request(path).parse().also {
        if (it.selectFirst("#login_form") != null) throw Expired()
    }

    private fun conversation(link: Link, otherChats: List<Link>): Page {
        val key = link.path.substringAfterLast('/')
        val recent = Entries.chat(readPage("/chat_messages/$key"))
        val older = Entries.chat(readPage("/chat_older_messages/$key"))
        val history = recent + older.filterNot { it in recent }
        return Page("Chats", history, otherChats, link)
    }

    fun page(link: Link): Page {
        api?.let { return it.page(link) }
        val doc = readPage(link.path)
        val links = Pages.links(doc)
        if (link.path == "/home") {
            val ordered = Pages.menu.flatMap { label -> links.filter { it.label == label } }
                .map { if (it.label == "Documenten Ouders") it.copy(label = "Documenten") else it }
            return Page("Opvang", emptyList(), ordered)
        }
        if (link.path == "/chats") {
            val chats = links.filter { Regex("/chats/[0-9]+_[0-9]+").matches(it.path) }
            val first = chats.firstOrNull() ?: return Page("Chats", emptyList(), emptyList())
            return conversation(first, chats.drop(1))
        }
        if (Regex("/chats/[0-9]+_[0-9]+").matches(link.path)) return conversation(link, emptyList())
        if (link.path.contains("/documents_categories")) {
            val root = Entries.documents(doc, link)
            val groups = root.links.distinctBy { it.path }.map { folder ->
                val files = Entries.documents(readPage(folder.path), folder).entries.flatMap { it.attachments }
                Entry(folder.label, attachments = files, lines = if (files.isEmpty()) listOf("Geen documenten.") else emptyList())
            }
            val groupedFiles = groups.flatMap { it.attachments }.map { it.path }.toSet()
            val ungrouped = root.entries.flatMap { it.attachments }.filterNot { it.path in groupedFiles }
            val general = if (ungrouped.isEmpty()) emptyList() else listOf(Entry("Algemeen", attachments = ungrouped))
            return Page("Documenten", general + groups, emptyList())
        }
        val entries = when {
            link.path.substringBefore('?').endsWith("/parent_newsletters") -> Entries.newsletters(doc)
            link.path.startsWith("/chat_older_messages/") -> Entries.chat(doc)
            link.path.substringBefore('?').endsWith("/daily_reports") -> Entries.reports(doc).ifEmpty { Entries.general(doc) }
            else -> Entries.general(doc)
        }
        return Page(link.label, entries, emptyList())
    }
}
