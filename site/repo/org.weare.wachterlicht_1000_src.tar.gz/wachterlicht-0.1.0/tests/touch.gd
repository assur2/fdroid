extends SceneTree

func _initialize():
	call_deferred("run")

func press(game, point):
	var event = InputEventScreenTouch.new()
	event.position = point
	event.pressed = true
	game._input(event)

func run():
	var game = load("res://Eiland.tscn").instantiate()
	root.add_child(game)
	await process_frame
	press(game, Vector2(440, 650))
	press(game, game.screen_point(game.SITES[1], 0.15))
	if game.choice != 1 or game.towers.size() != 1 or game.credits != 35:
		quit(1)
		return
	press(game, Vector2(1120, 650))
	press(game, Vector2(1183, 39))
	press(game, Vector2(1235, 39))
	if game.wave != 1 or not game.active or not game.paused or game.speed != 2:
		quit(1)
		return
	press(game, Vector2(640, 420))
	if game.paused:
		quit(1)
		return
	print("Tower selection, purchase, wave start, speed, pause and resume passed.")
	quit()
