# Wachterlicht

Defend the lighthouse through eight waves of mechanical crabs. Tap a tower card and a vacant build site, then tap Start golf. Tap a tower to upgrade or sell it. The top-right buttons control speed and pause.

The game code and original models, icons and sounds are licensed under GPL-3.0-only. See LICENSE. Runtime notices are in THIRD_PARTY.txt. Editable Blender models and their generator are in bron/.

## Android
Use Godot 4.4.1 Standard, its matching Android export templates, OpenJDK 17 and the Android SDK. With the Android and Java paths configured in Godot, run:

    mkdir -p build
    godot --headless --editor --import
    godot --headless --script tests/touch.gd
    godot --headless --export-release Android build/Wachterlicht.apk

The workflow signs releases with the app-specific certificate and stages each tagged source archive for the Weare Apps repository.
