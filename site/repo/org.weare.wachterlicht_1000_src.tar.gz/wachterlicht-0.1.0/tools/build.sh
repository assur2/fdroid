set -euo pipefail
tools_dir="${RUNNER_TEMP}/godot-wachterlicht"
mkdir -p "$tools_dir" build
touch build/.gdignore
base='https://github.com/godotengine/godot-builds/releases/download/4.4.1-stable'
(
  cd "$tools_dir"
  for file in Godot_v4.4.1-stable_linux.x86_64.zip Godot_v4.4.1-stable_export_templates.tpz; do
    curl --fail --silent --show-error --location --retry 3 "$base/$file" --output "$file"
  done
  sha512sum -c "$GITHUB_WORKSPACE/tools/checksums.txt"
  unzip -q Godot_v4.4.1-stable_linux.x86_64.zip
  target="$HOME/.local/share/godot/export_templates/4.4.1.stable"
  mkdir -p "$target"
  unzip -jq Godot_v4.4.1-stable_export_templates.tpz templates/android_debug.apk templates/android_release.apk -d "$target"
)
mkdir -p "$HOME/.config/godot"
cat > "$HOME/.config/godot/editor_settings-4.4.tres" <<EOF
[gd_resource type="EditorSettings" format=3]
[resource]
export/android/android_sdk_path = "$ANDROID_HOME"
export/android/java_sdk_path = "$JAVA_HOME"
EOF
engine="$tools_dir/Godot_v4.4.1-stable_linux.x86_64"
"$engine" --headless --editor --import
"$engine" --headless --script tests/touch.gd
"$engine" --headless --export-release Android build/Wachterlicht.apk
"$ANDROID_HOME/build-tools/35.0.0/aapt" dump badging build/Wachterlicht.apk > "$tools_dir/badging.txt"
name=$(sed -n "s/^package: .*versionName='\([^']*\)'.*/\1/p" "$tools_dir/badging.txt")
code=$(sed -n "s/^package: .*versionCode='\([^']*\)'.*/\1/p" "$tools_dir/badging.txt")
[[ "$name" =~ ^(0|[1-9][0-9]{0,2})\.(0|[1-9][0-9]{0,2})\.(0|[1-9][0-9]{0,2})$ ]]
[[ "$code" == $((BASH_REMATCH[1]*1000000+BASH_REMATCH[2]*1000+BASH_REMATCH[3])) ]]
grep -q "^package: name='org.weare.wachterlicht'" "$tools_dir/badging.txt"
if [[ "$GITHUB_REF_TYPE" == tag ]]; then [[ "$GITHUB_REF_NAME" == "v$name" ]]; fi
