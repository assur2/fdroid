extends Control

var game
var serif = SystemFont.new()
var sans = SystemFont.new()
var bold = SystemFont.new()
var navy = Color("#183438")
var panel = Color("#234449")
var muted = Color("#b4c7bc")
var paper = Color("#fff0ce")
var gold = Color("#efb963")
var border = Color("#57716c")
var shadow = Color("#102c32")

func _ready():
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	serif.font_names = PackedStringArray(["Georgia","DejaVu Serif"])
	sans.font_names = PackedStringArray(["Segoe UI","DejaVu Sans"])
	bold.font_names = sans.font_names
	bold.font_weight = 700

func rect(x,y,w,h,col):
	draw_rect(Rect2(x,y,w,h),col)

func label(x,y,value,px,col,font = null):
	draw_string(sans if font==null else font,Vector2(x,y),str(value),HORIZONTAL_ALIGNMENT_LEFT,-1,px,col)

func centered(x,y,value,px,col,font = null):
	var f = sans if font==null else font
	label(x-f.get_string_size(str(value),HORIZONTAL_ALIGNMENT_LEFT,-1,px).x*.5,y,value,px,col,f)

func symbol(id,x,y,s,col):
	draw_set_transform(Vector2(x,y),0,Vector2.ONE*s)
	match id:
		0:
			draw_colored_polygon(PackedVector2Array([Vector2(-9,10),Vector2(-6,-4),Vector2(5,-4),Vector2(9,10)]),col)
			rect(-8,-9,15,5,col)
			draw_line(Vector2(-3,-8),Vector2(-3,-16),col,3)
			draw_line(Vector2(3,-8),Vector2(3,-16),col,3)
		1:
			rect(-10,6,20,4,col)
			draw_colored_polygon(PackedVector2Array([Vector2(-6,5),Vector2(-13,-6),Vector2(1,-14),Vector2(8,0),Vector2(6,5)]),col)
			draw_line(Vector2(-13,-6),Vector2(1,-14),navy,3)
		2:
			draw_colored_polygon(PackedVector2Array([Vector2(0,-17),Vector2(8,-4),Vector2(0,7),Vector2(-8,-4)]),col)
			rect(-8,9,16,3,col)
		3:
			draw_colored_polygon(PackedVector2Array([Vector2(-8,15),Vector2(-4,-7),Vector2(4,-7),Vector2(8,15)]),col)
			rect(-6,-15,12,7,col)
			draw_colored_polygon(PackedVector2Array([Vector2(-8,-17),Vector2(0,-23),Vector2(8,-17)]),col)
			rect(-6,1,12,4,navy)
			draw_line(Vector2(10,-12),Vector2(19,-15),col,1.4)
			draw_line(Vector2(-10,-12),Vector2(-19,-15),col,1.4)
	draw_set_transform(Vector2.ZERO,0,Vector2.ONE)

func site_at(p):
	if p.y<80 or p.y>580: return -1
	var best = -1
	var dist = 1000.0
	for i in game.SITES.size():
		var ground = game.screen_point(game.SITES[i],.15)
		var center = ground + (Vector2(0,-15) if game.towers.has(i) else Vector2.ZERO)
		var d = p.distance_to(center)
		if d<(40 if OS.has_feature("mobile") else (33 if game.towers.has(i) else 26)) and d<dist:
			dist=d
			best=i
	return best

func click(p):
	if game.ended or game.paused:
		if Rect2(506,400,268,45).has_point(p):
			if game.ended: game.get_tree().reload_current_scene()
			else: game.paused = false
		return
	if Rect2(1215,15,47,47).has_point(p):
		game.paused=true
	elif Rect2(1158,15,53,47).has_point(p):
		game.speed=3-game.speed
	elif Rect2(1002,622,249,66).has_point(p):
		game.next_wave()
	elif game.selected>=0 and Rect2(310,622,220,66).has_point(p):
		game.upgrade()
	elif game.selected>=0 and Rect2(546,622,219,66).has_point(p):
		game.sell()
	elif game.selected>=0 and Rect2(781,622,188,66).has_point(p):
		game.pick(game.choice)
	elif game.selected<0 and p.y>=622 and p.y<=688 and p.x>=28 and p.x<976:
		var i = int((p.x-28)/316)
		if fmod(p.x-28,316)<302: game.pick(i)
	else:
		var i = site_at(p)
		if i>=0: game.site(i)
		elif p.y>80 and p.y<580: game.selected=-1

func world_marks():
	var s = game.selected if game.selected>=0 else game.hover
	if s>=0 and not game.paused and not game.ended:
		var t = game.towers.get(s)
		var kind = game.choice if t==null else t.type
		var radius = game.RANGE[kind]+(.25*(t.level-1) if t!=null else 0.0)
		var pts = PackedVector2Array()
		for j in 73:
			var a = TAU*j/72
			pts.append(game.screen_point(game.SITES[s]+Vector2.from_angle(a)*radius,.14))
		var fill = game.INK[kind]
		fill.a = .09
		draw_colored_polygon(pts,fill)
		draw_polyline(pts,game.INK[kind],2,true)
	for i in game.SITES.size():
		var p = game.screen_point(game.SITES[i],.15)
		if game.towers.has(i):
			if i==s or game.towers[i].level>1:
				draw_circle(p+Vector2(16,-5),8,navy,true,-1,true)
				centered(p.x+16,p.y-1,game.towers[i].level,11,paper,bold)
		else:
			draw_circle(p,11,navy,true,-1,true)
			draw_arc(p,11,0,TAU,25,gold if i==s else paper,1.5,true)
			draw_line(p-Vector2(4,0),p+Vector2(4,0),paper,1.5)
			draw_line(p-Vector2(0,4),p+Vector2(0,4),paper,1.5)
	for e in game.enemies:
		if e.hp>=e.max_hp: continue
		var p = game.camera.unproject_position(e.node.position+Vector3.UP*(.9 if e.kind<2 else 1.3))
		rect(p.x-12,p.y,24,4,shadow)
		rect(p.x-11,p.y+1,22*clampf(e.hp/e.max_hp,0,1),2,game.INK[2] if e.slow>0 else gold)

func _draw():
	if game==null: return
	world_marks()
	rect(0,0,1280,76,navy)
	rect(0,75,1280,2,gold)
	symbol(3,48,39,1.03,gold)
	label(86,48,"Wachterlicht",34,paper,serif)
	rect(333,17,1,40,border)
	label(357,34,"DUINPLAAT",13,gold,bold)
	label(357,53,"Westelijke kustpost",15,muted)
	for i in 3:
		var x = 644+i*166
		rect(x-18,20,1,35,border)
		label(x,31,["GOLF","KOPER","BAKEN"][i],12,muted,bold)
		label(x,57,[str(game.wave)+" / 8",str(game.credits),str(game.health)+" / 12"][i],24,gold if i==1 else paper,bold)
	rect(1158,17,51,43,panel)
	centered(1183,45,str(game.speed)+"×",19,paper,bold)
	rect(1216,17,43,43,panel)
	rect(1231,30,4,16,paper)
	rect(1241,30,4,16,paper)
	rect(0,580,1280,140,navy)
	rect(0,580,1280,2,gold)
	label(28,609,"WERF" if game.selected<0 else "TORENBEHEER",14,gold,bold)
	label(185,609,game.hint,15,paper)
	if game.selected<0:
		for i in 3:
			var x = 28+316*i
			var chosen = game.choice==i
			rect(x,622,302,66,gold if chosen else border)
			rect(x+2,624,298,62,panel if chosen else navy)
			symbol(i,x+31,658,1.18,game.INK[i])
			label(x+58,650,game.TYPES[i],23,paper,serif)
			label(x+58,673,["Snel precisievuur","Gebiedsschade","Vertraagt vijanden"][i],15,muted)
			label(x+244,651,str(game.PRICE[i]),20,gold,bold)
			label(x+244,672,"koper",13,muted)
	else:
		var t = game.towers[game.selected]
		symbol(t.type,53,659,1.2,game.INK[t.type])
		label(81,652,game.TYPES[t.type],24,paper,serif)
		label(81,674,"Niveau "+str(t.level)+" / 3",15,muted)
		rect(310,622,220,66,panel)
		centered(420,661,"Maximaal niveau" if t.level==3 else "Verbeter · "+str(game.upgrade_cost(game.selected)),18,paper,bold)
		rect(546,622,219,66,panel)
		centered(655,661,"Verkoop · +"+str(int(t.spent*.65)),18,paper,bold)
		rect(781,622,188,66,panel)
		centered(875,661,"Terug naar werf",17,paper)
	rect(1002,622,249,66,panel if game.active else gold)
	centered(1126,652,"Golf "+str(game.wave)+" onderweg" if game.active else "Start golf "+str(game.wave+1),22,paper if game.active else navy,bold)
	centered(1126,674,str(game.queue.size()+game.enemies.size())+" krabben over" if game.active else ("Tik om te starten" if OS.has_feature("mobile") else "Spatie"),14,muted if game.active else navy)
	if game.ended or game.paused:
		rect(0,0,1280,720,Color(0.03,.10,.12,.7))
		rect(398,233,484,241,navy)
		rect(398,233,484,3,gold)
		symbol(3,640,278,.8,gold)
		var title = "Pauze" if game.paused else ("Het baken brandt!" if game.health>0 else "Het baken is gedoofd")
		centered(640,334,title,34,paper,serif)
		centered(640,370,"De kustwacht wacht op je bevel." if game.paused else "%d krabben gestopt  ·  Golf %d van 8" % [game.kills,game.wave],17,muted)
		rect(506,400,268,45,gold)
		centered(640,429,"Verder spelen" if game.paused else "Opnieuw spelen",18,navy,bold)
