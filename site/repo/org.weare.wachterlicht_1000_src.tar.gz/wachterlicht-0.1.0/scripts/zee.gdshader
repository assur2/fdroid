shader_type spatial;
render_mode unshaded;
varying vec2 pos;
void vertex(){pos=(MODEL_MATRIX*vec4(VERTEX,1.0)).xz;}
void fragment(){
    float bands=sin(pos.y*3.6+0.75*sin(pos.x*0.7+TIME*0.45)+TIME*0.8);
    float ripples=smoothstep(0.95,1.0,bands)*smoothstep(0.40,0.92,sin(pos.x*1.6+pos.y*1.3+0.6*sin(pos.y*4.0)));
    float depth=smoothstep(0.83,1.5,length(pos/vec2(11.5,6.6)));
    vec3 sea=mix(vec3(0.33,0.65,0.64),vec3(0.18,0.43,0.47),depth);
    ALBEDO=sea+vec3(0.10,0.11,0.10)*ripples;
}
