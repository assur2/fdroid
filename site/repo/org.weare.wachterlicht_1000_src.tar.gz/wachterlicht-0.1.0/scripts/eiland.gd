extends Node3D

const Hud = preload("res://scripts/hud.gd")
const PATH = [Vector2(-10.4,0),Vector2(-7.5,0),Vector2(-6,-1.5),Vector2(-6,-3.35),Vector2(-4.8,-4.15),Vector2(-1.9,-4.15),Vector2(-.5,-2.9),Vector2(-.5,1.8),Vector2(.8,3.1),Vector2(4.45,3.1),Vector2(5.7,1.85),Vector2(5.7,-1.65),Vector2(7,-2.8),Vector2(8,-2.8)]
const SITES = [Vector2(-7.6,-1.8),Vector2(-4,-2.2),Vector2(-2.3,.15),Vector2(1.2,-1.8),Vector2(2.4,1.45),Vector2(4,-.85),Vector2(7.3,.25),Vector2(-2.6,3)]
const TYPES = ["Spits","Mortier","Vorst"]
const PRICE = [40,65,50]
const RANGE = [3.55,3.85,3.35]
const DAMAGE = [9,25,5]
const RATE = [.41,1.72,.65]
const INK = [Color("#ffcf66"),Color("#ff8660"),Color("#84ede6")]
const WAVES = 8
var camera = Camera3D.new()
var route = Curve3D.new()
var towers = {}
var enemies = []
var effects = []
var credits = 100
var health = 12
var wave = 0
var queue = []
var spawn_time = 0.0
var active = false
var ended = false
var paused = false
var speed = 1
var choice = 0
var selected = -1
var hover = -1
var elapsed = 0.0
var kills = 0
var hud
var hint = "Kies een bouwplek met + en plaats je eerste toren."
var sounds = {}
var sound_player = AudioStreamPlayer.new()
var models = {}
var beacon = Node3D.new()

func model(id, at):
	if not models.has(id):
		models[id] = load("res://assets/"+id+".glb")
	var n = models[id].instantiate()
	add_child(n)
	n.position = at
	return n

func pos3(point, height = 0.0):
	return Vector3(point.x,height,point.y)

func material(col):
	var m = StandardMaterial3D.new()
	m.albedo_color = col
	m.roughness = .9
	return m

func geometry(mesh, at, mat, parent = self):
	var n = MeshInstance3D.new()
	n.mesh = mesh
	n.material_override = mat
	parent.add_child(n)
	n.position = at
	return n

func _ready():
	for point in PATH:
		route.add_point(pos3(point))
	add_child(camera)
	camera.projection = Camera3D.PROJECTION_ORTHOGONAL
	camera.size = 18.5
	camera.position = Vector3(3.3,22,26)
	camera.look_at(Vector3(-.9,0,.65))
	camera.current = true
	var environment = Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("#447b82")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("#fff4df")
	environment.ambient_light_energy = .37
	var world = WorldEnvironment.new()
	world.environment = environment
	add_child(world)
	var sun = DirectionalLight3D.new()
	add_child(sun)
	sun.rotation_degrees = Vector3(-53,-34,0)
	sun.light_energy = .48
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 65
	var sea = PlaneMesh.new()
	sea.size = Vector2(160,160)
	var water = ShaderMaterial.new()
	water.shader = preload("res://scripts/zee.gdshader")
	geometry(sea,Vector3(0,-1.31,0),water)
	model("Duinplaat",Vector3.ZERO)
	model("Wachterlicht",pos3(PATH[-1]))
	add_child(beacon)
	beacon.position = pos3(PATH[-1],2.9)
	var jewel = SphereMesh.new()
	jewel.radius = .13
	jewel.height = .26
	geometry(jewel,Vector3(.43,0,0),material(Color("#ffe292")),beacon)
	for p in SITES:
		var base = CylinderMesh.new()
		base.top_radius = .70
		base.bottom_radius = .79
		base.height = .12
		base.radial_segments = 8
		geometry(base,pos3(p,.06),material(Color("#e0d3ac")))
	add_child(sound_player)
	sound_player.volume_db = -15
	for pair in [["build",520],["start",300],["leak",115],["finish",740]]:
		sounds[pair[0]] = chime(pair[1])
	hud = Hud.new()
	hud.game = self
	add_child(hud)

func chime(freq):
	var stream = AudioStreamWAV.new()
	stream.mix_rate = 22050
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	var bytes = PackedByteArray()
	bytes.resize(7600)
	for i in 3800:
		var t = i/22050.0
		var amp = sin(TAU*freq*t + t*t*280.0)*exp(-t*24)*minf(t*160,1)
		bytes.encode_s16(i*2,int(amp*17000))
	stream.data = bytes
	return stream

func tone(id):
	sound_player.stream = sounds[id]
	sound_player.play()

func pick(t):
	if ended or paused: return
	choice = t
	selected = -1
	hint = "Klik op een vrije bouwplek om "+TYPES[t]+" te plaatsen."

func site(i):
	if ended or paused: return
	if towers.has(i):
		selected = i
		hint = "Verbeter deze toren of verkoop hem voor een deel van de kosten."
		return
	if credits < PRICE[choice]:
		hint = "Te weinig koper voor "+TYPES[choice]+"."
		return
	credits -= PRICE[choice]
	var n = model(TYPES[choice],pos3(SITES[i],.12))
	towers[i] = {"type":choice,"level":1,"node":n,"timer":.1,"spent":PRICE[choice]}
	selected = -1
	tone("build")
	hint = TYPES[choice]+" gebouwd. Klik op de toren voor verbeteringen."

func upgrade_cost(i):
	return int(PRICE[towers[i].type]*.75)*int(towers[i].level)

func upgrade():
	if paused or ended or not towers.has(selected): return
	var t = towers[selected]
	if t.level >= 3: return
	var price = upgrade_cost(selected)
	if credits < price:
		hint = "Te weinig koper voor deze verbetering."
		return
	credits -= price
	t.spent += price
	t.level += 1
	t.node.scale *= 1.10
	tone("build")
	hint = TYPES[t.type]+" verbeterd naar niveau "+str(t.level)+"."

func sell():
	if paused or ended or not towers.has(selected): return
	var t = towers[selected]
	credits += int(t.spent*.65)
	t.node.queue_free()
	towers.erase(selected)
	selected = -1
	hint = "Toren verkocht. De bouwplek is weer vrij."

func next_wave():
	if ended or active or paused: return
	if towers.is_empty():
		hint = "Plaats eerst een toren op een bouwplek met +."
		return
	wave += 1
	active = true
	spawn_time = 0
	for j in 5+wave*2:
		queue.append(1 if wave>=3 and j%4==2 else 0)
	if wave==WAVES: queue.append(2)
	tone("start")
	hint = "De koningskrab komt aan land!" if wave==WAVES else "De krabben komen vanaf de westpier."

func spawn(kind):
	var n = model(["Loper","Schildkrab","Koning"][kind],pos3(PATH[0],.06))
	n.scale *= [0.78,1.08,1.55][kind]
	var hp = (13.0+wave*7.0)*[1.0,1.65,5.0][kind]
	enemies.append({"node":n,"hp":hp,"max_hp":hp,"d":0.0,"slow":0.0,"kind":kind,"speed":(1.4+.07*wave)*[1.0,.86,.67][kind]})

func beam(a,b,col,width):
	var length = a.distance_to(b)
	if length < .01: return
	var mesh = BoxMesh.new()
	mesh.size = Vector3(width,width,length)
	var n = geometry(mesh,(a+b)*.5,material(col))
	n.look_at(b,Vector3.UP if abs((b-a).normalized().y)<.99 else Vector3.RIGHT)
	effects.append({"node":n,"ttl":.13})

func fire(i,t,e):
	var a = t.node.position
	var b = e.node.position
	var kind = t.type
	t.node.rotation.y = atan2(a.x-b.x,a.z-b.z)
	var damage = DAMAGE[kind]*(1+.70*(t.level-1))
	beam(a+Vector3.UP*1.35,b+Vector3.UP*.4,INK[kind],.10 if kind==1 else .052)
	if kind==1:
		for other in enemies:
			if other.node.position.distance_to(b)<1.55:
				other.hp -= damage
				if other!=e: beam(b+Vector3.UP*.4,other.node.position+Vector3.UP*.35,INK[1],.06)
	else:
		e.hp -= damage
		if kind==2: e.slow = 1.65
	t.timer = RATE[kind]

func _process(delta):
	if hud == null: return
	hud.queue_redraw()
	if paused or ended: return
	var dt = minf(delta,.10)*speed
	elapsed += dt
	beacon.rotation.y += dt*1.7
	for fx in effects.duplicate():
		fx.ttl -= dt
		if fx.ttl<=0:
			fx.node.queue_free()
			effects.erase(fx)
	if not active: return
	spawn_time -= dt
	if not queue.is_empty() and spawn_time<=0:
		spawn(queue.pop_front())
		spawn_time = maxf(.46,1.07-wave*.055)
	for e in enemies:
		e.slow = maxf(0,e.slow-dt)
		e.d += e.speed*dt*(.48 if e.slow>0 else 1.0)
		var p = route.sample_baked(e.d)
		var ahead = route.sample_baked(e.d+.12)
		e.node.position = p+Vector3.UP*(.07+.04*abs(sin(e.d*8)))
		if ahead.distance_squared_to(p)>.00001:
			e.node.rotation.y = atan2(p.x-ahead.x,p.z-ahead.z)+.05*sin(e.d*9)
	for i in towers:
		var t = towers[i]
		t.timer -= dt
		if t.timer>0: continue
		var target = null
		for e in enemies:
			if e.hp>0 and e.node.position.distance_to(t.node.position)<RANGE[t.type]+.25*(t.level-1):
				if target==null or e.d>target.d: target=e
		if target!=null: fire(i,t,target)
	for e in enemies.duplicate():
		if e.hp<=0:
			credits += [4,7,30][e.kind]
			kills += 1
		elif e.d >= route.get_baked_length():
			health = maxi(0,health-[1,2,5][e.kind])
			tone("leak")
		else: continue
		enemies.erase(e)
		e.node.queue_free()
	if health<=0: ended=true
	elif enemies.is_empty() and queue.is_empty():
		active = false
		credits += 14+wave*2
		tone("finish")
		ended = wave==WAVES
		hint = "Golf doorstaan! Bouw of verbeter je torens voor de volgende golf."

func screen_point(p,h = 0.0):
	return camera.unproject_position(pos3(p,h))

func _input(event):
	if hud==null: return
	if event is InputEventScreenTouch and event.index == 0 and event.pressed:
		hud.click(event.position)
		return
	if event is InputEventMouseMotion:
		hover = hud.site_at(event.position)
	if event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT:
		hud.click(event.position)
	if event is InputEventKey and event.pressed and not event.echo:
		match event.keycode:
			KEY_1: pick(0)
			KEY_2: pick(1)
			KEY_3: pick(2)
			KEY_SPACE: next_wave()
			KEY_P, KEY_ESCAPE:
				if not ended: paused = not paused
			KEY_U: upgrade()
			KEY_DELETE: sell()
			KEY_F:
				if not paused and not ended: speed = 3-speed
			KEY_ENTER:
				if ended: get_tree().reload_current_scene()

