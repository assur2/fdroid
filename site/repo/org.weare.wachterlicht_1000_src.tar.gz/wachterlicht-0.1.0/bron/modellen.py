"""Run with Blender --background --python bron/modellen.py."""
from pathlib import Path
import math
import random
import bpy
import bmesh
from mathutils import Vector

ROOT = Path(__file__).resolve().parents[1]
rng = random.Random(37)
bpy.ops.wm.read_factory_settings(use_empty=True)
colors = dict(grass="92AE74", cliff="75665A", stone="BEB19A", sand="E6C18E",
              edge="CA9D6F", cream="F4DFAC", ivory="FFF0C7", brick="CB5339",
              roof="9B4030", dark="30474A", metal="536F70", copper="C88047",
              gold="F2B44D", aqua="70DFDA", trunk="725242", pine="396957",
              leaf="53836A", window="48676A", shadow="514C4A", plum="795481")
materials = []
for key, value in colors.items():
    mat = bpy.data.materials.new(key)
    rgb = [int(value[i:i+2],16)/255 for i in (0,2,4)]
    mat.diffuse_color = tuple(((c+0.055)/1.055)**2.4 if c>.04045 else c/12.92 for c in rgb)+(1,)
    mat.use_nodes = True
    mat.node_tree.nodes["Principled BSDF"].inputs["Base Color"].default_value = mat.diffuse_color
    materials.append(mat)
verts, faces, shades = [], [], []
def mesh(points, polygons, tones):
    offset=len(verts)
    verts.extend((x,-z,h) for x,z,h in points)
    faces.extend(tuple(offset+i for i in p) for p in polygons)
    shades.extend(tones)
def rings(levels, tones):
    n=len(levels[0])
    polys=[tuple(range(n))]
    cols=[tones[0]]
    for j in range(len(levels)-1):
        for i in range(n):
            k=(i+1)%n
            polys.append((j*n+i,j*n+k,(j+1)*n+k,(j+1)*n+i))
            cols.append(tones[j])
    polys.append(tuple(range((len(levels)-1)*n,len(levels)*n)))
    mesh(sum(levels,[]),polys,cols+[tones[-1]])
def cyl(x,z,h,r1,r2,height,color,n=12,turn=0):
    rings([[(x+r*math.cos(i*math.tau/n+turn),z+r*math.sin(i*math.tau/n+turn),y) for i in range(n)] for r,y in [(r1,h),(r2,h+height)]],[color,color])
def box(x,z,h,w,d,t,color,a=0):
    def level(y):
        return [(x+u*math.cos(a)-v*math.sin(a),z+u*math.sin(a)+v*math.cos(a),y) for u,v in [(-w/2,-d/2),(w/2,-d/2),(w/2,d/2),(-w/2,d/2)]]
    rings([level(h),level(h+t)],[color,color])
def export(name):
    geom=bpy.data.meshes.new(name)
    geom.from_pydata(verts,[],faces)
    for mat in materials: geom.materials.append(mat)
    for poly,col in zip(geom.polygons,shades): poly.material_index=list(colors).index(col)
    bm=bmesh.new(); bm.from_mesh(geom); bmesh.ops.recalc_face_normals(bm,faces=bm.faces[:]); bm.to_mesh(geom); bm.free()
    obj=bpy.data.objects.new(name,geom); bpy.context.collection.objects.link(obj)
    bpy.ops.object.select_all(action="DESELECT"); obj.select_set(True)
    bpy.ops.export_scene.gltf(filepath=str(ROOT/"assets"/(name+".glb")),use_selection=True,export_format="GLB")
    verts.clear(); faces.clear(); shades.clear()
    return obj
outline=[(-11,-3),(-10,-5.7),(-7.8,-6.8),(-4,-6.55),(-1.5,-7.1),(2.8,-6.75),(5,-7.0),(8.8,-6.1),(10.2,-4.2),(10.7,-1.2),(10,1.3),(10.1,3.9),(8,5.35),(5,5.8),(2.4,5.45),(-.3,6.1),(-4,5.8),(-6,6.25),(-9.4,4.9),(-10.6,2)]
rings([[(x*s,z*s,h+(rng.uniform(-.15,.15) if h<-.2 else 0)) for x,z in outline] for s,h in [(1.08,-1.8),(1.03,-1.26),(1.015,-.50),(1,-.15),(.985,0)]],["cliff","stone","cliff","edge","grass"])
path=[(-10.4,0),(-7.5,0),(-6,-1.5),(-6,-3.35),(-4.8,-4.15),(-1.9,-4.15),(-.5,-2.9),(-.5,1.8),(.8,3.1),(4.45,3.1),(5.7,1.85),(5.7,-1.65),(7,-2.8),(8,-2.8)]
for i,(x,z) in enumerate(path):
    cyl(x,z,.01,.62,.62,.026,"sand",16)
    if i==0: continue
    a,b=path[i-1]; length=math.hypot(x-a,z-b); angle=math.atan2(z-b,x-a)
    box((x+a)/2,(z+b)/2,.012,length,1.24,.024,"sand",angle)
    for j in range(int(length*2)):
        f=(j+.45)/(int(length*2)); off=rng.uniform(-.43,.43)
        box(a+(x-a)*f-off*math.sin(angle),b+(z-b)*f+off*math.cos(angle),.039,.16,.045,.012,"edge",angle+rng.uniform(-.4,.4))
def tree(x,z,s):
    cyl(x,z,0,.12*s,.095*s,.74*s,"trunk",7)
    for r,h,t,c in [(.57,.42,.94,"pine"),(.46,.87,.84,"leaf"),(.32,1.33,.72,"pine")]:
        cyl(x,z,h*s,r*s,.018*s,t*s,c,7,rng.random())
for x,z in [(-9,-4),(-8,-4.8),(-9.7,-2.8),(-5.3,-5.9),(-4.4,-5.8),(1,-5.4),(2,-5.8),(3,-5.6),(3.8,-4.9),(-8,3.2),(-8.9,2.4),(-6.8,4),(-4.8,4.6),(-4,4.9),(8.4,2.3),(7.6,3.5),(8.5,3.3),(1.5,4.8)]:
    tree(x,z,rng.uniform(.72,1.34))
def house(x,z,s):
    box(x,z,0,1.2*s,.93*s,.82*s,"cream")
    rings([[(x+u*s,z+v*s,h*s) for u,v,h in [(-.71,-.56,.81),(-.71,.56,.81),(-.71,0,1.29)]],[(x+u*s,z+v*s,h*s) for u,v,h in [(.71,-.56,.81),(.71,.56,.81),(.71,0,1.29)]]],["brick","brick"])
    box(x,z+.47*s,0,.26*s,.04,.52*s,"dark"); box(x+.36*s,z+.47*s,.40*s,.21*s,.04,.23*s,"window")
    box(x-.36*s,z-.16*s,.93*s,.18*s,.18*s,.48*s,"cliff")
house(6.3,-5,1); house(8.2,-4.8,.78); house(-7,2.5,.76)
for x,z in outline:
    for j in range(2):
        s=rng.uniform(.22,.62); cyl(x*1.065+rng.uniform(-.3,.3),z*1.07,-1.45,s,s*.68,s*.85,"stone",6,rng.random())
# Pier at the western landing.
for i in range(9): box(-10.5-i*.235,0,-.06,.215,1.45,.16,"trunk")
for x in (-10.8,-12.2):
    for z in (-.72,.72): cyl(x,z,-1.6,.09,.1,1.96,"trunk",8); cyl(x,z,.19,.115,.115,.09,"cream",8)
# Salt grass, flowering heather and pebbles in small off-road clumps.
for x,z in [(-9,-1.5),(-8.8,1.6),(-7.4,-3.4),(-6.6,-5.3),(-3,-5.6),(-2.8,-2.5),(-4.7,.5),(-6,1.3),(-5.5,3.7),(-2.7,4.6),(-1.4,4.4),(2.6,4.6),(5.5,4.35),(7,2.35),(8.7,.75),(4.4,-2.8),(2,-3.55),(.2,-5.2),(8.7,-3.8)]:
    for j in range(8):
        u=x+rng.uniform(-.45,.45); v=z+rng.uniform(-.28,.28)
        if j<2: cyl(u,v,.015,.15,.083,.10,"stone",5)
        else:
            cyl(u,v,.005,.068,.008,rng.uniform(.09,.21),"leaf",3,rng.random())
            if j==4: cyl(u,v,.12,.062,.047,.045,"gold",5)
export("Duinplaat")
x,z=0,0
for h,r1,r2,t,c in [(0,.88,.83,.24,"stone"),(.24,.68,.60,.85,"ivory"),(1.09,.60,.55,.57,"brick"),(1.66,.55,.46,.85,"ivory"),(2.51,.65,.65,.13,"dark"),(2.64,.41,.41,.55,"gold"),(3.19,.61,.07,.36,"brick"),(3.55,.055,.025,.32,"dark")]:
    cyl(x,z,h,r1,r2,t,c)
for i in range(8):
    a=i*math.tau/8; cyl(.44*math.cos(a),.44*math.sin(a),2.62,.042,.042,.58,"dark",6)
box(0,.64,.24,.26,.06,.50,"dark"); export("Wachterlicht").location.x=16
for idx,name in enumerate(["Spits","Mortier","Vorst"]):
    cyl(0,0,0,.62,.64,.16,"stone",8); cyl(0,0,.16,.50,.40,.72,"cream" if idx!=2 else "metal",8)
    cyl(0,0,.8,.51,.51,.16,"copper" if idx<2 else "aqua",10)
    if idx==0:
        cyl(0,0,.96,.35,.28,.33,"metal",8)
        for side in [-1,1]:
            box(side*.15,-.23,1.19,.14,.85,.15,"dark"); box(side*.15,-.62,1.18,.18,.13,.18,"gold")
    elif idx==1:
        cyl(0,0,.94,.31,.43,.59,"dark",10); cyl(0,0,1.53,.47,.47,.11,"copper",10); cyl(0,0,1.641,.32,.32,.012,"shadow",10)
    else:
        cyl(0,0,.96,.06,.33,.40,"aqua",5); cyl(0,0,1.36,.33,.012,.63,"aqua",5)
        for i in range(4):
            a=i*math.pi/2; cyl(.33*math.cos(a),.33*math.sin(a),.94,.09,.025,.44,"gold",6)
    export(name).location.x=20+idx*2
for idx,name in enumerate(["Loper","Schildkrab","Koning"]):
    shell=["brick","plum","copper"][idx]
    cyl(0,0,.19,.37,.45,.20,"dark",8); cyl(0,0,.37,.47,.28,.24,shell,8); cyl(0,0,.61,.22,.16,.07,"gold",6)
    for side in [-1,1]:
        for j in range(3): box(side*.43,(j-1)*.20,.09,.35,.09,.13,"metal",side*(j-1)*.4)
        box(side*.32,-.36,.22,.16,.36,.16,shell,side*.3); box(side*.36,-.53,.26,.19,.18,.15,"copper")
        cyl(side*.14,-.31,.42,.072,.072,.10,"aqua",8)
    export(name).location.x=20+idx*2; bpy.data.objects[name].location.y=3
bpy.context.preferences.filepaths.save_version = 0
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/"bron"/"Wachterlicht.blend"))

