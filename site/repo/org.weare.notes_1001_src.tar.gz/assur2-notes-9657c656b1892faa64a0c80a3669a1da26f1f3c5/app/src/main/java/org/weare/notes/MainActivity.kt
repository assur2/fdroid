// SPDX-License-Identifier: GPL-3.0-only
package org.weare.notes

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.io.IOException

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val file = NoteFile(filesDir.resolve("note.txt"))
        val initial = try { file.read() } catch (e: IOException) { null }
        setContent {
            MaterialTheme {
                if (initial == null) {
                    Text("Could not open note.txt", Modifier.systemBarsPadding())
                } else {
                    var draft by rememberSaveable { mutableStateOf(initial) }
                    var savedText by remember { mutableStateOf(initial) }
                    var status by remember { mutableStateOf("") }
                    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding().padding(16.dp)) {
                        Text("Notes", style = MaterialTheme.typography.h5)
                        OutlinedTextField(draft, { draft = it; status = "" },
                            label = { Text("Note") }, modifier = Modifier.fillMaxWidth().weight(1f))
                        Button(onClick = {
                            status = try {
                                file.save(draft)
                                savedText = draft
                                "Saved"
                            } catch (e: IOException) { "Save failed" }
                        }) { Text("Save") }
                        if (status.isNotEmpty()) Text(status)
                        else if (draft != savedText) Text("Unsaved changes")
                    }
                }
            }
        }
    }
}
