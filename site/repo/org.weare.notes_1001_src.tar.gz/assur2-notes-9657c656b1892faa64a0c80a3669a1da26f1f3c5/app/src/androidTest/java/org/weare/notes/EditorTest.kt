// SPDX-License-Identifier: GPL-3.0-only
package org.weare.notes

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class EditorTest {
    @get:Rule val ui = createAndroidComposeRule<MainActivity>()
    @Test fun saveWritesTextFileAndEditorReopensIt() {
        val text = "Remember the library"
        ui.onNode(hasSetTextAction()).performTextReplacement(text)
        ui.onNodeWithText("Unsaved changes").assertIsDisplayed()
        ui.onNodeWithText("Save").performClick()
        ui.onNodeWithText("Saved").assertIsDisplayed()
        ui.onNodeWithText("Unsaved changes").assertDoesNotExist()
        ui.activityRule.scenario.onActivity {
            org.junit.Assert.assertEquals(text, it.filesDir.resolve("note.txt").readText())
        }
        ui.activityRule.scenario.recreate()
        ui.onNodeWithText(text).assertExists()
    }
}
