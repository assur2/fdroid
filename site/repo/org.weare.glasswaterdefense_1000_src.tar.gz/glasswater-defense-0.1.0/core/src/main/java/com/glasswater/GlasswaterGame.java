package com.glasswater;

import com.badlogic.gdx.ApplicationAdapter;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.InputAdapter;
import com.badlogic.gdx.Preferences;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.GlyphLayout;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.MathUtils;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;

import static com.glasswater.Defense.*;

class GlasswaterGame extends ApplicationAdapter {
    static final int WIDTH = 1280, HEIGHT = 720;
    private static final int BOARD_X = 36, BOARD_Y = 108, TILE = 48, PANEL = 924;
    private static final int CARD_X = 942, CARD_WIDTH = 284, CARD_HEIGHT = 56;
    private static final float STEP = 1f / 60f;

    private static final Color BACK = color("0A1320"), PANEL_BG = color("111E2D");
    private static final Color BORDER = color("294256"), SLATE = color("1B3042");
    private static final Color WHITE = color("EAF5F6"), MUTED = color("A2B9C9"), DIM = color("678699");
    private static final Color MINT = color("74EFCE"), GOLD = color("FFD08B"), RED = color("FF8F89");
    private static final Color[] TOWER_COLORS = {MINT, GOLD, color("A2BCFF")};
    private static final Color[] GROUND = {color("18353A"), color("19383E"), color("1B3B40"), color("1B3B3C")};

    private final FitViewport viewport = new FitViewport(WIDTH, HEIGHT);
    private final Vector2 pointer = new Vector2();
    private final GlyphLayout layout = new GlyphLayout();
    private Defense defense = new Defense();
    private TowerType armed;
    private Tower selected;
    private ShapeRenderer shapes;
    private SpriteBatch batch;
    private BitmapFont font;
    private Preferences preferences;
    private int best, speed = 1;
    private boolean paused, confirmReset;
    private float accumulator, clock, noticeTime;
    private String notice = "";

    @Override
    public void create() {
        shapes = new ShapeRenderer();
        batch = new SpriteBatch();
        font = new BitmapFont();
        font.getRegion().getTexture().setFilter(Texture.TextureFilter.Linear, Texture.TextureFilter.Linear);
        preferences = Gdx.app.getPreferences("glasswater-defense");
        best = preferences.getInteger("waves-cleared", 0);
        Gdx.input.setCatchKey(Input.Keys.BACK, true);
        Gdx.input.setInputProcessor(new InputAdapter() {
            @Override
            public boolean touchDown(int x, int y, int pointerIndex, int button) {
                if (pointerIndex != 0) return false;
                if (button == Input.Buttons.RIGHT) {
                    clearSelection();
                    return true;
                }
                viewport.unproject(pointer.set(x, y));
                click(pointer.x, pointer.y);
                return true;
            }

            @Override
            public boolean keyDown(int key) {
                if (key == Input.Keys.ESCAPE || key == Input.Keys.BACK) {
                    if (confirmReset) confirmReset = false;
                    else if (armed != null || selected != null) clearSelection();
                    else togglePause();
                    return true;
                }
                if (confirmReset || !defense.active()) return false;
                switch (key) {
                    case Input.Keys.NUM_1: arm(TowerType.BOLT); return true;
                    case Input.Keys.NUM_2: arm(TowerType.MORTAR); return true;
                    case Input.Keys.NUM_3: arm(TowerType.FROST); return true;
                    case Input.Keys.SPACE: waveAction(); return true;
                    case Input.Keys.P: togglePause(); return true;
                    case Input.Keys.F: changeSpeed(); return true;
                    case Input.Keys.U: upgradeSelected(); return true;
                    default: return false;
                }
            }
        });
    }

    @Override
    public void resize(int width, int height) { viewport.update(width, height, true); }

    @Override
    public void pause() {
        if (defense.phase == Phase.WAVE) paused = true;
    }

    @Override
    public void render() {
        float dt = Math.min(Gdx.graphics.getDeltaTime(), 0.10f);
        if (!paused && !confirmReset) {
            clock += dt;
            accumulator += dt * speed;
            while (accumulator >= STEP) {
                defense.tick(STEP);
                accumulator -= STEP;
            }
        }
        if (noticeTime > 0) noticeTime -= dt;
        if (defense.cleared > best) {
            best = defense.cleared;
            preferences.putInteger("waves-cleared", best).flush();
        }

        ScreenUtils.clear(BACK);
        viewport.apply();
        shapes.setProjectionMatrix(viewport.getCamera().combined);
        batch.setProjectionMatrix(viewport.getCamera().combined);
        Gdx.gl.glEnable(GL20.GL_BLEND);
        Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        drawScenery();
        drawBoard();
        drawControls();
        shapes.end();

        batch.begin();
        drawLabels();
        batch.end();

        if (confirmReset || !defense.active()) drawModal();
    }

    private void drawScenery() {
        for (int i = 0; i < 5; i++) {
            rect(0, i * 155, WIDTH, 1, color("111E2C"));
        }
        rect(36, 647, 1208, 1, BORDER);
        rect(36, 84, 1208, 1, BORDER);
        diamond(57, 684, 19, 19, MINT);
        diamond(57, 684, 15, 15, BACK);
        line(47, 684, 52, 684, 2, MINT);
        line(52, 684, 55, 691, 2, MINT);
        line(55, 691, 60, 677, 2, MINT);
        line(60, 677, 63, 684, 2, MINT);
        line(63, 684, 67, 684, 2, MINT);
        statBox(620, 146, MINT);
        statBox(776, 146, GOLD);
        statBox(932, 146, defense.hull < 6 ? RED : MINT);
        button(1096, 660, 148, 48, false);
        for (int i = 0; i < WAVES; i++) {
            Color fill = i < defense.cleared ? MINT : i == defense.wave - 1 ? GOLD : BORDER;
            rect(939 + i * 25, 91, 19, 4, fill);
        }
    }

    private void statBox(int x, int width, Color accent) {
        rect(x, 659, width, 50, PANEL_BG);
        rect(x, 659, 3, 50, accent);
    }

    private void drawBoard() {
        rect(BOARD_X - 1, BOARD_Y - 1, COLS * TILE + 2, ROWS * TILE + 2, BORDER);
        for (int y = 0; y < ROWS; y++) {
            for (int x = 0; x < COLS; x++) {
                int sx = BOARD_X + x * TILE, sy = BOARD_Y + y * TILE;
                int pattern = (x * 31 ^ y * 37 ^ x * y * 9) & 15;
                rect(sx, sy, TILE, TILE, color("13292F"));
                rect(sx + 1, sy + 1, TILE - 1, TILE - 1, GROUND[pattern % GROUND.length]);
                if (pattern < 5 && !defense.canal[x][y]) {
                    rect(sx + 10 + pattern * 3, sy + 8, 7, 2, color("284A4A"));
                    rect(sx + 14 + pattern * 3, sy + 12, 4, 2, color("284A4A"));
                }
                if (pattern == 8 && !defense.canal[x][y]) {
                    diamond(sx + 15, sy + 29, 4, 6, color("285454"));
                    diamond(sx + 22, sy + 31, 3, 5, color("285454"));
                }
            }
        }
        drawCanal(44, color("4A6D6A"));
        drawCanal(38, color("204D58"));
        drawCanal(30, color("163E50"));
        for (int i = 1; i < ROUTE.length; i++) {
            int[] a = ROUTE[i - 1], b = ROUTE[i];
            float dx = b[0] - a[0], dy = b[1] - a[1];
            float length = Math.abs(dx) + Math.abs(dy);
            for (int j = 0; j < length; j++) {
                float t = (j + 0.5f) / length;
                float x = sx(a[0] + dx * t), y = sy(a[1] + dy * t);
                float drift = MathUtils.sin(clock * 1.7f + i + j) * 4;
                line(x - dx / length * 4 + drift, y - dy / length * 4,
                        x + dx / length * 4 + drift, y + dy / length * 4, 1, color("428593"));
            }
        }
        gate(0, 8, RED);
        gate(17, 2, MINT);

        if (selected != null) range(selected.x, selected.y, selected.range(), towerColor(selected.type));
        if (armed != null && Gdx.app.getType() == com.badlogic.gdx.Application.ApplicationType.Desktop) {
            Vector2 hover = viewport.unproject(pointer.set(Gdx.input.getX(), Gdx.input.getY()));
            int x = gridX(hover.x), y = gridY(hover.y);
            if (defense.canBuild(x, y)) {
                Color accent = defense.credits >= armed.price ? towerColor(armed) : RED;
                range(x, y, armed.range, accent);
                towerIcon(sx(x), sy(y), armed, 90, accent, 0.8f);
            }
        }
        for (Tower tower : defense.towers) {
            float x = sx(tower.x), y = sy(tower.y);
            Color accent = towerColor(tower.type);
            if (tower == selected) outline(x - 22, y - 22, 44, 44, accent);
            towerIcon(x, y, tower.type, tower.aim, accent, 1);
            for (int i = 0; i < tower.level; i++) rect(x - (tower.level * 7 - 2) / 2f + 7 * i, y - 19, 5, 2, accent);
        }
        for (Enemy enemy : defense.enemies) drawEnemy(enemy);
        for (Shot shot : defense.shots) {
            Color ink = new Color(towerColor(shot.type));
            ink.a = shot.life / .22f * .8f;
            if (shot.type == TowerType.MORTAR) {
                ring(sx(shot.tx), sy(shot.ty), 9 + (1 - shot.life / .22f) * 49, 2.5f, ink);
            } else {
                line(sx(shot.x), sy(shot.y), sx(shot.tx), sy(shot.ty), 2, ink);
                shapes.setColor(ink);
                shapes.circle(sx(shot.tx), sy(shot.ty), 6, 13);
            }
        }

        rect(48, 590, 118, 27, BACK);
        rect(758, 122, 129, 27, BACK);
        rect(48, 590, 3, 27, RED);
        rect(884, 122, 3, 27, MINT);
    }

    private void drawCanal(float thickness, Color color) {
        line(BOARD_X, sy(8), sx(0), sy(8), thickness, color);
        for (int i = 1; i < ROUTE.length; i++) {
            int[] a = ROUTE[i - 1], b = ROUTE[i];
            rect(sx(a[0]) - thickness / 2, sy(a[1]) - thickness / 2, thickness, thickness, color);
            line(sx(a[0]), sy(a[1]), sx(b[0]), sy(b[1]), thickness, color);
        }
        line(sx(17), sy(2), BOARD_X + COLS * TILE, sy(2), thickness, color);
    }

    private void gate(int col, int row, Color color) {
        float x = sx(col), y = sy(row);
        rect(x - 17, y - 19, 34, 38, BACK);
        rect(x - 13, y - 16, 26, 32, SLATE);
        for (int i = -1; i <= 1; i++) {
            line(x + 3 + i * 6, y - 9, x + 8 + i * 6, y, 2, color);
            line(x + 8 + i * 6, y, x + 3 + i * 6, y + 9, 2, color);
        }
    }

    private void range(int x, int y, float radius, Color accent) {
        int left = Math.max(0, x - MathUtils.ceil(radius));
        int right = Math.min(COLS - 1, x + MathUtils.ceil(radius));
        int bottom = Math.max(0, y - MathUtils.ceil(radius));
        int top = Math.min(ROWS - 1, y + MathUtils.ceil(radius));
        Color tint = new Color(accent.r, accent.g, accent.b, .13f);
        for (int gy = bottom; gy <= top; gy++) {
            for (int gx = left; gx <= right; gx++) {
                if (Vector2.dst2(gx, gy, x, y) <= radius * radius) {
                    rect(sx(gx) - 23, sy(gy) - 23, 46, 46, tint);
                }
            }
        }
        outline(sx(x) - 23, sy(y) - 23, 46, 46, accent);
    }

    private void drawEnemy(Enemy enemy) {
        float x = sx(enemy.x), y = sy(enemy.y);
        Color accent = enemy.flash > 0 ? WHITE : switch (enemy.type) {
            case SKIFF -> RED;
            case DART -> GOLD;
            case BARGE -> color("ECA9EF");
            case DREAD -> color("FF655B");
        };
        int size = switch (enemy.type) {
            case DART -> 10;
            case SKIFF -> 13;
            case BARGE -> 16;
            case DREAD -> 22;
        };
        diamond(x + 2, y - 2, size + 3, size + 2, BACK);
        diamond(x, y, size, size, accent);
        diamond(x, y, size - 4, size - 4, color("203448"));
        rect(x - 2, y - 2, 4, 4, accent);
        if (enemy.slow > 0) ring(x, y, size + 4, 1.3f, TOWER_COLORS[2]);
        rect(x - size, y + size + 4, size * 2, 4, BACK);
        rect(x - size + 1, y + size + 5, (size * 2 - 2) * MathUtils.clamp(enemy.hp / enemy.maxHp, 0, 1), 2, accent);
    }

    private void towerIcon(float x, float y, TowerType type, float angle, Color accent, float scale) {
        float radius = 17 * scale;
        shapes.setColor(BACK);
        shapes.circle(x + 1, y - 2, radius + 2, 8);
        shapes.setColor(accent);
        shapes.circle(x, y, radius, 8);
        shapes.setColor(SLATE);
        shapes.circle(x, y, radius - 2, 8);
        float dx = MathUtils.cosDeg(angle), dy = MathUtils.sinDeg(angle);
        if (type == TowerType.BOLT) {
            line(x, y, x + dx * 15 * scale, y + dy * 15 * scale, 5 * scale, accent);
            diamond(x, y, 6 * scale, 6 * scale, accent);
        } else if (type == TowerType.MORTAR) {
            line(x, y, x + dx * 12 * scale, y + dy * 12 * scale, 9 * scale, accent);
            shapes.setColor(accent);
            shapes.circle(x, y, 7 * scale, 6);
            shapes.setColor(BACK);
            shapes.circle(x, y, 3 * scale, 6);
        } else {
            diamond(x, y, 9 * scale, 12 * scale, accent);
            diamond(x, y, 4 * scale, 7 * scale, WHITE);
        }
    }

    private void drawControls() {
        rect(PANEL, 108, 320, 528, PANEL_BG);
        outline(PANEL, 108, 320, 528, BORDER);
        rect(PANEL + 1, 633, 318, 3, MINT);
        for (TowerType type : TowerType.values()) {
            int y = cardY(type);
            rect(CARD_X, y, CARD_WIDTH, CARD_HEIGHT, armed == type ? color("254354") : SLATE);
            outline(CARD_X, y, CARD_WIDTH, CARD_HEIGHT, armed == type ? towerColor(type) : BORDER);
            towerIcon(970, y + 28, type, 45, towerColor(type), .9f);
        }
        rect(942, 208, 284, 152, BACK);
        outline(942, 208, 284, 152, BORDER);
        if (selected != null) {
            button(954, 222, 135, 36, selected.level < 3 && defense.credits >= selected.upgradePrice());
            button(1097, 222, 117, 36, false);
        } else {
            for (int i = 0; i < 6; i++) rect(956 + i * 13, 222, 8, 2, BORDER);
        }
        button(942, 157, 284, 43, defense.phase == Phase.BUILD || paused);
        button(942, 119, 137, 30, false);
        button(1089, 119, 137, 30, false);
    }

    private void drawLabels() {
        text("GLASSWATER", 87, 708, WHITE, 1.98f);
        text("D E F E N S E", 89, 674, MINT, 0.93f);
        stat("WAVE", Math.min(WAVES, defense.phase == Phase.BUILD ? defense.wave + 1 : defense.wave) + " / " + WAVES, 633, MINT);
        stat("CREDITS", Integer.toString(defense.credits), 789, GOLD);
        stat("GATE HULL", defense.hull + " / 18", 945, defense.hull < 6 ? RED : MINT);
        buttonText("Restart", 1096, 660, 148, 48, WHITE, 1.07f);

        text("FLEET INLET", 61, 609, RED, 0.94f);
        text("LOCK GATE", 771, 141, MINT, 0.94f);
        text("TOWER DEPLOYMENT", 944, 613, WHITE, 1.28f);
        text("Choose a tower, then select a bank tile.", 944, 584, MUTED, 0.99f);
        for (TowerType type : TowerType.values()) {
            int y = cardY(type);
            text(type.label, 996, y + 46, WHITE, 1.22f);
            text(type.description, 997, y + 23, MUTED, 0.91f);
            right(Integer.toString(type.price) + " C", 1213, y + 44, defense.credits >= type.price ? GOLD : DIM, 1.0f);
        }

        if (selected == null) {
            int wave = Math.min(WAVES, defense.phase == Phase.WAVE ? defense.wave : defense.wave + 1);
            text(defense.phase == Phase.WAVE ? "FLEET IN TRANSIT" : "NEXT FLEET", 955, 346, DIM, 0.9f);
            text("Wave " + wave + "   /   " + fleetSize(wave) + " vessels", 955, 321, WHITE, 1.21f);
            text(fleetDescription(wave), 955, 296, MUTED, 0.94f);
            text("Select a built tower to upgrade or sell.", 955, 263, MUTED, 0.94f);
        } else {
            text("TOWER SELECTED", 955, 346, DIM, 0.9f);
            text(selected.type.label + "   /   Level " + selected.level, 955, 321, towerColor(selected.type), 1.23f);
            text(MathUtils.round(selected.damage()) + " damage   /   " + selected.range() + " tile range",
                    955, 289, MUTED, 0.96f);
            String upgrade = selected.level == 3 ? "Max level" : "Upgrade  " + selected.upgradePrice() + " C";
            boolean affordable = selected.level < 3 && defense.credits >= selected.upgradePrice();
            buttonText(upgrade, 954, 222, 135, 36, affordable ? BACK : MUTED, 0.98f);
            buttonText("Sell  +" + selected.resale(), 1097, 222, 117, 36, WHITE, 0.98f);
        }

        String action = defense.phase == Phase.BUILD ? "Dispatch wave " + (defense.wave + 1)
                : paused ? "Resume wave" : "Fleet in transit";
        buttonText(action, 942, 157, 284, 43, defense.phase == Phase.BUILD || paused ? BACK : MUTED, 1.24f);
        buttonText(paused ? "Resume" : "Pause", 942, 119, 137, 30,
                defense.phase == Phase.WAVE ? WHITE : DIM, 0.98f);
        buttonText("Speed  " + speed + "x", 1089, 119, 137, 30, WHITE, 0.98f);

        String status = noticeTime > 0 ? notice : paused ? "Paused. Build and upgrade before resuming."
                : armed != null ? "Select a bank tile to deploy " + armed.label + "."
                : Gdx.app.getType() == com.badlogic.gdx.Application.ApplicationType.Desktop
                    ? "1-3   Select tower      SPACE   Dispatch      P   Pause      F   Speed"
                    : "Build on the banks and keep the fleet away from the lock gate.";
        text(status, 36, 63, noticeTime > 0 ? GOLD : MUTED, 1f);
        right("BEST  " + best + " / " + WAVES, 1244, 63, MINT, 1f);
    }

    private void stat(String label, String value, int x, Color accent) {
        text(label, x, 700, MUTED, .82f);
        text(value, x, 681, accent, 1.24f);
    }

    private String fleetDescription(int wave) {
        if (wave == WAVES) return "Mixed fleet with a dreadnought";
        if (wave >= 4) return "Skiffs, fast darts and armored barges";
        if (wave >= 2) return "Skiffs and fast darts";
        return "Light skiffs";
    }

    private void drawModal() {
        boolean won = defense.phase == Phase.WON;
        Color accent = confirmReset || won ? MINT : RED;
        Gdx.gl.glEnable(GL20.GL_BLEND);
        shapes.begin(ShapeRenderer.ShapeType.Filled);
        rect(0, 0, WIDTH, HEIGHT, new Color(0.02f, 0.04f, .07f, .80f));
        rect(400, 231, 480, 258, PANEL_BG);
        outline(400, 231, 480, 258, BORDER);
        rect(400, 485, 480, 4, accent);
        if (confirmReset) {
            button(436, 255, 192, 49, false);
            button(652, 255, 192, 49, true);
        } else {
            button(516, 255, 248, 49, true);
        }
        shapes.end();
        batch.begin();
        center(confirmReset ? "Restart defense?" : won ? "Glasswater holds" : "The gate has fallen",
                640, 440, accent, 2.12f);
        center(confirmReset ? "Start a new run from wave one." : defense.cleared + " waves cleared   /   " + defense.kills + " vessels sunk",
                640, 376, WHITE, 1.24f);
        if (confirmReset) {
            buttonText("Keep playing", 436, 255, 192, 49, WHITE, 1.08f);
            buttonText("Restart", 652, 255, 192, 49, BACK, 1.08f);
        } else {
            buttonText("Play again", 516, 255, 248, 49, BACK, 1.08f);
        }
        batch.end();
    }

    private void click(float x, float y) {
        if (confirmReset) {
            if (inside(x, y, 436, 255, 192, 49)) confirmReset = false;
            if (inside(x, y, 652, 255, 192, 49)) reset();
            return;
        }
        if (!defense.active()) {
            if (inside(x, y, 516, 255, 248, 49)) reset();
            return;
        }
        if (inside(x, y, 1096, 660, 148, 48)) {
            confirmReset = true;
            return;
        }
        for (TowerType type : TowerType.values()) {
            if (inside(x, y, CARD_X, cardY(type), CARD_WIDTH, CARD_HEIGHT)) {
                arm(type);
                return;
            }
        }
        if (inside(x, y, 942, 157, 284, 43)) waveAction();
        if (inside(x, y, 942, 119, 137, 30)) togglePause();
        if (inside(x, y, 1089, 119, 137, 30)) changeSpeed();
        if (selected != null && inside(x, y, 954, 222, 135, 36)) upgradeSelected();
        if (selected != null && inside(x, y, 1097, 222, 117, 36)) {
            defense.sell(selected);
            selected = null;
        }
        if (!inside(x, y, BOARD_X, BOARD_Y, TILE * COLS, TILE * ROWS)) return;
        int col = gridX(x), row = gridY(y);
        Tower tower = defense.towerAt(col, row);
        if (tower != null) {
            selected = tower;
            armed = null;
        } else if (armed != null) {
            if (!defense.canBuild(col, row)) notifyPlayer("Build on a bank tile.");
            else if (defense.build(col, row, armed) == null) notifyPlayer("More credits needed.");
            else noticeTime = 0;
        } else {
            selected = null;
            notifyPlayer("Choose an Arc, Flare or Rime tower first.");
        }
    }

    private void waveAction() {
        if (paused) paused = false;
        else if (defense.phase == Phase.BUILD) {
            noticeTime = 0;
            defense.dispatch();
        }
    }

    private void reset() {
        defense = new Defense();
        clearSelection();
        paused = false;
        confirmReset = false;
        speed = 1;
        accumulator = 0;
        noticeTime = 0;
    }

    private void clearSelection() { selected = null; armed = null; }
    private void arm(TowerType type) {
        selected = null;
        armed = armed == type ? null : type;
        noticeTime = 0;
    }
    private void upgradeSelected() {
        if (selected != null && selected.level < 3 && !defense.upgrade(selected)) notifyPlayer("More credits needed.");
    }
    private void togglePause() { if (defense.phase == Phase.WAVE) paused = !paused; }
    private void changeSpeed() { speed = speed % 3 + 1; }
    private void notifyPlayer(String message) { notice = message; noticeTime = 3f; }

    private static int cardY(TowerType type) { return 503 - type.ordinal() * 65; }
    private static float sx(float col) { return BOARD_X + (col + 0.5f) * TILE; }
    private static float sy(float row) { return BOARD_Y + (row + 0.5f) * TILE; }
    private static int gridX(float x) { return MathUtils.floor((x - BOARD_X) / TILE); }
    private static int gridY(float y) { return MathUtils.floor((y - BOARD_Y) / TILE); }
    private static boolean inside(float x, float y, int bx, int by, int w, int h) {
        return x >= bx && x < bx + w && y >= by && y < by + h;
    }
    private static Color color(String hex) { return Color.valueOf(hex); }
    private static Color towerColor(TowerType type) { return TOWER_COLORS[type.ordinal()]; }
    private void rect(float x, float y, float w, float h, Color ink) {
        shapes.setColor(ink);
        shapes.rect(x, y, w, h);
    }
    private void outline(float x, float y, float w, float h, Color ink) {
        rect(x, y, w, 1, ink);
        rect(x, y + h - 1, w, 1, ink);
        rect(x, y + 1, 1, h - 2, ink);
        rect(x + w - 1, y + 1, 1, h - 2, ink);
    }
    private void line(float x, float y, float tx, float ty, float width, Color ink) {
        shapes.setColor(ink);
        shapes.rectLine(x, y, tx, ty, width);
    }
    private void diamond(float x, float y, float rx, float ry, Color ink) {
        shapes.setColor(ink);
        shapes.triangle(x - rx, y, x, y - ry, x + rx, y);
        shapes.triangle(x - rx, y, x + rx, y, x, y + ry);
    }
    private void ring(float x, float y, float radius, float width, Color ink) {
        for (int i = 0; i < 36; i++) {
            float a = i * 10f, b = a + 10;
            line(x + MathUtils.cosDeg(a) * radius, y + MathUtils.sinDeg(a) * radius,
                    x + MathUtils.cosDeg(b) * radius, y + MathUtils.sinDeg(b) * radius, width, ink);
        }
    }
    private void button(int x, int y, int w, int h, boolean primary) {
        rect(x, y, w, h, primary ? MINT : SLATE);
        outline(x, y, w, h, primary ? color("B0FFE9") : BORDER);
    }
    private void text(String value, float x, float y, Color ink, float scale) {
        font.getData().setScale(scale);
        font.setColor(ink);
        font.draw(batch, value, x, y);
    }
    private void center(String value, float x, float y, Color ink, float scale) {
        font.getData().setScale(scale);
        layout.setText(font, value);
        text(value, x - layout.width / 2, y, ink, scale);
    }
    private void right(String value, float x, float y, Color ink, float scale) {
        font.getData().setScale(scale);
        layout.setText(font, value);
        text(value, x - layout.width, y, ink, scale);
    }
    private void buttonText(String value, int x, int y, int w, int h, Color ink, float scale) {
        font.getData().setScale(scale);
        center(value, x + w / 2f, y + (h + font.getCapHeight()) / 2f, ink, scale);
    }

    @Override
    public void dispose() {
        font.dispose();
        batch.dispose();
        shapes.dispose();
    }
}
