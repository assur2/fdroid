package com.glasswater;

import java.util.ArrayList;
import java.util.List;

final class Defense {
    static final int COLS = 18, ROWS = 11, WAVES = 12;
    static final int[][] ROUTE = {{0,8}, {4,8}, {4,3}, {8,3}, {8,8}, {13,8}, {13,2}, {17,2}};
    static final float ROUTE_LENGTH = routeLength();

    enum Phase { BUILD, WAVE, WON, LOST }

    enum TowerType {
        BOLT("Arc", "Rapid single-target fire", 45, 2.55f, 14, 0.36f),
        MORTAR("Flare", "Area damage", 75, 3.1f, 32, 1.00f),
        FROST("Rime", "Slows targets on hit", 60, 2.8f, 13, 0.67f);

        final String label, description;
        final int price;
        final float range, damage, interval;

        TowerType(String label, String description, int price, float range, float damage, float interval) {
            this.label = label;
            this.description = description;
            this.price = price;
            this.range = range;
            this.damage = damage;
            this.interval = interval;
        }
    }

    enum EnemyType {
        SKIFF("Skiffs", 1f, 1.65f, 1, 7),
        DART("Darts", 0.64f, 2.65f, 1, 8),
        BARGE("Barges", 2.20f, 1.10f, 2, 12),
        DREAD("Dreadnought", 9f, 0.78f, 5, 50);

        final String label;
        final float armor, speed;
        final int breach, bounty;

        EnemyType(String label, float armor, float speed, int breach, int bounty) {
            this.label = label;
            this.armor = armor;
            this.speed = speed;
            this.breach = breach;
            this.bounty = bounty;
        }
    }

    static final class Tower {
        final int x, y;
        final TowerType type;
        int level = 1;
        int spent;
        float cooldown;
        float aim = 90;

        Tower(int x, int y, TowerType type) {
            this.x = x;
            this.y = y;
            this.type = type;
            spent = type.price;
        }

        float range() { return type.range + (level - 1) * 0.30f; }
        float damage() { return type.damage * (level == 1 ? 1 : level == 2 ? 1.9f : 3.2f); }
        int upgradePrice() { return level == 1 ? type.price : type.price * 3 / 2; }
        int resale() { return spent * 7 / 10; }
    }

    static final class Enemy {
        final EnemyType type;
        final float maxHp;
        float hp, progress, x, y, slow, flash;

        Enemy(EnemyType type, float hp) {
            this.type = type;
            this.hp = hp;
            maxHp = hp;
            locate();
        }

        void locate() {
            float left = progress;
            for (int i = 1; i < ROUTE.length; i++) {
                int[] from = ROUTE[i - 1], to = ROUTE[i];
                int segment = length(from, to);
                if (left <= segment) {
                    x = from[0] + (to[0] - from[0]) * left / segment;
                    y = from[1] + (to[1] - from[1]) * left / segment;
                    return;
                }
                left -= segment;
            }
            x = ROUTE[ROUTE.length - 1][0];
            y = ROUTE[ROUTE.length - 1][1];
        }
    }

    static final class Shot {
        final TowerType type;
        final float x, y, tx, ty;
        float life = 0.22f;

        Shot(Tower tower, Enemy target) {
            type = tower.type;
            x = tower.x;
            y = tower.y;
            tx = target.x;
            ty = target.y;
        }
    }

    final List<Tower> towers = new ArrayList<>();
    final List<Enemy> enemies = new ArrayList<>();
    final List<Shot> shots = new ArrayList<>();
    final boolean[][] canal = new boolean[COLS][ROWS];
    Phase phase = Phase.BUILD;
    int credits = 160, hull = 18, wave, cleared, kills;
    int spawned;
    float spawnClock;

    Defense() {
        for (int i = 1; i < ROUTE.length; i++) {
            int[] a = ROUTE[i - 1], b = ROUTE[i];
            int dx = Integer.compare(b[0], a[0]), dy = Integer.compare(b[1], a[1]);
            for (int n = 0; n <= length(a, b); n++) {
                canal[a[0] + dx * n][a[1] + dy * n] = true;
            }
        }
    }

    Tower towerAt(int x, int y) {
        for (Tower tower : towers) {
            if (tower.x == x && tower.y == y) return tower;
        }
        return null;
    }

    boolean canBuild(int x, int y) {
        return active() && x >= 0 && y >= 0 && x < COLS && y < ROWS
                && !canal[x][y] && towerAt(x, y) == null;
    }

    Tower build(int x, int y, TowerType type) {
        if (!canBuild(x, y) || credits < type.price) return null;
        Tower tower = new Tower(x, y, type);
        towers.add(tower);
        credits -= type.price;
        return tower;
    }

    boolean upgrade(Tower tower) {
        if (!active() || !towers.contains(tower) || tower.level == 3 || credits < tower.upgradePrice()) return false;
        int price = tower.upgradePrice();
        credits -= price;
        tower.spent += price;
        tower.level++;
        return true;
    }

    boolean sell(Tower tower) {
        if (!active() || !towers.remove(tower)) return false;
        credits += tower.resale();
        return true;
    }

    boolean active() { return phase == Phase.BUILD || phase == Phase.WAVE; }

    void dispatch() {
        if (phase != Phase.BUILD) return;
        wave++;
        spawned = 0;
        spawnClock = 0;
        phase = Phase.WAVE;
    }

    static int fleetSize(int wave) { return 8 + 2 * wave; }

    static EnemyType fleetMember(int wave, int index) {
        if (wave == WAVES && index == fleetSize(wave) - 1) return EnemyType.DREAD;
        if (wave >= 4 && index % (wave >= 9 ? 4 : 6) == 2) return EnemyType.BARGE;
        if (wave >= 2 && index % (wave >= 7 ? 3 : 5) == 1) return EnemyType.DART;
        return EnemyType.SKIFF;
    }

    void tick(float dt) {
        for (int i = shots.size() - 1; i >= 0; i--) {
            Shot shot = shots.get(i);
            shot.life -= dt;
            if (shot.life <= 0) shots.remove(i);
        }
        if (phase != Phase.WAVE) return;

        spawnClock -= dt;
        if (spawned < fleetSize(wave) && spawnClock <= 0) {
            EnemyType type = fleetMember(wave, spawned++);
            enemies.add(new Enemy(type, type.armor * (27 + 9 * wave + 1.12f * wave * wave)));
            spawnClock += Math.max(0.41f, 0.86f - 0.041f * wave);
        }
        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy enemy = enemies.get(i);
            enemy.progress += dt * enemy.type.speed * (enemy.slow > 0 ? 0.53f : 1f);
            enemy.slow -= dt;
            enemy.flash -= dt;
            enemy.locate();
            if (enemy.progress >= ROUTE_LENGTH) {
                enemies.remove(i);
                hull = Math.max(0, hull - enemy.type.breach);
            }
        }
        if (hull == 0) {
            phase = Phase.LOST;
            return;
        }

        for (Tower tower : towers) {
            tower.cooldown -= dt;
            if (tower.cooldown > 0) continue;
            Enemy target = targetFor(tower);
            if (target == null) continue;
            fire(tower, target);
        }
        for (int i = enemies.size() - 1; i >= 0; i--) {
            Enemy enemy = enemies.get(i);
            if (enemy.hp <= 0) {
                enemies.remove(i);
                credits += enemy.type.bounty;
                kills++;
            }
        }
        if (spawned == fleetSize(wave) && enemies.isEmpty()) {
            cleared = wave;
            credits += 24 + wave * 3;
            phase = cleared == WAVES ? Phase.WON : Phase.BUILD;
        }
    }

    private Enemy targetFor(Tower tower) {
        Enemy target = null;
        float range = tower.range();
        for (Enemy enemy : enemies) {
            if (enemy.hp > 0 && distanceSquared(tower.x, tower.y, enemy.x, enemy.y) <= range * range
                    && (target == null || enemy.progress > target.progress)) {
                target = enemy;
            }
        }
        return target;
    }

    private void fire(Tower tower, Enemy target) {
        tower.cooldown = tower.type.interval;
        tower.aim = (float) Math.toDegrees(Math.atan2(target.y - tower.y, target.x - tower.x));
        shots.add(new Shot(tower, target));
        hit(target, tower.damage());
        if (tower.type == TowerType.MORTAR) {
            float radius = 1.2f + (tower.level - 1) * 0.18f;
            for (Enemy enemy : enemies) {
                if (enemy != target && enemy.hp > 0
                        && distanceSquared(target.x, target.y, enemy.x, enemy.y) <= radius * radius) {
                    hit(enemy, tower.damage() * 0.72f);
                }
            }
        }
        if (tower.type == TowerType.FROST) target.slow = 1.25f + tower.level * 0.30f;
    }

    private static void hit(Enemy target, float damage) {
        target.hp -= damage;
        target.flash = 0.1f;
    }

    private static float distanceSquared(float x, float y, float tx, float ty) {
        float dx = tx - x, dy = ty - y;
        return dx * dx + dy * dy;
    }

    private static int length(int[] a, int[] b) {
        return Math.abs(a[0] - b[0]) + Math.abs(a[1] - b[1]);
    }

    private static int routeLength() {
        int result = 0;
        for (int i = 1; i < ROUTE.length; i++) result += length(ROUTE[i - 1], ROUTE[i]);
        return result;
    }
}
