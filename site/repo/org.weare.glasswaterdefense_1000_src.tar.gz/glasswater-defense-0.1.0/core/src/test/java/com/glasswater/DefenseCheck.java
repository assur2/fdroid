package com.glasswater;

import static com.glasswater.Defense.*;

public final class DefenseCheck {
    private static final int[][] PLAN = {
        {5, 7, 0}, {6, 6, 1}, {7, 7, 0}, {7, 6, 2}, {9, 7, 1},
        {5, 4, 1}, {7, 4, 0}, {10, 7, 1}, {12, 7, 2}, {12, 5, 1},
        {14, 4, 0}, {14, 3, 1}, {15, 3, 2}, {3, 7, 0}, {8, 2, 1},
        {11, 7, 1}, {12, 6, 0}, {14, 6, 0}, {10, 9, 1}, {16, 3, 0}
    };

    public static void main(String[] args) {
        Defense defense = new Defense();
        require(defense.build(4, 5, TowerType.BOLT) == null, "Canal accepted a tower");
        Tower arc = defense.build(5, 7, TowerType.BOLT);
        require(arc != null && defense.credits == 115, "Purchase did not debit credits");
        require(defense.build(5, 7, TowerType.FROST) == null, "Occupied bank accepted a tower");
        require(defense.upgrade(arc) && arc.level == 2 && defense.credits == 70, "Upgrade failed");
        require(defense.sell(arc) && defense.credits == 133 && defense.towerAt(5, 7) == null, "Refund failed");
        verifyLoss();
        verifyCampaign();
    }

    private static void verifyLoss() {
        Defense empty = new Defense();
        resolveWave(empty);
        require(empty.hull == 8 && empty.cleared == 1, "Leaks did not damage the gate");
        resolveWave(empty);
        require(empty.hull == 0 && empty.phase == Phase.LOST, "An undefended gate did not fall");
    }

    private static void verifyCampaign() {
        Defense defense = new Defense();
        int planned = 0;
        for (int wave = 1; wave <= WAVES; wave++) {
            while (planned < PLAN.length) {
                int[] tile = PLAN[planned];
                if (defense.build(tile[0], tile[1], TowerType.values()[tile[2]]) == null) break;
                planned++;
                if (planned >= wave + 1) break;
            }
            for (Tower tower : defense.towers) {
                if (tower.level < 3) defense.upgrade(tower);
            }
            resolveWave(defense);
            require(defense.cleared == wave, "Campaign stalled at wave " + wave + ", hull " + defense.hull);
        }
        require(defense.phase == Phase.WON, "Final wave did not finish the campaign");
        System.out.println("Campaign won with " + defense.hull + " hull and " + defense.kills + " vessels sunk.");
    }

    private static void resolveWave(Defense defense) {
        defense.dispatch();
        require(defense.phase == Phase.WAVE, "Wave did not dispatch");
        for (int i = 0; i < 12_000 && defense.phase == Phase.WAVE; i++) defense.tick(1f / 60f);
        require(defense.phase != Phase.WAVE, "Wave did not resolve");
    }

    private static void require(boolean pass, String message) {
        if (!pass) throw new AssertionError(message);
    }
}
