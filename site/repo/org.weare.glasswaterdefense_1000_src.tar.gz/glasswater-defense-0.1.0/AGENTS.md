# Android emulator assignment

Glasswater Defense uses its own Android 14 x86_64 AVD, `GlasswaterDefense_Pixel`, on fixed port **5568**. Keep its writable AVD files private to this project. Start it on an invisible Windows desktop with `-no-window -gpu swiftshader_indirect -no-snapshot -port 5568`. Use `adb -s emulator-5568` for commands targeting this instance.
