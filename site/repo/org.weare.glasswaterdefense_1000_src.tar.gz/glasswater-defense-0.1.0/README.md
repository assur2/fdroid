# Glasswater Defense

Defend the lock gate across 12 waves. The fleet enters from the upper left and follows the canal to the lower right. The gate starts with 18 hull. Sink vessels and clear waves to earn credits for new towers and upgrades.

| Tower | Cost | Role |
| --- | ---: | --- |
| Arc | 45 | Fast single-target shots |
| Flare | 75 | Splash damage against clustered vessels |
| Rime | 60 | Slows individual targets |

Choose a tower and select a bank tile to build. Select a placed tower to upgrade it twice or sell it for 70% of its total cost. You can build during waves and while paused. Dispatch each wave when ready. The game saves your best wave count locally.

## Play

- **Windows x64** — Extract the entire portable ZIP, then run `GlasswaterDefense.exe`. The ZIP includes a Java runtime. On Windows, number keys 1–3 select a tower, Space dispatches or resumes a wave, P pauses, F cycles speed, and U upgrades the selected tower. Right-click clears the selection.
- **Android 6.0 or later** — Install the debug APK. The game runs in landscape and uses tap controls.

## Build

The game and simulation are shared in `core`. Windows uses libGDX's LWJGL3 backend. Android uses the libGDX Android backend with native libraries for ARM and x86.

Install JDK 17 and Android SDK Platform 34. Set `JAVA_HOME` and `ANDROID_HOME`, or define `sdk.dir` in an untracked `local.properties`.

```powershell
.\gradlew.bat :core:check :windows:installDist :android:assembleDebug
```

- Launch the Java-based Windows build with `windows\build\install\GlasswaterDefense\bin\GlasswaterDefense.bat`.
- The Android APK is at `android\build\outputs\apk\debug\android-debug.apk`.
- The shared regression check exercises deployment, upgrades, selling, loss, and a complete 12-wave win.

To rebuild the portable Windows ZIP on Windows x64, set `JAVA_HOME` to a Windows x64 JDK 17 and run the following commands. The package script uses the built-in .NET Framework C# compiler for the graphical launcher and bundles a Java runtime with the game.

```powershell
.\gradlew.bat :windows:installDist
.\windows\package.ps1
```

The package is written to `windows\build\distributions\GlasswaterDefense-Portable-Windows-x64.zip`.

## F-Droid

The Android release package is `org.weare.glasswaterdefense`. Releases use the format `vMAJOR.MINOR.PATCH`. The release workflow builds and signs the APK, then publishes it to GitHub for the [Weare Apps catalog](https://assur2.github.io/fdroid/repo/). The catalog links the matching tagged source archive.

Glasswater Defense is licensed under [GPL-3.0-only](LICENSE).
