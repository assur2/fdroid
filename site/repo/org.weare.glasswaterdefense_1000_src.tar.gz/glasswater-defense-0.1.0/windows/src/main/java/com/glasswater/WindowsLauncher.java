package com.glasswater;

import com.badlogic.gdx.backends.lwjgl3.Lwjgl3Application;
import com.badlogic.gdx.backends.lwjgl3.Lwjgl3ApplicationConfiguration;

public final class WindowsLauncher {
    public static void main(String[] args) {
        Lwjgl3ApplicationConfiguration config = new Lwjgl3ApplicationConfiguration();
        config.setTitle("Glasswater Defense");
        config.setWindowedMode(1280, 720);
        config.setWindowSizeLimits(800, 450, -1, -1);
        config.useVsync(true);
        config.setBackBufferConfig(8, 8, 8, 8, 0, 0, 4);
        config.disableAudio(true);
        new Lwjgl3Application(new GlasswaterGame(), config);
    }
}
