[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
if (!$env:JAVA_HOME) { throw 'Set JAVA_HOME to a Windows x64 JDK 17 installation.' }

$jlink = Join-Path $env:JAVA_HOME 'bin/jlink.exe'
$csc = Join-Path $env:WINDIR 'Microsoft.NET/Framework64/v4.0.30319/csc.exe'
$libraries = Join-Path $PSScriptRoot 'build/install/GlasswaterDefense/lib'
if (!(Test-Path -LiteralPath (Join-Path $libraries 'windows.jar'))) {
    throw 'Run .\gradlew.bat :windows:installDist from the project root first.'
}

$build = (Resolve-Path -LiteralPath (Join-Path $PSScriptRoot 'build')).Path
$stage = Join-Path $build ('package-' + [guid]::NewGuid().ToString('N'))
$portable = Join-Path $stage 'GlasswaterDefense'
$output = Join-Path $PSScriptRoot 'build/distributions/GlasswaterDefense-Portable-Windows-x64.zip'
$zip = Join-Path $stage 'GlasswaterDefense.zip'
try {
    New-Item -ItemType Directory -Path (Join-Path $portable 'lib') | Out-Null

    Get-ChildItem -LiteralPath $libraries -Filter '*.jar' |
        Where-Object Name -NotMatch 'natives-(linux|macos|windows-x86)' |
        Copy-Item -Destination (Join-Path $portable 'lib')

    $runtime = Join-Path $portable 'runtime'
    & $jlink --add-modules 'java.base,java.desktop,jdk.unsupported' --strip-debug --no-header-files --no-man-pages --compress=2 --output $runtime
    if ($LASTEXITCODE -ne 0) { throw "jlink failed with exit code $LASTEXITCODE." }
    Copy-Item -LiteralPath (Join-Path $runtime 'bin/javaw.exe') -Destination (Join-Path $runtime 'bin/GlasswaterDefense-javaw.exe')

    $launcher = Join-Path $portable 'GlasswaterDefense.exe'
    $icon = Join-Path $PSScriptRoot 'launcher/crest.ico'
    $source = Join-Path $PSScriptRoot 'launcher/Launcher.cs'
    & $csc /nologo /target:winexe /platform:x64 /optimize+ /reference:System.Windows.Forms.dll "/win32icon:$icon" "/out:$launcher" $source
    if ($LASTEXITCODE -ne 0) { throw "Launcher compilation failed with exit code $LASTEXITCODE." }

    New-Item -ItemType Directory -Force -Path (Split-Path -Parent $output) | Out-Null
    Compress-Archive -LiteralPath $portable -DestinationPath $zip
    Move-Item -LiteralPath $zip -Destination $output -Force
    Get-Item -LiteralPath $output
}
finally {
    if (Test-Path -LiteralPath $stage) {
        $stagedPath = (Resolve-Path -LiteralPath $stage).Path
        if ((Split-Path -Parent $stagedPath) -eq $build) {
            Remove-Item -LiteralPath $stagedPath -Recurse -Force
        }
    }
}
