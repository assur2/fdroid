using System;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows.Forms;

[assembly: AssemblyTitle("Glasswater Defense")]
[assembly: AssemblyProduct("Glasswater Defense")]
[assembly: AssemblyVersion("1.0.0.0")]

internal static class Launcher
{
    [STAThread]
    private static int Main()
    {
        try
        {
            string folder = AppDomain.CurrentDomain.BaseDirectory;
            string java = Path.Combine(folder, "runtime", "bin", "GlasswaterDefense-javaw.exe");
            string libraries = Path.Combine(folder, "lib");

            if (!File.Exists(java) || !File.Exists(Path.Combine(libraries, "windows.jar")))
            {
                throw new InvalidOperationException(
                    "The game files are incomplete. Extract the entire Glasswater Defense ZIP and open the launcher inside the extracted folder.");
            }

            var start = new ProcessStartInfo
            {
                FileName = java,
                Arguments = "-cp \"" + Path.Combine(libraries, "*") + "\" com.glasswater.WindowsLauncher",
                WorkingDirectory = folder,
                UseShellExecute = false,
                CreateNoWindow = true
            };

            using (Process game = Process.Start(start))
            {
                game.WaitForExit();
                if (game.ExitCode != 0)
                {
                    throw new InvalidOperationException("The game closed with exit code " + game.ExitCode + ".");
                }
            }

            return 0;
        }
        catch (Exception error)
        {
            MessageBox.Show(error.Message, "Glasswater Defense", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }
}
