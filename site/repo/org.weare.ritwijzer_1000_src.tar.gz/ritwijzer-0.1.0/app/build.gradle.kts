plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}
android {
    namespace = "org.weare.ritwijzer"
    compileSdk = 34
    defaultConfig {
        applicationId = "org.weare.ritwijzer"
        minSdk = 26
        targetSdk = 34
        versionCode = providers.gradleProperty("releaseCode").orElse("1000").get().toInt()
        versionName = providers.gradleProperty("releaseName").orElse("0.1.0").get()
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.compose.material3:material3")
    implementation("org.maplibre.gl:android-sdk:11.8.2")
}
