package org.weare.ritwijzer

import android.Manifest
import android.content.*
import android.content.pm.PackageManager
import android.location.*
import android.net.Uri
import android.os.Bundle
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.*
import org.json.JSONArray
import java.util.Locale


private val pine=Color(0xff145c50)
private val cream=Color(0xfff6f5ee)
private val ink=Color(0xff18332d)
private enum class Page(val title:String,val summary:String) {
    Home("Ritwijzer",""), Route("Route","Plan je rit en volg de afslagen"), Traffic("Verkeer","Hinder en werkzaamheden"), Fuel("Tanken","Tankstations en pompprijzen"), Charge("Laden","Laadpunten, vrije stekkers en tarieven"), Park("Parkeren","Zones, tarieven en parkeeracties"), Help("Pechhulp","Locatie en Wegenwacht"), Account("Mijn gegevens","Ledenpas, voertuig en bewaarde routes")
}
private fun Context.open(uri:String) {
    val action=if(uri.startsWith("tel:")) Intent.ACTION_DIAL else Intent.ACTION_VIEW
    try { startActivity(Intent(action,Uri.parse(uri))) }
    catch(e:ActivityNotFoundException) { Toast.makeText(this,"Geen geschikte app geïnstalleerd.",Toast.LENGTH_LONG).show() }
}
class MainActivity: ComponentActivity(),LocationListener {
    private val manager by lazy { getSystemService(LocationManager::class.java) }
    private var pending: ((Point)->Unit)?=null
    private var continuous=false
    private var latest by mutableStateOf<Point?>(null)
    private val timeout=android.os.Handler(Looper.getMainLooper())
    private val expired=Runnable {
        pending=null
        if(!continuous) manager.removeUpdates(this)
        toast("Geen actuele locatie ontvangen. Vul een adres in of probeer buiten opnieuw.")
    }
    private val permission=registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if(permitted()) listen() else { stopGps(); toast("Locatie niet toegestaan. Je kunt een adres invullen.") }
    }
    private fun permitted()=checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)==PackageManager.PERMISSION_GRANTED || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)==PackageManager.PERMISSION_GRANTED
    fun gps(track:Boolean=false, callback:(Point)->Unit) {
        continuous=track; pending=callback
        if(permitted()) listen() else permission.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION,Manifest.permission.ACCESS_FINE_LOCATION))
    }
    @Suppress("MissingPermission")
    private fun listen() {
        if(!permitted()) return
        val providers=listOf(LocationManager.GPS_PROVIDER,LocationManager.NETWORK_PROVIDER).filter { runCatching { manager.isProviderEnabled(it) }.getOrDefault(false) }
        if(providers.isEmpty()) { stopGps(); toast("Zet locatie aan of vul een adres in."); return }
        val known=providers.mapNotNull { runCatching { manager.getLastKnownLocation(it) }.getOrNull() }.maxByOrNull { it.elapsedRealtimeNanos }
        var listening=false
        for(p in providers) if(runCatching { manager.requestLocationUpdates(p,2000L,3f,this,Looper.getMainLooper()) }.isSuccess) listening=true
        if(!listening) { stopGps(); toast("Locatieprovider niet beschikbaar."); return }
        timeout.removeCallbacks(expired)
        timeout.postDelayed(expired,30000)
        if(known!=null && SystemClock.elapsedRealtimeNanos()-known.elapsedRealtimeNanos in 0..30_000_000_000L) onLocationChanged(known)
    }
    override fun onLocationChanged(location:Location) {
        latest=Point(location.latitude,location.longitude)
        timeout.removeCallbacks(expired)
        val next=pending; pending=null
        if(!continuous) manager.removeUpdates(this)
        next?.invoke(latest!!)
    }
    fun stopGps() { continuous=false; pending=null; timeout.removeCallbacks(expired); manager.removeUpdates(this) }
    override fun onStart() { super.onStart(); if(continuous && permitted()) listen() }
    override fun onStop() { manager.removeUpdates(this); timeout.removeCallbacks(expired); if(!continuous) pending=null; super.onStop() }
    @Deprecated("Legacy provider callback")
    override fun onStatusChanged(provider:String?,status:Int,extras:Bundle?) {}
    override fun onProviderEnabled(provider:String) {}
    override fun onProviderDisabled(provider:String) {}
    fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_LONG).show()
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor=android.graphics.Color.rgb(20,71,61)
        android.net.http.HttpResponseCache.install(java.io.File(cacheDir,"http"),32L*1024*1024)
        setContent { MaterialTheme(colorScheme=lightColorScheme(primary=pine,onPrimary=Color.White,background=cream,surface=Color.White,onSurface=ink)) { App(this,latest) } }
    }
}
@Composable private fun Field(value:String,label:String,change:(String)->Unit) =
    OutlinedTextField(value,change,label={Text(label)},singleLine=true,modifier=Modifier.fillMaxWidth())
@Composable private fun Action(label:String,enabled:Boolean=true,click:()->Unit) =
    Button(onClick=click,enabled=enabled,shape=RoundedCornerShape(12.dp)) { Text(label) }
@Composable private fun Minor(label:String,click:()->Unit) =
    OutlinedButton(onClick=click,shape=RoundedCornerShape(12.dp)) { Text(label) }
@Composable private fun Tile(title:String,detail:String,click:()->Unit) {
    Surface(onClick=click,shape=RoundedCornerShape(15.dp),color=Color.White,modifier=Modifier.fillMaxWidth()) {
        Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                Text(title,color=ink,fontWeight=FontWeight.SemiBold,fontSize=18.sp)
                if(detail.isNotBlank()) Text(detail,color=Color(0xff51655e),fontSize=14.sp)
            }
            Text("›",color=pine,fontSize=24.sp)
        }
    }
}
@Composable private fun App(host:MainActivity,here:Point?) {
    val prefs=remember { host.getSharedPreferences("rit",Context.MODE_PRIVATE) }
    var page by rememberSaveable { mutableStateOf(Page.Home) }
    var from by rememberSaveable { mutableStateOf("") }
    var to by rememberSaveable { mutableStateOf("") }
    var search by rememberSaveable { mutableStateOf("") }
    var trip by remember { mutableStateOf<Trip?>(null) }
    var guiding by remember { mutableStateOf(false) }
    val guidance=remember(trip) { trip?.let(::Guidance) }
    var fix by remember(trip,guiding) { mutableStateOf<Guidance.Fix?>(null) }
    var spots by remember { mutableStateOf(emptyList<Spot>()) }
    var center by remember { mutableStateOf<Point?>(null) }
    var selected by remember { mutableStateOf<Spot?>(null) }
    var detail by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var job by remember { mutableStateOf<Job?>(null) }
    var nearbyRoute by remember { mutableStateOf(false) }
    var fuelKey by remember { mutableStateOf("") }
    var showKey by remember { mutableStateOf(false) }
    var grade by rememberSaveable { mutableIntStateOf(0) }
    val grades=listOf(43 to "E10",33 to "E5",1 to "Diesel",14 to "LPG")
    var usage by rememberSaveable { mutableStateOf(prefs.getString("usage","").orEmpty()) }
    var literPrice by rememberSaveable { mutableStateOf(prefs.getString("literPrice","").orEmpty()) }
    var plate by rememberSaveable { mutableStateOf(prefs.getString("plate","").orEmpty()) }
    var member by rememberSaveable { mutableStateOf(prefs.getString("member","").orEmpty()) }
    var favorites by remember { mutableStateOf(prefs.getStringSet("routes",emptySet()).orEmpty().toSet()) }
    var pass by remember { mutableStateOf(prefs.getString("pass","").orEmpty()) }
    var previewPass by remember { mutableStateOf(false) }
    if(previewPass && pass.isNotBlank()) PassPreview(host,Uri.parse(pass)) { previewPass=false }
    val document=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if(uri!=null) {
            try {
                host.contentResolver.takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION)
                if(pass.isNotBlank() && pass!=uri.toString()) runCatching { host.contentResolver.releasePersistableUriPermission(Uri.parse(pass),Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                pass=uri.toString(); prefs.edit().putString("pass",pass).apply()
            } catch(e:SecurityException) { host.toast("De pas kon niet worden bewaard.") }
        }
    }
    val focusManager=androidx.compose.ui.platform.LocalFocusManager.current
    val scope=rememberCoroutineScope()
    fun reset() { job?.cancel(); busy=false; spots=emptyList(); selected=null; detail=""; note=""; center=null }
    fun go(p:Page) { focusManager.clearFocus(); reset(); host.stopGps(); guiding=false; nearbyRoute=false; search=""; page=p }
    fun <T> load(task:()->T,done:(T)->Unit) {
        focusManager.clearFocus(); job?.cancel(); note=""; busy=true
        job=scope.launch {
            try { val result=runInterruptible(Dispatchers.IO) { task() }; done(result) }
            catch(e:CancellationException) { throw e }
            catch(e:Exception) { note=e.localizedMessage ?: "Ophalen mislukt. Probeer opnieuw." }
            finally { if(isActive) busy=false }
        }
    }
    fun listResults(rows:List<Spot>) { spots=rows; if(rows.isEmpty()) note="Geen resultaten voor deze zoekopdracht." }
    fun findPlaces(national:Boolean=false) {
        selected=null; spots=emptyList(); detail=""
        val query=search; val mode=page; val key=fuelKey.trim(); val chosen=grades[grade]
        load({
            val loc=RoadData.place(query)
            loc to (when { mode!=Page.Fuel -> RoadData.charges(loc.p,national); key.isBlank() -> RoadData.fuel(loc.p); else -> RoadData.fuelPrices(loc.p,key,chosen.first,chosen.second) })
        }) { (loc,rows) -> center=loc.p; listResults(rows) }
    }
    fun plan() {
        val a=from; val b=to; guiding=false; host.stopGps(); trip=null
        load({ RoadData.route(a,b) }) { trip=it }
    }
    fun closeDetail() { job?.cancel(); busy=false; selected=null; detail=""; note="" }
    BackHandler(page!=Page.Home) { if(selected!=null) closeDetail() else go(Page.Home) }
    LaunchedEffect(here,guiding,trip) {
        val t=trip
        if(guiding && here!=null && t!=null && guidance!=null) {
            val projected=guidance.locate(here,fix?.progress)
            fix=projected
            if(projected.gap<40 && projected.turn==t.steps.lastIndex && projected.remaining<18 && here.meters(t.to.p)<65) {
                guiding=false; host.stopGps(); note="Bestemming bereikt."
            }
        }
    }
    val displayed=remember(page,spots,search,nearbyRoute,trip) {
        if(page!=Page.Traffic) return@remember spots
        val corridor=if(nearbyRoute) trip?.line.orEmpty() else emptyList()
        spots.filter { s -> (s.name+" "+s.detail).contains(search,true) && (!nearbyRoute || s.p?.let { point -> along(point,corridor) }==true) }
    }
    Column(Modifier.fillMaxSize().background(cream)) {
        Surface(color=Color(0xff17483f),contentColor=Color.White) {
            Column(Modifier.fillMaxWidth().padding(horizontal=20.dp,vertical=15.dp)) {
                if(page!=Page.Home) TextButton(onClick={ if(selected!=null) closeDetail() else go(Page.Home) },contentPadding=PaddingValues(0.dp)) { Text(if(selected!=null) "‹  Terug naar overzicht" else "‹  Ritwijzer",color=Color.White) }
                Text(page.title,fontSize=32.sp,fontWeight=FontWeight.Bold)
                if(page==Page.Home) Text("Reizen in Nederland",color=Color(0xffc1d8cb))
            }
        }
        key(page,selected) {
            LazyColumn(contentPadding=PaddingValues(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                if(page==Page.Home) {
                    items(Page.entries.drop(1)) { p -> Tile(p.title,p.summary) { go(p) } }
                } else if(selected!=null) {
                    val s=selected!!
                    item { Text(s.name,style=MaterialTheme.typography.headlineSmall) }
                    item { Text(s.detail) }
                    if(s.p!=null) {
                        item { TravelMap(null,s.p,null,Modifier.fillMaxWidth().height(200.dp)); Text("Kaart © Kadaster / PDOK",fontSize=12.sp) }
                        item { Action("Route hierheen") { go(Page.Route); to=s.p.toString(); trip=null } }
                    }
                    if(page==Page.Charge) item {
                        if(s.tariffs.isEmpty()) Text("Geen tarief doorgegeven door de exploitant.")
                        else Minor("Laadtarief ophalen") { load({ RoadData.chargeTariff(s) }) { detail=it } }
                    }
                    if(page==Page.Park) item { Minor("Tarieven ophalen") { load({ RoadData.parkingDetails(s.id) }) { detail=it } } }
                    if(detail.isNotEmpty()) item { Text(detail) }
                } else when(page) {
                    Page.Route -> {
                        item { Field(from,"Vertrekadres") { from=it; reset(); trip=null; guiding=false; host.stopGps() } }
                        item { Minor("Vertrek vanaf mijn locatie") { host.gps { from=it.toString() } } }
                        item { Field(to,"Bestemming") { to=it; reset(); trip=null; guiding=false; host.stopGps() } }
                        item { Action("Bereken autoroute",!busy && from.isNotBlank() && to.isNotBlank()) { plan() } }
                        trip?.let { t ->
                            item { Text("${t.minutes} min  ·  ${distance(t.km*1000)}",style=MaterialTheme.typography.headlineMedium); Text("${t.from.title} → ${t.to.title}") }
                            val liters=usage.replace(',','.').toDoubleOrNull()
                            val euro=literPrice.replace(',','.').toDoubleOrNull()
                            if(liters!=null && liters>0 && euro!=null && euro>0) item { Text("Geschatte brandstofkosten € %.2f".format(Locale.forLanguageTag("nl-NL"),t.km*liters*euro/100)) }
                            item {
                                val current=fix
                                if(guiding && current!=null && current.turn in t.steps.indices) {
                                    if(current.gap>100) {
                                        Text("Je bent buiten de geplande route.")
                                        Minor("Herbereken vanaf mijn locatie") { here?.let { from=it.toString(); plan() } }
                                    } else Text("${t.steps[current.turn].instruction} · over ${distance(current.remaining)}",fontWeight=FontWeight.Bold)
                                }
                                Action(if(guiding) "Stop begeleiding" else "Start gps-begeleiding") {
                                    if(guiding) { guiding=false; host.stopGps() }
                                    else host.gps(true) { guiding=true }
                                }
                            }
                            item { Minor("Bewaar route") {
                                val entry=JSONArray().put(t.from.title).put(t.to.title).put(t.from.p.toString()).put(t.to.p.toString()).toString()
                                favorites=favorites+entry; prefs.edit().putStringSet("routes",favorites).apply(); host.toast("Route bewaard")
                            } }
                            item { Minor("Verkeer langs deze route") { go(Page.Traffic); nearbyRoute=true; load(RoadData::traffic) { listResults(it) } } }
                            item { TravelMap(t,if(guiding) here else null,here,Modifier.fillMaxWidth().height(245.dp)); Text("Kaart © Kadaster / PDOK · Route © OpenStreetMap-bijdragers, OSRM",fontSize=12.sp) }
                            items(t.steps) { Text("${it.instruction}   ·   ${distance(it.meters)}") }
                        }
                    }
                    Page.Traffic -> {
                        item { Minor("Flitsmeldingen bij ANWB ↗") { host.open("https://www.anwb.nl/verkeer/verkeersinformatie") } }
                        item { Field(search,"Filter op weg, plaats of melding") { search=it } }
                        item { Action("Haal verkeersmeldingen op",!busy) { load(RoadData::traffic) { listResults(it) } } }
                        if(trip!=null) item { Row { Checkbox(nearbyRoute,{nearbyRoute=it}); Text("Binnen 2 km van mijn route",Modifier.padding(top=12.dp)) } }
                    }
                    Page.Fuel,Page.Charge -> {
                        item { Field(search,"Zoek rond adres of plaats") { search=it } }
                        item { Minor("Gebruik mijn locatie") { host.gps { search=it.toString() } } }
                        trip?.let { t -> item { Minor("Zoek bij bestemming") { search=t.to.p.toString(); findPlaces() } } }
                        item { Action(if(page==Page.Fuel) "Zoek tankstations" else "Zoek laadpunten", !busy && search.isNotBlank()) { findPlaces() } }
                        if(page==Page.Fuel) item {
                            Minor(if(showKey) "Sluit prijsinstellingen" else "Pompprijzen met eigen HERE-sleutel") { showKey=!showKey }
                            if(showKey) {
                                OutlinedTextField(fuelKey,{fuelKey=it},label={Text("HERE Fuel Prices API-sleutel")},singleLine=true,visualTransformation=androidx.compose.ui.text.input.PasswordVisualTransformation())
                                Text("De sleutel blijft alleen tijdens deze sessie in het geheugen.")
                            }
                            if(fuelKey.isNotBlank()) Row { grades.forEachIndexed { i,g ->
                                TextButton(onClick={grade=i; spots=emptyList()}) { Text(if(i==grade) "✓ ${g.second}" else g.second) }
                            } }
                        }
                        if(page==Page.Fuel) item { Minor("Vergelijk pompprijzen bij ANWB ↗") { host.open("https://www.anwb.nl/verkeer/routeplanner") } }
                        if(page==Page.Charge && note.isNotBlank() && spots.isEmpty() && search.isNotBlank()) item {
                            Minor("Zoek in landelijk NDW-bestand") { findPlaces(true) }
                        }
                    }
                    Page.Park -> {
                        item { Field(search,"Plaats of straat") { search=it } }
                        item { Action("Zoek parkeerlocaties", !busy && search.trim().length>=2) { val q=search; load({ RoadData.parking(q) }) { listResults(it) } } }
                        item { Tile("Parkeeractie starten of stoppen","Via de ANWB-parkeercomputer, vanaf je geregistreerde nummer. Houd de zonecode bij de hand.") { host.open("tel:0882742536") } }
                        item { Minor("Parkeerhistorie en facturen ↗") { host.open("https://my.anwb.yellowbrick.nl/") } }
                    }
                    Page.Help -> {
                        item { Tile("Meld pech bij de Wegenwacht","Open het officiële meldformulier. Na verzending ontvang je de statuslink van ANWB per sms.") { host.open("https://www.anwb.nl/wegenwacht/service/pechmelding") } }
                        item { Minor("Toon mijn coördinaten") { host.gps { center=it } } }
                        center?.let { item { Text("Mijn locatie  $it",fontWeight=FontWeight.Bold) } }
                        item { Minor("Bel Wegenwacht in Nederland") { host.open("tel:0882692888") } }
                        item { Minor("Bel vanuit het buitenland") { host.open("tel:+31703141414") } }
                    }
                    Page.Account -> {
                        item { Minor("Open Mijn ANWB ↗") { host.open("https://www.anwb.nl/mijn-anwb") } }
                        item { Field(plate,"Kenteken") { plate=it } }
                        item { Field(member,"Lidmaatschapsnummer") { member=it } }
                        item { Field(usage,"Verbruik (liter per 100 km)") { usage=it } }
                        item { Field(literPrice,"Literprijs voor ritkosten (€)") { literPrice=it } }
                        item { Action("Bewaar op dit toestel") { prefs.edit().putString("plate",plate).putString("member",member).putString("usage",usage).putString("literPrice",literPrice).apply(); host.toast("Gegevens bewaard") } }
                        item { Text("Mijn ledenpas",style=MaterialTheme.typography.titleLarge); Text("Bewaar een eigen afbeelding of pdf om je pas offline te openen.") }
                        item { Minor("Selecteer pasbestand") { document.launch(arrayOf("image/*","application/pdf")) } }
                        if(pass.isNotEmpty()) item { Row {
                            Minor("Bekijk pas") { previewPass=true }
                            TextButton(onClick={runCatching {host.contentResolver.releasePersistableUriPermission(Uri.parse(pass),Intent.FLAG_GRANT_READ_URI_PERMISSION)}; pass=""; prefs.edit().remove("pass").apply()}) { Text("Verwijder") }
                        } }
                        item { Minor("Officiële digitale ledenpas ↗") { host.open("https://www.anwb.nl/lidmaatschap/pas/locatie") } }
                        item { Text("Bewaarde routes",style=MaterialTheme.typography.titleLarge); if(favorites.isEmpty()) Text("Bewaar een berekende route om deze hier terug te vinden.") }
                        items(favorites.sorted()) { entry ->
                            val pair=JSONArray(entry)
                            Tile(pair.getString(1),"Vanaf ${pair.getString(0)}") { go(Page.Route); from=pair.getString(2); to=pair.getString(3); plan() }
                            TextButton(onClick={ favorites=favorites-entry; prefs.edit().putStringSet("routes",favorites).apply() }) { Text("Verwijder route") }
                        }
                    }
                    Page.Home -> Unit
                }
                if(busy) item { LinearProgressIndicator(Modifier.fillMaxWidth()); Text("Gegevens ophalen…") }
                if(note.isNotBlank()) item { Text(note,color=ink) }
                if(selected==null && spots.isNotEmpty()) {
                    item { Text("${displayed.size} resultaten",fontWeight=FontWeight.SemiBold) }
                    items(displayed) { s ->
                        val d=center?.let { c -> s.p?.let { distance(c.meters(it)) } }
                        Tile(s.name,listOfNotNull(d,s.detail).filter(String::isNotBlank).joinToString(" · ")) { selected=s; detail=""; note="" }
                    }
                }
            }
        }
    }
}
private fun along(p:Point,line:List<Point>):Boolean {
    val scale=kotlin.math.cos(Math.toRadians(p.lat))*111320
    return (1 until line.size).any { i ->
        val a=line[i-1]; val b=line[i]
        if(p.lat<minOf(a.lat,b.lat)-.019 || p.lat>maxOf(a.lat,b.lat)+.019) return@any false
        val x=(a.lon-p.lon)*scale; val y=(a.lat-p.lat)*111320
        val dx=(b.lon-a.lon)*scale; val dy=(b.lat-a.lat)*111320
        val length=dx*dx+dy*dy
        val t=if(length==0.0) 0.0 else (-(x*dx+y*dy)/length).coerceIn(0.0,1.0)
        kotlin.math.hypot(x+t*dx,y+t*dy)<=2000
    }
}

