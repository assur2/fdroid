package org.weare.ritwijzer

import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import org.maplibre.android.MapLibre
import org.maplibre.android.maps.*
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.geometry.LatLngBounds
import org.maplibre.android.camera.CameraUpdateFactory
import org.maplibre.android.style.sources.GeoJsonSource
import org.maplibre.android.style.layers.*
import org.maplibre.android.style.layers.PropertyFactory.*
import org.maplibre.geojson.LineString
import org.maplibre.geojson.Point as GeoPoint

private fun Point.ll()=LatLng(lat,lon)
private fun Point.geo()=GeoPoint.fromLngLat(lon,lat)
private const val BASE = """{"version":8,"sources":{"pdok":{"type":"raster","tileSize":256,"minzoom":0,"maxzoom":19,"tiles":["https://service.pdok.nl/kadaster/brt-achtergrondkaart/wmts/v2_0/pastel/EPSG:3857/{z}/{x}/{y}.png"]}},"layers":[{"id":"paper","type":"background","paint":{"background-color":"#ebeee8"}},{"id":"basemap","type":"raster","source":"pdok"}]}"""

@Composable fun TravelMap(trip: Trip?, focus: Point?, here: Point?, modifier: Modifier) {
    val context=LocalContext.current
    val owner=LocalLifecycleOwner.current
    val view=remember { MapLibre.getInstance(context); MapView(context).apply { onCreate(null) } }
    var map by remember { mutableStateOf<MapLibreMap?>(null) }
    var style by remember { mutableStateOf<Style?>(null) }
    DisposableEffect(view,owner) {
        val observer=LifecycleEventObserver { _,e -> when(e) {
            Lifecycle.Event.ON_START -> view.onStart()
            Lifecycle.Event.ON_RESUME -> view.onResume()
            Lifecycle.Event.ON_PAUSE -> view.onPause()
            Lifecycle.Event.ON_STOP -> view.onStop()
            else -> Unit
        } }
        owner.lifecycle.addObserver(observer)
        var alive=true
        view.getMapAsync { m ->
            if(alive) {
                map=m
                m.uiSettings.isAttributionEnabled=false
                m.uiSettings.isLogoEnabled=false
                m.setStyle(Style.Builder().fromJson(BASE)) { if(alive) style=it }
            }
        }
        onDispose {
            alive=false
            owner.lifecycle.removeObserver(observer)
            if(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) view.onPause()
            if(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) view.onStop()
            view.onDestroy()
        }
    }
    AndroidView(factory={view},modifier=modifier)
    LaunchedEffect(style,trip,focus) {
        val s=style ?: return@LaunchedEffect
        for(id in listOf("route","pins","focus")) { s.removeLayer(id); s.removeSource(id) }
        if(trip!=null && trip.line.size>=2) {
            s.addSource(GeoJsonSource("route",LineString.fromLngLats(trip.line.map { it.geo() })))
            s.addLayer(LineLayer("route","route").withProperties(lineColor("#145e55"),lineWidth(5f)))
            val ends=listOf(trip.from.p,trip.to.p)
            s.addSource(GeoJsonSource("pins",org.maplibre.geojson.MultiPoint.fromLngLats(ends.map { it.geo() })))
            s.addLayer(CircleLayer("pins","pins").withProperties(circleColor("#f08d51"),circleRadius(7f),circleStrokeWidth(2f),circleStrokeColor("#ffffff")))
            if(focus==null && trip.line.first()!=trip.line.last()) {
                val bounds=LatLngBounds.Builder().includes(trip.line.map { it.ll() }).build()
                view.post { map?.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds,50)) }
            }
        }
        if(focus!=null) {
            s.addSource(GeoJsonSource("focus",focus.geo()))
            s.addLayer(CircleLayer("focus","focus").withProperties(circleColor("#ac4c22"),circleRadius(7f)))
            map?.moveCamera(CameraUpdateFactory.newLatLngZoom(focus.ll(),15.0))
        } else if(trip==null) map?.moveCamera(CameraUpdateFactory.newLatLngZoom(LatLng(52.16,5.30),6.3))
    }
    LaunchedEffect(here,style) {
        val s=style ?: return@LaunchedEffect
        if(here!=null) {
            val source=s.getSourceAs<GeoJsonSource>("gps")
            if(source!=null) source.setGeoJson(here.geo()) else {
                s.addSource(GeoJsonSource("gps",here.geo()))
                s.addLayer(CircleLayer("gps","gps").withProperties(circleColor("#2569ac"),circleRadius(6f),circleStrokeWidth(2f),circleStrokeColor("#ffffff")))
            }
        }
    }
}
