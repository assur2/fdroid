package org.weare.ritwijzer

import kotlin.math.*

/** Distances along the route keep the next turn stable between GPS updates. */
class Guidance(private val trip: Trip) {
    private val cumulative=DoubleArray(trip.line.size)
    private val turns=DoubleArray(trip.steps.size)
    init {
        for (i in 1 until trip.line.size) cumulative[i]=cumulative[i-1]+trip.line[i-1].meters(trip.line[i])
        var start=0
        trip.steps.forEachIndexed { index,step ->
            // An ordered search also distinguishes repeated junctions on a loop.
            val found=(start until trip.line.size).firstOrNull { trip.line[it].meters(step.p)<3 }
                ?: (start until trip.line.size).minByOrNull { trip.line[it].meters(step.p) } ?: start
            turns[index]=cumulative[found]
            start=found
        }
    }
    data class Fix(val progress:Double,val gap:Double,val turn:Int,val remaining:Double)
    fun locate(p:Point,previous:Double?):Fix {
        var best=Double.POSITIVE_INFINITY
        var progress=previous ?: 0.0
        var gap=Double.POSITIVE_INFINITY
        val scale=111320*cos(Math.toRadians(p.lat))
        for(i in 1 until trip.line.size) {
            val a=trip.line[i-1]; val b=trip.line[i]
            val x=(a.lon-p.lon)*scale; val y=(a.lat-p.lat)*111320
            val dx=(b.lon-a.lon)*scale; val dy=(b.lat-a.lat)*111320
            val len=dx*dx+dy*dy
            val t=if(len==0.0) 0.0 else (-(x*dx+y*dy)/len).coerceIn(0.0,1.0)
            val offset=cumulative[i-1]+t*(cumulative[i]-cumulative[i-1])
            val separation=hypot(x+t*dx,y+t*dy)
            val score=separation+if(previous==null) 0.0 else min(35.0,abs(offset-previous)*.02)
            if(score<best) { best=score;gap=separation;progress=offset }
        }
        val turn=turns.indexOfFirst { it>progress+8 }.let { if(it<0) turns.lastIndex else it }
        return Fix(progress,gap,turn,if(turn>=0) max(0.0,turns[turn]-progress) else 0.0)
    }
}
