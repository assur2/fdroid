package org.weare.ritwijzer

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable fun PassPreview(context:Context,uri:Uri,close:()->Unit) {
    var page by remember(uri) { mutableIntStateOf(0) }
    var total by remember(uri) { mutableIntStateOf(1) }
    var error by remember(uri) { mutableStateOf(false) }
    var bitmap by remember(uri,page) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(uri,page) {
        try {
            val loaded=withContext(Dispatchers.IO) {
                val resolver=context.contentResolver
                if(resolver.getType(uri)=="application/pdf") {
                    resolver.openFileDescriptor(uri,"r")!!.use { fd ->
                        PdfRenderer(fd).use { pdf ->
                            pdf.openPage(page).use { sheet ->
                                val factor=1800.0/maxOf(sheet.width,sheet.height)
                                val image=Bitmap.createBitmap(maxOf(1,(sheet.width*factor).toInt()),maxOf(1,(sheet.height*factor).toInt()),Bitmap.Config.ARGB_8888)
                                image.eraseColor(android.graphics.Color.WHITE)
                                sheet.render(image,null,null,PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                image to pdf.pageCount
                            }
                        }
                    }
                } else {
                    val options=BitmapFactory.Options().apply { inJustDecodeBounds=true }
                    resolver.openInputStream(uri)!!.use { BitmapFactory.decodeStream(it,null,options) }
                    options.inJustDecodeBounds=false
                    while(maxOf(options.outWidth,options.outHeight)/options.inSampleSize.coerceAtLeast(1)>2400) options.inSampleSize=options.inSampleSize.coerceAtLeast(1)*2
                    resolver.openInputStream(uri)!!.use { (BitmapFactory.decodeStream(it,null,options) ?: error("Afbeelding onleesbaar")) to 1 }
                }
            }
            total=loaded.second; bitmap=loaded.first
        } catch(e:kotlinx.coroutines.CancellationException) { throw e }
        catch(e:Exception) { error=true }
    }
    AlertDialog(onDismissRequest=close,title={Text("Mijn pasbestand")},text={
        Column {
            if(error) Text("Dit bestand kan niet worden gelezen. Selecteer je pas opnieuw.")
            else bitmap?.let { Image(it.asImageBitmap(), "Eigen ledenpas",Modifier.fillMaxWidth().heightIn(max=430.dp)) } ?: CircularProgressIndicator()
            if(total>1) Row {
                TextButton(enabled=page>0,onClick={page--}) { Text("Vorige") }
                Text("${page+1}/$total",Modifier.padding(top=12.dp))
                TextButton(enabled=page+1<total,onClick={page++}) { Text("Volgende") }
            }
        }
    },confirmButton={TextButton(onClick=close){Text("Sluiten")}})
}
