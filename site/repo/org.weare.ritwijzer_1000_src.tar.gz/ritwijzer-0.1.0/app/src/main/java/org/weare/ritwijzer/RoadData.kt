package org.weare.ritwijzer

import android.util.JsonReader
import android.util.JsonToken
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.InputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.zip.GZIPInputStream
import kotlin.math.*

data class Point(val lat: Double, val lon: Double) {
    fun meters(p: Point): Double {
        val north = Math.toRadians(p.lat - lat)
        val east = Math.toRadians(p.lon - lon)
        val a = sin(north/2).pow(2) + cos(Math.toRadians(lat))*cos(Math.toRadians(p.lat))*sin(east/2).pow(2)
        return 12742000 * asin(sqrt(a.coerceIn(0.0,1.0)))
    }
    override fun toString() = "%.6f, %.6f".format(Locale.US, lat, lon)
}
data class Place(val title: String, val p: Point)
data class Step(val instruction: String, val meters: Double, val p: Point)
data class Trip(val from: Place, val to: Place, val km: Double, val minutes: Int, val line: List<Point>, val steps: List<Step>)
data class Spot(val name: String, val detail: String, val p: Point? = null, val id: String = "", val tariffs: Set<String> = emptySet())

fun JSONArray.objects() = (0 until length()).mapNotNull { optJSONObject(it) }
private fun JSONArray.point() = Point(getDouble(1), getDouble(0))
fun distance(m: Double) = if (m < 1000) "${m.roundToInt()} m" else "%.1f km".format(Locale.forLanguageTag("nl-NL"),m/1000)
private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
private class HttpError(val status: Int): IOException("De databron antwoordde met HTTP $status.")
private fun <T> fetch(url: String, read: (InputStream) -> T): T {
    val c = URL(url).openConnection() as HttpURLConnection
    try {
        if(url.startsWith("https://fuel.hereapi.com/")) c.useCaches=false
        c.connectTimeout = 12000
        c.readTimeout = 45000
        c.setRequestProperty("User-Agent", "Ritwijzer/0.1 (Android; reisplanner)")
        if (c.responseCode !in 200..299) throw HttpError(c.responseCode)
        return c.inputStream.use { if (url.endsWith(".gz")) GZIPInputStream(it).use(read) else read(it) }
    } finally { c.disconnect() }
}
private fun json(url: String) = fetch(url) { JSONObject(it.bufferedReader().readText()) }
private fun value(reader: JsonReader): Any = when(reader.peek()) {
    JsonToken.BEGIN_OBJECT -> JSONObject().apply {
        reader.beginObject()
        while(reader.hasNext()) put(reader.nextName(), value(reader))
        reader.endObject()
    }
    JsonToken.BEGIN_ARRAY -> JSONArray().apply {
        reader.beginArray()
        while(reader.hasNext()) put(value(reader))
        reader.endArray()
    }
    JsonToken.NULL -> { reader.nextNull(); JSONObject.NULL }
    JsonToken.BOOLEAN -> reader.nextBoolean()
    else -> reader.nextString()
}
object RoadData {
    fun place(query: String): Place {
        val pair = query.split(',').map { it.trim().toDoubleOrNull() }
        if (pair.size == 2 && pair.all { it != null }) {
            val p = Point(pair[0]!!, pair[1]!!)
            require(p.lat in -90.0..90.0 && p.lon in -180.0..180.0) { "Ongeldige coördinaten." }
            return Place(query,p)
        }
        require(query.isNotBlank()) { "Vul een plaats of adres in." }
        val url = "https://api.pdok.nl/bzk/locatieserver/search/v3_1/free?rows=1&fq=" +
            enc("type:(adres OR woonplaats OR weg)") + "&q=" + enc(query)
        val d = json(url).getJSONObject("response").getJSONArray("docs").optJSONObject(0)
            ?: error("Geen adres gevonden voor ‘$query’.")
        val xy = d.getString("centroide_ll").substringAfter('(').substringBefore(')').trim().split(Regex("\\s+"))
        return Place(d.getString("weergavenaam"), Point(xy[1].toDouble(),xy[0].toDouble()))
    }
    fun route(start: String, end: String): Trip {
        val a = place(start)
        val b = place(end)
        val coords = "${a.p.lon},${a.p.lat};${b.p.lon},${b.p.lat}"
        val result = json("https://routing.openstreetmap.de/routed-car/route/v1/driving/$coords?overview=full&steps=true&geometries=geojson")
        val r = result.optJSONArray("routes")?.optJSONObject(0) ?: error("Geen autoroute gevonden.")
        val geo = r.getJSONObject("geometry").getJSONArray("coordinates")
        val line = (0 until geo.length()).map { geo.getJSONArray(it).point() }
        val steps = r.getJSONArray("legs").objects().flatMap { leg -> leg.getJSONArray("steps").objects().map {
            val m = it.getJSONObject("maneuver")
            val direction = mapOf("left" to "links","right" to "rechts","straight" to "rechtdoor","slight left" to "schuin links","slight right" to "schuin rechts","sharp left" to "scherp links","sharp right" to "scherp rechts","uturn" to "om").get(m.optString("modifier")).orEmpty()
            val action = when(m.optString("type")) {
                "depart" -> "Vertrek"
                "arrive" -> "Bestemming bereikt"
                "roundabout","rotary" -> if(m.has("exit")) "Neem afslag ${m.getInt("exit")} op de rotonde" else "Volg de rotonde"
                "merge" -> "Voeg in $direction"
                "off ramp" -> "Neem de afrit $direction"
                "on ramp" -> "Neem de oprit $direction"
                else -> if(direction.isEmpty()) "Volg de weg" else "Ga $direction"
            }
            Step(listOf(action.trim(),it.optString("name")).filter(String::isNotBlank).joinToString(" · "),it.getDouble("distance"),m.getJSONArray("location").point())
        } }
        return Trip(a,b,r.getDouble("distance")/1000,ceil(r.getDouble("duration")/60).toInt(),line,steps)
    }
    fun fuelPrices(p: Point, key: String, fuelCode: Int, label: String): List<Spot> {
        val url = "https://fuel.hereapi.com/v3/stations?in=circle:${p.lat},${p.lon};r=6000&fuelTypes=$fuelCode&sort=price:asc&apiKey="+enc(key)
        val response = json(url)
        val stations = response.optJSONArray("stations") ?: response.optJSONObject("stations")?.optJSONArray("station")
            ?: if (response.optInt("count",-1)==0) JSONArray() else error("Onbekend antwoord van HERE.")
        return stations.objects().mapNotNull { station ->
            val pos=station.getJSONObject("position")
            val lat=pos.optDouble("lat",pos.optDouble("latitude"))
            val lon=pos.optDouble("lng",pos.optDouble("longitude"))
            val prices=station.optJSONArray("prices") ?: station.optJSONObject("prices")?.optJSONArray("fuelPrice") ?: JSONArray()
            val price=prices.objects().firstOrNull { it.optInt("fuelType")==fuelCode && it.optDouble("price").isFinite() }
            if(!lat.isFinite() || !lon.isFinite() || price==null) return@mapNotNull null
            Spot(station.optString("name",station.optString("brand","Tankstation")),
                "$label · ${price.optString("currency")} ${price.getDouble("price")}/${price.optString("unit")}\n${price.optString("modified")}",Point(lat,lon))
        }
    }
    fun fuel(p: Point): List<Spot> {
        val q = "[out:json][timeout:20];nwr(around:6000,${p.lat},${p.lon})[amenity=fuel];out center;"
        val data = json("https://overpass-api.de/api/interpreter?data="+enc(q))
        if(data.has("remark")) error("De tankstationbron is druk. Probeer opnieuw.")
        return data.getJSONArray("elements").objects().map {
            val xy = it.optJSONObject("center") ?: it
            val t = it.getJSONObject("tags")
            Spot(t.optString("name", t.optString("brand","Tankstation")),listOf(
                listOf(t.optString("addr:street"),t.optString("addr:housenumber")).joinToString(" ").trim(),
                t.optString("opening_hours")).filter(String::isNotBlank).joinToString(" · "),Point(xy.getDouble("lat"),xy.getDouble("lon")))
        }.sortedBy { p.meters(it.p!!) }
    }
    fun charges(p: Point, national: Boolean): List<Spot> {
        val box = "%.5f,%.5f,%.5f,%.5f".format(Locale.US,p.lon-.025,p.lat-.015,p.lon+.025,p.lat+.015)
        val url = if(national) "https://opendata.ndw.nu/charging_point_locations.geojson.gz" else
            "https://dotnl.ndw.nu/api/rest/geojson/dynamic-road-status/charge-point-data/v1/features?bbox=$box"
        return fetch(url) { input ->
            val rows = mutableListOf<Spot>()
            val reader = JsonReader(input.bufferedReader())
            reader.beginObject()
            while(reader.hasNext()) {
                if(reader.nextName() != "features") { reader.skipValue(); continue }
                reader.beginArray()
                while(reader.hasNext()) {
                    if(Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException()
                    val obj = value(reader) as JSONObject
                    val xy = obj.getJSONObject("geometry").getJSONArray("coordinates").point()
                    if(abs(xy.lat-p.lat)>.015 || abs(xy.lon-p.lon)>.025) continue
                    val pr = obj.getJSONObject("properties")
                    val ports = pr.optJSONArray("availabilities")?.objects().orEmpty()
                    val info = ports.joinToString("\n") {
                        val power = it.optDouble("power_max") / 1000
                        val availability = if(it.isNull("available") || it.isNull("total")) "Beschikbaarheid onbekend" else "${it.getInt("available")} van ${it.getInt("total")} vrij"
                        availability + if(power.isFinite()) " · ${distancePower(power)} kW" else ""
                    }
                    val ids = ports.flatMap { port ->
                        val arr = port.optJSONArray("tariff_ids") ?: JSONArray()
                        (0 until arr.length()).map { arr.getString(it) }
                    }.toSet()
                    rows.add(Spot(pr.optString("address","Laadpunt"),listOf(pr.optString("operator_name"),info,pr.optString("last_updated")).filter(String::isNotBlank).joinToString("\n"),xy,pr.optString("cpo_id"),ids))
                }
                reader.endArray()
            }
            reader.endObject()
            rows.sortedBy { p.meters(it.p!!) }.take(60)
        }
    }
    private fun distancePower(kW: Double) = "%.1f".format(Locale.forLanguageTag("nl-NL"),kW)
    fun chargeTariff(s: Spot): String = fetch("https://opendata.ndw.nu/charging_point_tariffs_ocpi.json.gz") { input ->
        val reader = JsonReader(input.bufferedReader())
        val lines = mutableListOf<String>()
        reader.beginArray()
        while(reader.hasNext()) {
            if(Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException()
            val t = value(reader) as JSONObject
            if(t.optString("country_code")!="NL" || t.optString("party_id")!=s.id || t.optString("id") !in s.tariffs) continue
            for (element in t.getJSONArray("elements").objects()) {
                val restrictions = element.optJSONObject("restrictions")
                for (component in element.getJSONArray("price_components").objects()) {
                    val unit = when(component.optString("type")) { "ENERGY" -> "/kWh"; "TIME" -> "/uur"; "PARKING_TIME" -> "/parkeeruur"; "FLAT" -> " per sessie"; else -> continue }
                    lines += "${t.optString("currency")} ${component.getDouble("price")}$unit excl. btw" +
                        if(restrictions!=null && restrictions.length()>0) " (voorwaardelijk: $restrictions)" else ""
                }
            }
        }
        reader.endArray()
        lines.distinct().joinToString("\n").ifBlank { "Geen tarief gepubliceerd voor deze aansluiting." }
    }
    fun parking(query: String): List<Spot> {
        require(query.trim().length>=2) { "Vul een plaats- of straatnaam in." }
        return json("https://npropendata.rdw.nl/parkingdata/v2/").getJSONArray("ParkingFacilities").objects()
            .filter { !it.optBoolean("limitedAccess") && it.optString("name").contains(query.trim(),true) }
            .sortedByDescending { it.optLong("staticDataLastUpdated") }
            .map {
                val updated=it.optLong("staticDataLastUpdated")
                val date=if(updated>0) java.time.Instant.ofEpochSecond(updated).atZone(java.time.ZoneId.of("Europe/Amsterdam")).toLocalDate().toString() else ""
                Spot(it.getString("name"),listOf("RDW",date).filter(String::isNotBlank).joinToString(" · "),id=it.getString("identifier"))
            }
    }
    fun parkingDetails(id: String): String {
        val p = json("https://npropendata.rdw.nl/parkingdata/v2/static/"+enc(id)).getJSONObject("parkingFacilityInformation")
        val now = System.currentTimeMillis()/1000
        if(p.optLong("validityEndOfPeriod",Long.MAX_VALUE)<now) return "Deze registratie is verlopen."
        val tariffs = p.optJSONArray("tariffs")?.objects().orEmpty().filter { it.optLong("startOfPeriod",0)<=now && it.optLong("endOfPeriod",Long.MAX_VALUE)>=now }
        return tariffs.map { t ->
            val days = t.optJSONArray("validityDays")?.let { a -> (0 until a.length()).joinToString("/") { a.getString(it) } }.orEmpty()
            fun hour(k: String) = t.optJSONObject(k)?.let { "%02d:%02d".format(it.optInt("h"),it.optInt("m")) }.orEmpty()
            val intervals = t.optJSONArray("intervalRates")?.objects().orEmpty().filter {
                it.optLong("validityStartOfPeriod",0)<=now && it.optLong("validityEndOfPeriod",Long.MAX_VALUE)>=now
            }.joinToString { i ->
                val unit=when(val type=i.optString("durationType")) { "Minutes" -> "min"; "Hours" -> "uur"; "Days" -> "dagen"; else -> type }
                val end=i.optInt("durationUntil",-1)
                val range=if(end<0) "vanaf ${i.optInt("durationFrom")} $unit" else "${i.optInt("durationFrom")}–$end $unit"
                "€ ${i.optString("charge")} per ${i.optString("chargePeriod")} $unit ($range)"
            }
            listOf(t.optString("tariffDescription"),days,listOf(hour("validityFromTime"),hour("validityUntilTime")).filter(String::isNotBlank).joinToString("–"),intervals).filter(String::isNotBlank).joinToString(" · ")
        }.distinct().joinToString("\n").ifBlank { "Geen actueel tarief doorgegeven." }
    }
    fun traffic(): List<Spot> = fetch("https://opendata.ndw.nu/actueel_beeld.xml.gz") { input ->
        val parser = Xml.newPullParser()
        parser.setInput(input,null)
        val result = mutableListOf<Spot>()
        val path = mutableListOf<String>()
        var fields = mutableMapOf<String,String>()
        var kind = ""
        var active = false
        while(parser.eventType != XmlPullParser.END_DOCUMENT) {
            when(parser.eventType) {
                XmlPullParser.START_TAG -> {
                    path.add(parser.name)
                    if(parser.name=="situationRecord") {
                        active=true; fields=mutableMapOf()
                        kind=parser.getAttributeValue("http://www.w3.org/2001/XMLSchema-instance","type").orEmpty().substringAfter(':')
                    }
                }
                XmlPullParser.TEXT -> if(active && parser.text.isNotBlank()) {
                    val k = path.last()
                    if(k in setOf("latitude","longitude","roadNumber","posList","validityStatus","overallStartTime","overallEndTime")) fields.putIfAbsent(k,parser.text.trim())
                    if(k=="value" && "generalPublicComment" in path) fields.putIfAbsent("comment",parser.text.trim())
                    if(k=="value" && "roadName" in path) fields.putIfAbsent("roadName",parser.text.trim())
                    if(k=="value" && "sourceName" in path) fields.putIfAbsent("source",parser.text.trim())
                }
                XmlPullParser.END_TAG -> {
                    if(parser.name=="situationRecord") {
                        active=false
                        val now=java.time.Instant.now()
                        fun moment(key:String)=fields[key]?.let { runCatching { java.time.Instant.parse(it) }.getOrNull() }
                        if(fields["validityStatus"]!="suspended" && moment("overallStartTime")?.isAfter(now)!=true && moment("overallEndTime")?.isBefore(now)!=true) {
                            val pos=fields["posList"]?.split(' ',limit=3)
                            val lat=fields["latitude"]?.toDoubleOrNull() ?: pos?.getOrNull(0)?.toDoubleOrNull()
                            val lon=fields["longitude"]?.toDoubleOrNull() ?: pos?.getOrNull(1)?.toDoubleOrNull()
                            val title=mapOf("Accident" to "Ongeval","MaintenanceWorks" to "Werkzaamheden","AbnormalTraffic" to "Verkeersdrukte","VehicleObstruction" to "Voertuig op de weg","RoadOrCarriagewayOrLaneManagement" to "Verkeersmaatregel","ConstructionWorks" to "Wegwerkzaamheden")[kind] ?: "Verkeersmelding"
                            result.add(Spot(listOfNotNull(title,fields["roadNumber"],fields["roadName"]).joinToString(" · "),fields["comment"] ?: fields["source"].orEmpty(),if(lat!=null && lon!=null) Point(lat,lon) else null))
                        }
                    }
                    path.removeAt(path.lastIndex)
                }
            }
            parser.next()
        }
        result
    }
}
