# Ritwijzer

Nederlandstalige Android-reisplanner in Kotlin en Jetpack Compose. De app draait vanaf Android 8. Locatiebepaling gebruikt de Android-locatieprovider wanneer de gebruiker daarom vraagt. Je kunt ook een Nederlands adres of coördinaten invoeren. Gps-begeleiding werkt zolang de app op de voorgrond staat.

| Functie | Gegevens en gebruik |
| --- | --- |
| Route | PDOK zoekt het adres. OSRM berekent de autoroute op OpenStreetMap. MapLibre toont de route op de BRT-achtergrondkaart van Kadaster/PDOK. Bewaar routes lokaal of volg de afslagen met gps. |
| Verkeer | Het actuele NDW-beeld bevat meldingen met verschillende soorten hinder. Zoek op de tekst van de melding of filter op maximaal 2 km van de berekende route. De volledigheid van weg- en plaatsnamen verschilt per melding. |
| Tanken | OpenStreetMap/Overpass zoekt tankstations binnen 6 km. Voor prijsvergelijking zijn er een verwijzing naar de ANWB-routeplanner en een optionele HERE Fuel Prices-koppeling met een eigen geautoriseerde sleutel. Vul de sleutel op het tankscherm in en kies een brandstof. |
| Laden | DOT-NL levert locatie, beschikbaarheid en aansluitvermogen. Vraag het exploitantentarief per laadlocatie op. Als de regionale opvraag mislukt, kun je in het grotere landelijke bestand zoeken. Bij elke locatie staat de brontijd. |
| Parkeren | Zoek in RDW Open Parkeerdata op naam. Open een locatie voor de gepubliceerde tarieven. De parkeercomputer en het Yellowbrick-portaal regelen acties en facturen voor bestaande ANWB Parkeren-klanten. |
| Pechhulp | Open de officiële ANWB-pechmelding of kies het telefoonnummer voor Nederland of het buitenland. Je kunt je coördinaten tonen om door te geven. |
| Mijn gegevens | Bewaar kenteken, lidnummer en ritkostenvoorkeuren op het toestel. Selecteer je eigen pasafbeelding of pdf om offline te bekijken. De originele pas blijft op de gekozen locatie staan. Mijn ANWB opent in de browser. |

Zoekopdrachten en voor een opvraag benodigde coördinaten gaan naar de gekozen gegevensdienst. Ritwijzer gebruikt geen Google Maps, Google Play Services, Firebase of advertentie-SDK. Parkeerbetalingen, officiële ledengegevens en pechmeldingen worden door de betreffende dienst afgehandeld.

## Bouwen

Gebruik JDK 17, Android SDK 34 en de meegeleverde Gradle-wrapper. Stel de SDK-locatie in via Android Studio, de omgevingsvariabele ANDROID_HOME of local.properties.

    gradlew.bat :app:assembleDebug :app:lintDebug

De debug-APK komt in app/build/outputs/apk/debug. Voor een distributiebuild maakt :app:assembleRelease een APK die je met de Android SDK-tool apksigner kunt ondertekenen. Bewaar de oorspronkelijke ondertekeningssleutel voor updates.

## Bronnen

- [PDOK Locatieserver](https://www.pdok.nl/pdok-locatieserver) en [BRT Achtergrondkaart](https://www.kadaster.nl/zakelijk/producten/geo-informatie/brt-achtergrondkaart)
- [OSRM](https://project-osrm.org/docs/) en [OpenStreetMap-bijdragers](https://www.openstreetmap.org/copyright)
- [Actuele NDW-bestanden](https://opendata.ndw.nu/) en [DOT-NL gegevensafname](https://docs.ndw.nu/en/data-uitwisseling/interface-beschrijvingen/dafne-api/dafne_api_consumer_pull/)
- [RDW open parkeerdata](https://www.nationaalparkeerregister.nl/parkeer-en-verblijfsrechten/open-parkeerdata)
- [HERE Fuel Prices](https://docs.here.com/fuel-prices/docs/get-started)
- [Pech melden](https://www.anwb.nl/wegenwacht/service/pechmelding), [parkeren](https://www.anwb.nl/verkeer/anwbparkeren) en [ledenpas](https://www.anwb.nl/lidmaatschap/pas/locatie)

Licentie voor de appcode: GPL-3.0-only. Zie LICENSE.
