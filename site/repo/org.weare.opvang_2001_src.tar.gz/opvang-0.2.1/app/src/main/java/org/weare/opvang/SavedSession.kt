// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

internal class SavedSession(context: Context, name: String = "mobile-session") {
    private val prefs = context.getSharedPreferences(name, Context.MODE_PRIVATE)
    private val alias = "opvang.$name.v1"
    private fun key(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        return KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
            init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build())
        }.generateKey()
    }

    fun save(token: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val encoded = listOf(cipher.iv, cipher.doFinal(token.toByteArray(Charsets.UTF_8)))
            .joinToString(".") { Base64.encodeToString(it, Base64.NO_WRAP) }
        check(prefs.edit().putString("encrypted", encoded).commit())
    }

    fun read(): String? {
        val encoded = prefs.getString("encrypted", null) ?: return null
        val parts = encoded.split('.')
        return try {
            require(parts.size == 2)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(parts[0], Base64.NO_WRAP)))
            cipher.doFinal(Base64.decode(parts[1], Base64.NO_WRAP)).toString(Charsets.UTF_8)
        } catch (_: javax.crypto.AEADBadTagException) { clear(); null }
          catch (_: IllegalArgumentException) { clear(); null }
          catch (_: android.security.keystore.KeyPermanentlyInvalidatedException) { clear(); null }
    }

    fun clear() { check(prefs.edit().remove("encrypted").commit()) }
}
