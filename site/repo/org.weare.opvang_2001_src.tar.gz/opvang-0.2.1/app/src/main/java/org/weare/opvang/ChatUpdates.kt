// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import com.pusher.client.AuthorizationFailureException
import com.pusher.client.Pusher
import com.pusher.client.channel.PresenceChannelEventListener
import com.pusher.client.channel.PusherEvent
import com.pusher.client.channel.User
import com.pusher.client.PusherOptions
import org.json.JSONObject
import org.jsoup.Connection
import org.jsoup.Jsoup

internal fun subscribeToChat(group: String, contract: String, token: String, changed: () -> Unit): AutoCloseable {
    val channel = "presence-prod-chat-${group}_$contract"
    val options = PusherOptions().setCluster("eu").setUseTLS(true).setChannelAuthorizer { name, socket ->
        if (name != channel) throw AuthorizationFailureException("Onbekend gesprek")
        try {
            val result = Jsoup.connect("$ORIGIN/pusher/auth").followRedirects(false).ignoreContentType(true)
                .timeout(15000).method(Connection.Method.POST).header("Content-Type","application/json")
                .header("token", token).requestBody(JSONObject().put("token",token)
                    .put("channel_name",name).put("socket_id",socket).toString()).execute()
            if (result.statusCode() != 200) throw AuthorizationFailureException("Geen toegang")
            result.body()
        } catch (_: java.io.IOException) { throw AuthorizationFailureException("Chatverbinding mislukt") }
    }
    // Public Pusher application identifier. Authorization is performed by KOVnet.
    val client = Pusher("1fdea4366cd005972f89", options)
    bindChatUpdates(client, channel, changed)
    client.connect()
    return AutoCloseable { client.disconnect() }
}

internal fun bindChatUpdates(client: Pusher, channel: String, changed: () -> Unit) {
    client.subscribePresence(channel, object : PresenceChannelEventListener {
        override fun onEvent(event: PusherEvent) = changed()
        override fun onSubscriptionSucceeded(channelName: String) = Unit
        override fun onAuthenticationFailure(message: String?, e: Exception?) = Unit
        override fun onUsersInformationReceived(channelName: String, users: Set<User>) = Unit
        override fun userSubscribed(channelName: String, user: User) = Unit
        override fun userUnsubscribed(channelName: String, user: User) = Unit
    }, "new-message")
}
