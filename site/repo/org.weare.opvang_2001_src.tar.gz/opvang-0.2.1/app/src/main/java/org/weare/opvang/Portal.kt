// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import java.io.IOException
import java.net.URI
import org.json.JSONObject
import org.jsoup.Connection
import org.jsoup.Jsoup
import org.jsoup.nodes.Document
import org.jsoup.nodes.Element
import org.jsoup.nodes.TextNode

internal const val ORIGIN = "https://app.kovnet.nl"
internal data class Link(val label: String, val path: String, val browser: Boolean = false)
internal data class Page(val title: String, val entries: List<Entry>, val links: List<Link>, val conversation: Link? = null, val canSend: Boolean = true)
internal class Expired : IOException("Je sessie is verlopen. Meld je opnieuw aan.")
internal data class Downloaded(val file: java.io.File, val name: String, val mime: String)
internal data class Location(val id: String, val name: String)
internal sealed interface Login {
    data object Ready : Login
    data object Code : Login
    data class Choose(val locations: List<Location>) : Login
}

internal object Pages {
    val menu = listOf("Schriftje", "Chats", "Nieuwsbrieven", "Documenten Ouders",
        "Wijziging aanvragen", "Vakantie opgeven")

    fun path(url: String): String? {
        val uri = runCatching { URI(url) }.getOrNull() ?: return null
        if (uri.scheme != "https" || uri.rawAuthority != "app.kovnet.nl" || uri.rawPath.isNullOrBlank()) return null
        return uri.rawPath + (uri.rawQuery?.let { "?$it" } ?: "")
    }

    fun mediaUrl(url: String): String? {
        path(url)?.let { return it }
        val uri = runCatching { URI(url) }.getOrNull() ?: return null
        return url.takeIf { uri.scheme == "https" && uri.host != null && uri.userInfo == null }
    }

    fun isFile(path: String): Boolean = path.startsWith("https://kdvnet-filepicker-copy.s3.eu-central-1.amazonaws.com/") || path.startsWith("/file_storage_") ||
        path.substringBefore('?').substringAfterLast('.').lowercase() in
            setOf("pdf", "doc", "docx", "xls", "xlsx", "png", "jpg", "jpeg", "odt", "zip")

    fun links(doc: Document): List<Link> = doc.select("a[href]").mapNotNull { a ->
        val label = a.text().trim()
        val path = path(a.absUrl("href")) ?: return@mapNotNull null
        if (label.isBlank()) null else Link(label, path)
    }.distinct()

    fun content(doc: Document, fragment: Boolean = false): Element {
        val body = doc.body().clone()
        body.select("script, style, nav, header, footer, aside, form, noscript, #first_level, #menu, #footer, #header, .menu").remove()
        if (!fragment) body.select("ul").filter { list -> list.select("a").count { it.text() in menu } >= 3 }.forEach { it.remove() }
        return body.selectFirst("main, [role=main], #content, .main-content") ?: body
    }

    fun lines(doc: Document, fragment: Boolean = false) = textLines(content(doc, fragment))

    fun textLines(root: Element): List<String> {
        val lines = mutableListOf<String>()
        val buffer = StringBuilder()
        fun flush() {
            buffer.toString().trim().takeIf { it.isNotEmpty() }?.let(lines::add)
            buffer.clear()
        }
        fun walk(node: org.jsoup.nodes.Node) {
            when (node) {
                is TextNode -> buffer.append(node.text().replace(Regex("\\s+"), " "))
                is Element -> {
                    if (node.tagName() == "tr") {
                        flush()
                        val row = node.children().map { it.text() }.filter { it.isNotBlank() }
                        if (row.isNotEmpty()) lines += row.joinToString(" · ")
                        return
                    }
                    val block = node.isBlock || node.tagName() == "br"
                    if (block) flush()
                    node.childNodes().forEach(::walk)
                    if (block) flush()
                }
            }
        }
        walk(root)
        flush()
        return lines.filterNot { it in menu || it in setOf("Home", "Sitemap", "Terug", "Uitloggen") }
    }
}

internal class Portal : MobileApi() {
    private fun mediaResponse(path: String, maxBytes: Int): Connection.Response {
        var url = if (path.startsWith("/")) ORIGIN + path else path
        repeat(8) {
            val uri = URI(url)
            require(uri.scheme == "https" && uri.host != null && uri.userInfo == null)
            // Storage redirects receive a fresh, cookie-free request.
            val connection = Jsoup.connect(url)
            authorizeMedia(url, connection)
            val response = connection.followRedirects(false).timeout(20000).maxBodySize(maxBytes)
                .ignoreContentType(true).execute()
            if (response.statusCode() in listOf(301, 302, 303, 307, 308)) {
                url = uri.resolve(response.header("Location") ?: throw IOException("Fotolink ontbreekt.")).toString()
            } else {
                if (response.contentType()?.startsWith("text/html", ignoreCase = true) == true) throw IOException("Bestand niet beschikbaar.")
                return response
            }
        }
        throw IOException("Te veel doorverwijzingen.")
    }

    fun imageBytes(path: String) = mediaResponse(path, 24 * 1024 * 1024).bodyAsBytes()

    fun download(link: Link, directory: java.io.File): Downloaded {
        val response = mediaResponse(link.path, 0)
        val type = response.contentType()?.substringBefore(';') ?: "application/octet-stream"
        val suggested = android.webkit.URLUtil.guessFileName(response.url().toString(),
            response.header("Content-Disposition"), type)
        val name = if (link.label.matches(Regex(""".+\.[a-zA-Z0-9]{1,6}"""))) link.label else suggested
        val mime = if (type == "application/octet-stream") {
            android.webkit.MimeTypeMap.getSingleton().getMimeTypeFromExtension(name.substringAfterLast('.').lowercase()) ?: type
        } else type
        directory.mkdirs()
        val file = java.io.File.createTempFile("bijlage-", ".tmp", directory)
        try {
            response.bodyStream().use { input -> file.outputStream().use { output -> input.copyTo(output) } }
        } catch (e: Exception) { file.delete(); throw e }
        return Downloaded(file, name.substringAfterLast('/').substringAfterLast('\\'), mime)
    }

}
