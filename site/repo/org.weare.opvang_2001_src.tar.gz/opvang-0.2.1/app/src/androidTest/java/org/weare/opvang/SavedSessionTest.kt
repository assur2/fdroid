package org.weare.opvang

import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test

class SavedSessionTest {
    @Test fun savedTokenSurvivesReopeningAndIsRemovedOnLogout() {
        val context = InstrumentationRegistry.getInstrumentation().targetContext
        val store = SavedSession(context, "test-session")
        val marker = "fictieve-offline-sessie"
        val phase = InstrumentationRegistry.getArguments().getString("upgradePhase")
        if (phase != "restore") {
            store.save(marker)
            val ciphertext = context.getSharedPreferences("test-session", 0).getString("encrypted", null)
            assertNotNull(ciphertext)
            assertFalse(ciphertext!!.contains(marker))
        }
        assertEquals(marker, SavedSession(context, "test-session").read())
        if (phase != "prepare") {
            store.clear()
            assertNull(SavedSession(context, "test-session").read())
        }
    }
}
