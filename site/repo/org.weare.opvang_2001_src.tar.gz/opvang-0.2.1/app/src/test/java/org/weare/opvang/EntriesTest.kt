package org.weare.opvang

import org.jsoup.Jsoup
import org.junit.Assert.*
import org.junit.Test

class EntriesTest {
    @Test fun reportsKeepPhotosCommentsAndFormsWithTheirOwnPost() {
        val page = "/parents/locations/1/children/2/daily_reports"
        fun report(number: Int) = """
            <div class='dr_entries'><div class='dr_date'>Dag $number</div>
            <div class='dr_content'><p>Bericht $number</p></div>
            <div class='dr_notes'><p>Reactie $number</p><a>Verwijder</a></div>
            <form method='post' action='$page/$number/notes'><input name='authenticity_token' value='test'>
            <textarea name='content'></textarea></form>
            <div class='dr_photo_entry'><a class='dr_photo' href='#' data-photo-url='/full/$number'>
            <img src='/thumb/$number'></a><div class='fp_dl'><a href='/download/$number'>download</a></div></div></div>"""
        val entries = Entries.reports(Jsoup.parse(report(1) + report(2), ORIGIN + page))
        assertEquals(2, entries.size)
        entries.forEachIndexed { i, entry ->
            val n = i + 1
            assertEquals(listOf("Bericht $n"), entry.lines)
            assertEquals(listOf(listOf("Reactie $n")), entry.replies)
            assertEquals(listOf(Photo("/thumb/$n", "/full/$n")), entry.photos)
            assertEquals(ReplyForm("$page/$n/notes", "test", page), entry.form)
        }
    }

    @Test fun existingMultilineRepliesAndPageTokenKeepReplyAction() {
        val page = "/parents/locations/1/children/2/daily_reports"
        val doc = Jsoup.parse("""<meta name="csrf-token" content="test">
            <div class="dr_entries" id="daily_report_3"><div class="dr_notes">
            <div>Door Noor - 12-11-2026 10:00</div><p>Een<br>Twee</p>
            <div>Door Sam - 12-11-2026 11:00</div><p>Drie</p></div>
            <a class="react-link">Reageer</a></div>""", ORIGIN + page)
        val entry = Entries.reports(doc).single()
        assertEquals(listOf(listOf("Door Noor - 12-11-2026 10:00", "Een", "Twee"),
            listOf("Door Sam - 12-11-2026 11:00", "Drie")), entry.replies)
        assertEquals(ReplyForm("$page/3/notes", "test", page), entry.form)
    }

    @Test fun newestFirstPreservesMultilineMessagesEvenIfServerOrderChanges() {
        fun msg(day: String, body: String) = "<div class='chat-message'><b class='message-title'>$day 12:00 - A</b><div class='message-text'>$body</div></div>"
        val first = msg("2026-01-12", "Een")
        val second = msg("2026-10-09", "Twee<br>Regel twee")
        for (html in listOf(first + second, second + first)) {
            val result = Entries.chat(Jsoup.parse(html))
            assertEquals(listOf(listOf("Twee", "Regel twee"), listOf("Een")), result.map { it.lines })
        }
    }

    @Test fun chatPhotoStaysWithItsMessage() {
        val doc = Jsoup.parse("""<div class="chat-message"><div class="message-text">
            <a href="/file_storage_1/full"><img src="/file_storage_1/small"></a>
            <span>Uitnodiging</span></div><div class="message-title">2026-11-16 11:24 - Groep</div></div>""", ORIGIN)
        assertEquals(listOf(Photo("/file_storage_1/small", "/file_storage_1/full")), Entries.chat(doc).single().photos)
    }

    @Test fun newsletterUsesHeaderAsSchemaAndKeepsSignedAttachmentUrl() {
        val file = "https://example.org/a.pdf?signature=test"
        val doc = Jsoup.parse("""<table><tr><th>Verzonden op</th><th>Onderwerp</th><th>Tekst</th><th>Bijlage</th><th>Locatie</th></tr>
            <tr><td>16 november</td><td>herfst</td><td>Nieuws</td><td><a href="$file">Brief.pdf</a></td><td>Groep</td></tr></table>""", ORIGIN)
        val entry = Entries.newsletters(doc).single()
        assertEquals("Herfst · 16 november", entry.title)
        assertEquals(listOf("Nieuws"), entry.lines)
        assertEquals(emptyList<Pair<String, String>>(), entry.fields)
        assertEquals(listOf(Link("Brief.pdf", file)), entry.attachments)
    }

    @Test fun documentCategoriesAndAuthenticatedFilesHaveDifferentActions() {
        val path = "/parents/locations/1/documents_categories"
        val doc = Jsoup.parse("""<main><a href="$path/nil">Algemeen</a><a href="/file_storage_1/key">Reglement.pdf</a></main>""", ORIGIN)
        val page = Entries.documents(doc, Link("Documenten Ouders", path))
        assertEquals(listOf(Link("Algemeen", "$path/nil")), page.links)
        assertEquals(Link("Reglement.pdf", "/file_storage_1/key"), page.entries.single().attachments.single())
    }

    @Test fun tableRowsRemainSeparateCards() {
        val page = Jsoup.parse("<main><table><tr><td>A</td><td>B</td></tr><tr><td>C</td><td>D</td></tr></table></main>")
        assertEquals(listOf(listOf("A · B"), listOf("C · D")), Entries.general(page).map { it.lines })
    }
}
