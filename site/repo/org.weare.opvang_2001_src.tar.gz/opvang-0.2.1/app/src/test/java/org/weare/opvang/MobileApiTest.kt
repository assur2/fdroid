// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import java.io.IOException
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class MobileApiTest {
    private class Fixture {
        val calls = mutableListOf<ApiCall>()
        var modern = false
        var secondParent = false
        var denyEdit = false
        var rejected = false
        val api = MobileApi(ApiTransport { call, token ->
            calls += call
            if (call.path == "auth/get_tokens/") {
                assertEquals("", token)
                if (call.json == null) {
                    assertEquals(mapOf("email" to "ouder@example.invalid","password" to "fictief"), call.query)
                    return@ApiTransport JSONObject("""{"success":false,"code":15}""")
                }
                assertEquals("123456",call.json.getString("code"))
                val extra = if (secondParent) """,{"token":"twee","parent_user":true,"organization":{"name":"Tweede"}}""" else ""
                return@ApiTransport JSONObject("""{"success":true,"body":{"users":[{"token":"een","parent_user":true,"organization":{"name":"Eerste"}}$extra]}}""")
            }
            assertEquals(if (secondParent) "twee" else "een",token)
            val body = when (call.path) {
                "users/access_rights" -> """[{"location_id":3,"contract_ids":[8],"view_chat_message":true,"edit_chat_message":${!denyEdit},"view_newsletter":true,"view_parents_general_document":true}]"""
                "user/profile/" -> """{"locations":[{"id":3,"name":"Locatie","enable_notes_on_daily_report":true}],"contracts":[{"id":8,"location_id":3}]}"""
                "parent_requests/count_by_type" -> {
                    assertEquals("year", call.query["range"])
                    "{}"
                }
                "chats/" -> if (call.json == null) """[{"group_id":7,"contract_id":8,"group_name":"Groep","can_chat_today":true}]""" else "{}"
                "chats/messages/", "chats/older_messages/" -> {
                    assertEquals(mapOf("group_id" to "7","contract_id" to "8"),call.query)
                    if (call.path.contains("older")) """[{"id":2,"text":"Recent"},{"id":1,"text":"Ouder","date":"2026-01-01"}]"""
                    else """[{"id":2,"text":"Recent","date":"2026-01-02","photo":{"url":"https://example.invalid/image.jpg"}}]"""
                }
                "diaries/diaries_exist" -> """{"diaries_exist":$modern}"""
                "daily_reports/" -> """[{"id":9,"content":"Oud schriftje","notes_count":1,"location":{"enable_notes_on_daily_report":true}}]"""
                "daily_reports/9/notes" -> """[{"content":"Oude reactie"}]"""
                "diaries/" -> """{"diaries":[{"id":9,"location_id":3,"child_id":5}]}"""
                "diaries/9/" -> """{"content":"Nieuw schriftje","chats":[{"child_id":5,"comments":[{"text":"Nieuwe reactie"}]},{"child_id":6,"comments":[]}]}"""
                "daily_reports/9/notes/","diaries/9/add_comment/" -> "{}"
                "newsletters/" -> """[{"subject":"Nieuws","body":"<p>Lees de <a href=\"/docs/nieuws.pdf\">nieuwsbrief</a></p>","attachments":[{"name":"Menu","url":"https://example.invalid/menu.pdf"}]}]"""
                "parents_documents/" -> """{"general":[{"location":{"id":3,"name":"Locatie"},"categories":[{"category":{"name":"Beleid"},"documents":[{"description":"Schoolgids","url":"https://example.invalid/gids.pdf"}]}]}]}"""
                else -> error("Onverwachte route: ${call.path}")
            }
            JSONObject("""{"success":${!rejected},"body":$body}""")
        })

        fun signIn() {
            assertEquals(Login.Code, api.check("ouder@example.invalid","fictief",""))
            val result = api.check("ouder@example.invalid","fictief","123456")
            val selection = if (secondParent) (result as Login.Choose).locations.last().id else {
                assertEquals(Login.Ready,result)
                ""
            }
            api.login(selection)
        }
    }

    @Test fun chatUsesSelectedTokenAndCombinesHistoryOnce() {
        val f = Fixture().apply { secondParent = true; signIn() }
        val page = f.api.page(Link("Chats","chats"))
        assertEquals(listOf("Recent","Ouder"),page.entries.flatMap { it.lines })
        assertEquals(1,page.entries.first().photos.size)
        f.api.sendMessage(page.conversation!!,"Test")
        val post = f.calls.last()
        assertEquals("chats/",post.path)
        assertEquals(7,post.json!!.getInt("group_id"))
        assertEquals(8,post.json.getInt("contract_id"))
        assertEquals("Test",post.json.getString("message"))
        assertTrue(post.json.isNull("photo"))
    }

    @Test fun missingEditAccessBlocksWriteBeforeTransport() {
        val f = Fixture().apply { denyEdit = true; signIn() }
        val page = f.api.page(Link("Chats","chats"))
        assertFalse(page.canSend)
        val count = f.calls.size
        assertThrows(IOException::class.java) { f.api.sendMessage(page.conversation!!,"Test") }
        assertEquals(count,f.calls.size)
    }

    @Test fun bothDiariesUseTheirOwnReadAndWriteFormat() {
        for (modern in listOf(false,true)) {
            val f = Fixture().apply { this.modern = modern; signIn() }
            val entries = f.api.page(Link("Schriftje","diary/1")).entries
            if (modern) {
                assertEquals(2,entries.size)
                f.api.reply(entries.last().form!!,"Voor tweede kind")
                assertEquals(6,f.calls.last().json!!.getInt("child_id"))
            }
            val entry = entries.first()
            assertTrue(entry.replies.flatten().any { it.endsWith("reactie") })
            f.api.reply(entry.form!!,"Test")
            val post = f.calls.last()
            assertEquals(if (modern) "diaries/9/add_comment/" else "daily_reports/9/notes/",post.path)
            assertEquals("Test",post.json!!.getString(if (modern) "text" else "content"))
            if (modern) assertEquals(5,post.json.getInt("child_id"))
            f.rejected = true
            assertThrows(IOException::class.java) { f.api.reply(entry.form,"Test") }
        }
    }

    @Test fun openingRequestsMakesNoApiCall() {
        val f = Fixture().apply { signIn() }
        val count = f.calls.size
        val page = f.api.page(Link("Wijziging aanvragen","requests"))
        assertEquals(count,f.calls.size)
        assertEquals("requests/list",page.links.single().path)
        f.api.page(page.links.single())
        assertEquals("parent_requests/count_by_type", f.calls.last().path)
    }

    @Test fun savedTokenRestoresTheAccountWithoutSendingCredentials() {
        val f = Fixture().apply { secondParent = true }
        val home = f.api.resume("twee")
        assertEquals("Opvang", home.title)
        assertEquals(listOf("user/profile/", "users/access_rights"), f.calls.map { it.path })
    }
    @Test fun presenceSubscriptionAcceptsTheChatListenerWithoutConnecting() {
        val options = com.pusher.client.PusherOptions().setChannelAuthorizer { _, _ -> error("Offline test") }
        val client = com.pusher.client.Pusher("fixture", options)
        try { bindChatUpdates(client, "presence-test") {} } finally { client.disconnect() }
    }
    @Test fun documentsAndNewsRetainAttachments() {
        val f = Fixture().apply { signIn() }
        val doc = f.api.page(Link("Documenten","documents")).entries.single()
        assertEquals("Locatie · Beleid",doc.title)
        assertEquals("Schoolgids",doc.attachments.single().label)
        val news = f.api.page(Link("Nieuwsbrieven","news")).entries.single()
        assertEquals("Nieuws",news.title)
        assertEquals(listOf("Lees de nieuwsbrief"),news.lines)
        assertEquals(listOf(Link("nieuwsbrief","/docs/nieuws.pdf"), Link("Menu","https://example.invalid/menu.pdf")),news.attachments)
    }
}
