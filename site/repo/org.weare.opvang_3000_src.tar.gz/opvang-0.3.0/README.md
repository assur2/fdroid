# Opvang

Opvang is een onafhankelijke Nederlandstalige Android-app voor het KOVnet-ouderportaal. Chats toont recente en oudere berichten met foto's. In Schriftje kun je foto's vergroten, door de foto's van een bericht vegen en reageren. Nieuwsbrieven en Documenten bevatten bijlagen die je kunt openen of opslaan.

Opvang gebruikt de mobiele JSON-API van KOVnet op `https://app.kovnet.nl/api/v2/`. De app ondersteunt verificatiecodes en organisatiekeuze. Opvang bewaart het sessietoken versleuteld met een sleutel uit Android Keystore. Bij herstart of update hervat de app de sessie als KOVnet het token nog accepteert. Een geopend chatgesprek ontvangt berichtmeldingen via Pusher en haalt de nieuwe inhoud bij KOVnet op. Je verstuurt een bericht of reactie zelf met de verzendknop.

De mobiele aanmelding van KOVnet gebruikt bij de eerste stap een HTTPS-GET met het e-mailadres en wachtwoord in de querystring. Opvang logt de aanvraag-URL niet. Afmelden wist het opgeslagen token en de conceptberichten.

In Mijn opvang kies je een contract en een opvangdag voor een afmelding, extra opvang, gewijzigde tijden of een ruilverzoek. Wijziging aanvragen haalt het overzicht op zodra je het opent. Een aanvraag wordt verstuurd wanneer je de aanvraag bevestigt. Vakanties en Dagritme volgen de instellingen van de opvanglocatie. Bij het aanmelden kun je een herstelmail aanvragen.

In het nieuwe Schriftje kun je een bericht liken als de locatie dat toestaat. Je kunt een herkenbaar eigen commentaar bewerken of verwijderen. Het oude Schriftje ondersteunt het verwijderen van eigen reacties.

## Installeren

Voeg de [Weare Apps-feed](https://assur2.github.io/fdroid/repo/) toe aan F-Droid en zoek naar **Opvang**.

## Bouwen en testen

Gebruik JDK 17, Gradle 8.11.1 en Android SDK 35. Bouw met `gradle :app:assembleDebug`. Onder Actions → Test Opvang kun je de unit-tests en lint handmatig starten. Kies de emulatoroptie voor de aanmeldschermtest. Voor een controle met een eigen account: meld aan, open Schriftje en Chats, kies een gesprek, laad oudere berichten, ga terug en meld af.

## Release

Een tag `vMAJOR.MINOR.PATCH` bouwt en ondertekent de APK met de eigen Opvang-sleutel. De catalogus koppelt de APK en het bronarchief van dezelfde tag. Licentie: GPL-3.0-only (zie LICENSE).
