package org.weare.opvang

import android.graphics.Bitmap
import androidx.activity.compose.setContent
import androidx.compose.runtime.*
import androidx.compose.material.MaterialTheme
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import java.util.concurrent.CopyOnWriteArrayList

class EntryCardTest {
    @get:Rule val ui = createAndroidComposeRule<MainActivity>()

    @Test fun composeInlineChatMessageWithoutSending() {
        val model = PortalModel().apply { pages.add(Page("Groep", emptyList(), emptyList(), Link("Groep", "/chats/1_2"))) }
        ui.activityRule.scenario.onActivity { it.setContent { MaterialTheme { PortalScreen(model) } } }
        ui.onNodeWithText("Verzenden").assertIsNotEnabled()
        ui.onNodeWithText("Je bericht").performTextInput("Fictief bericht")
        ui.onNodeWithText("Verzenden").assertIsEnabled()
        ui.onNodeWithText("Annuleren").assertDoesNotExist()
        ui.onNodeWithText("Nieuw chatbericht").assertDoesNotExist()
    }

    @Test fun openingAndCancellingARequestDoesNotSubmitIt() {
        val writes = java.util.concurrent.atomic.AtomicInteger()
        val action = ParentAction("Afwezig melden","Testkind · maandag",null,confirm = "Aanvraag versturen") { writes.incrementAndGet() }
        val model = PortalModel().apply { pages.add(Page("Mijn opvang",listOf(Entry("Boeking",actions = listOf(action))),emptyList())) }
        ui.activityRule.scenario.onActivity { it.setContent { MaterialTheme { PortalScreen(model) } } }
        ui.onNodeWithText("Afwezig melden").performClick()
        ui.onNodeWithText("Annuleren").performClick()
        assertEquals(0,writes.get())
        ui.onNodeWithText("Afwezig melden").performClick()
        ui.onNodeWithText("Aanvraag versturen").performClick()
        ui.waitUntil { writes.get() == 1 }
    }

    @Test fun openSecondPhotoThenNavigateWithinPost() {
        val requests = CopyOnWriteArrayList<String>()
        val bitmap = Bitmap.createBitmap(4, 4, Bitmap.Config.ARGB_8888)
        val entry = Entry("Een bericht", listOf("Een fijne dag"), photos = listOf(
            Photo("/thumb-a", "/full-a"), Photo("/thumb-b", "/full-b")),
            form = ReplyForm("/report/1/notes", "fixture", "/report"))
        var submitted = ""
        ui.activityRule.scenario.onActivity { activity ->
            activity.setContent {
                MaterialTheme {
                    var draft by remember { mutableStateOf("") }
                    EntryCard(entry, { path, _ -> requests += path; bitmap }, {}) {
                        Composer("Je reactie", "Reageren", draft, true, { draft = it }, { submitted = draft })
                    }
                }
            }
        }
        ui.onNodeWithContentDescription("Foto 2").performClick()
        ui.onNodeWithText("Foto 2 van 2").assertIsDisplayed()
        ui.onNodeWithText("Volgende").assertIsNotEnabled()
        ui.onNodeWithText("Vorige").performClick()
        ui.onNodeWithText("Foto 1 van 2").assertIsDisplayed()
        ui.onNodeWithText("Vorige").assertIsNotEnabled()
        ui.onNodeWithText("Sluiten").performClick()
        ui.onNodeWithText("Reageren").assertIsNotEnabled()
        ui.onNodeWithText("Je reactie").performTextInput("Mijn reactie")
        ui.onNodeWithText("Reageren").performClick()
        ui.runOnIdle {
            assertEquals("Mijn reactie", submitted)
            assertTrue(requests.containsAll(listOf("/full-a", "/full-b")))
        }
    }
}
