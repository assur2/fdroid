// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import java.io.IOException

import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Connection
import org.jsoup.Jsoup

internal data class ApiCall(val path: String, val query: Map<String, String> = emptyMap(), val json: JSONObject? = null,
    val method: Connection.Method = if (json == null) Connection.Method.GET else Connection.Method.POST)
internal fun interface ApiTransport {
    fun execute(call: ApiCall, bearer: String): JSONObject
}

internal object KovnetTransport : ApiTransport {
    override fun execute(call: ApiCall, bearer: String): JSONObject {
        require(call.path.matches(Regex("[A-Za-z0-9_/]+")) && !call.path.startsWith('/'))
        val query = call.query.entries.joinToString("&") { (k,v) ->
            java.net.URLEncoder.encode(k,"UTF-8") + "=" + java.net.URLEncoder.encode(v,"UTF-8")
        }
        val url = "$ORIGIN/api/v2/${call.path}" + if (query.isEmpty()) "" else "?$query"
        val req = Jsoup.connect(url).method(call.method).timeout(20000)
            .followRedirects(false).ignoreHttpErrors(true).ignoreContentType(true)
            .header("Accept", "application/json").maxBodySize(12 * 1024 * 1024)
        if (bearer.isNotEmpty()) req.header("Authorization", "Bearer $bearer")

        call.json?.let { req.header("Content-Type", "application/json").requestBody(it.toString()) }
        // Transport exceptions can contain the entire login URL.
        val response = try { req.execute() } catch (_: IOException) { throw IOException("Geen verbinding met KOVnet.") }
        if (response.statusCode() == 401 && bearer.isNotEmpty()) throw Expired()
        val result = runCatching { JSONObject(response.body()) }.getOrNull()
        if (call.path == "auth/get_tokens/" && result?.optInt("code") == 15) return result
        if (response.statusCode() !in 200..299 || result == null)
            throw IOException(if (call.path == "auth/get_tokens/") "Aanmelden is niet gelukt." else "KOVnet kon dit verzoek niet afronden.")
        return result
    }
}

internal fun JSONObject.str(vararg keys: String): String = keys.firstNotNullOfOrNull {
    if (isNull(it)) null else when (val v = opt(it)) {
        is String, is Number -> v.toString().takeIf(String::isNotBlank)
        else -> null
    }
}.orEmpty()
internal fun JSONObject.id(key: String) = str(key).takeIf { it.matches(Regex("[0-9]+")) }
internal fun JSONArray.objects() = (0 until length()).map { getJSONObject(it) }
private fun Any?.rows(): List<JSONObject> = (this as? JSONArray)?.objects()
    ?: throw IOException("KOVnet gaf een onverwacht lijstformaat terug.")
internal fun JSONObject.list(k: String) = optJSONArray(k)?.objects().orEmpty()
internal fun JSONObject.child(k: String) = optJSONObject(k) ?: JSONObject()
internal fun json(vararg fields: Pair<String, Any>) = JSONObject(mapOf(*fields))
private fun textLines(value: String) = if (value.contains('<')) Pages.lines(Jsoup.parseBodyFragment(value), true)
    else value.lines().map(String::trim).filter(String::isNotEmpty)
private fun fileUrl(value: String): String? = when {
    value.startsWith('/') && !value.startsWith("//") -> Pages.mediaUrl(ORIGIN + value)
    else -> Pages.mediaUrl(value)
}
private fun photo(obj: JSONObject): Photo? {
    val versions = obj.optJSONObject("versions") ?: obj.optJSONObject("urls") ?: obj
    val full = fileUrl(obj.str("url", "original", "original_url").ifBlank { versions.str("native","large") }) ?: return null
    return Photo(fileUrl(versions.str("thumb", "small", "thumbnail","tiny")) ?: full, full)
}

internal open class MobileApi(private val transport: ApiTransport = KovnetTransport) {
    var token = ""
        private set
    private var users = emptyList<JSONObject>()
    private var rights: List<JSONObject>? = null
    internal fun allowed(key: String, location: String? = null, contract: String? = null, child: String? = null, parent: String? = null): Boolean {
        fun contains(array: JSONArray?, id: String) = array != null && (0 until array.length()).any { array.optString(it) == id }
        return rights?.any { row ->
            row.optBoolean(key) && (location == null || location == row.id("location_id")) &&
                (contract == null || contains(row.optJSONArray("contract_ids"), contract)) &&
                (child == null || contains(row.optJSONArray("child_ids"), child)) &&
                (parent == null || parent == row.id("parents_id"))
        } ?: true
    }
    internal var profile = JSONObject()
        private set
    private var chats = emptyMap<String, JSONObject>()
    private data class ReplyTarget(val path: String, val fields: JSONObject)
    private var replyFields = emptyMap<String, ReplyTarget>()
    private val locations get() = profile.list("locations")
    internal fun body(path: String, query: Map<String,String> = emptyMap(), payload: JSONObject? = null,
        method: Connection.Method = if (payload == null) Connection.Method.GET else Connection.Method.POST): Any {
        check(token.isNotBlank())
        val result = transport.execute(ApiCall(path, query, payload, method), token)
        if (!result.optBoolean("success")) throw IOException("KOVnet heeft het verzoek afgewezen.")
        return result.opt("body") ?: JSONObject.NULL
    }

    fun resetPassword(email: String) {
        val address = email.trim()
        if (!address.matches(Regex("[^@\\s]+@[^@\\s]+"))) throw IOException("Vul een geldig e-mailadres in.")
        val result = transport.execute(ApiCall("auth/reset_password", mapOf("email" to address), method = Connection.Method.POST), "")
        if (!result.optBoolean("success")) throw IOException("KOVnet kon de herstelmail niet aanvragen.")
    }

    fun check(email: String, password: String, code: String): Login {
        users = emptyList()
        val credentials = mapOf("email" to email, "password" to password)
        val call = if (code.isBlank()) ApiCall("auth/get_tokens/", credentials)
            else ApiCall("auth/get_tokens/", json = JSONObject(credentials + ("code" to code)))
        val response = transport.execute(call, "")
        if (!response.optBoolean("success")) {
            if (response.optInt("code") == 15) return Login.Code
            throw IOException("Controleer je aanmeldgegevens en verificatiecode.")
        }
        users = response.child("body").list("users").filter { it.optBoolean("parent_user") && it.str("token").isNotBlank() }
        if (users.isEmpty()) throw IOException("Geen ouderaccount gevonden.")
        return if (users.size == 1) Login.Ready else Login.Choose(users.mapIndexed { i, u ->
            Location(i.toString(), listOf(u.child("organization").str("name"), u.list("locations").joinToString(", ") { it.str("name") })
                .filter(String::isNotBlank).joinToString(" · ").ifBlank { "Organisatie ${i+1}" })
        })
    }

    fun login(selection: String): Page {
        val user = if (selection.isEmpty()) users.single() else users[selection.toInt()]
        return resume(user.getString("token"))
    }

    fun resume(savedToken: String): Page {
        token = savedToken
        profile = body("user/profile/") as? JSONObject ?: throw IOException("Ouderprofiel ontbreekt.")
        val access = body("users/access_rights")
        rights = if (access == JSONObject.NULL) null else access.rows()
        if ((profile.optJSONArray("contract_waiting_acceptance")?.length() ?: 0) > 0 || (profile.optJSONArray("contract_blocked_by_other_parent")?.length() ?: 0) > 0)
            throw IOException("Bevestig eerst je contract in het ouderportaal.")
        users = emptyList()
        return Page("Opvang", emptyList(), listOf(Link("Schriftje","diary/1"), Link("Chats","chats"),
            Link("Nieuwsbrieven","news"), Link("Documenten","documents"), Link("Wijziging aanvragen","requests"),
            Link("Mijn opvang","planning")) + listOfNotNull(
                Link("Vakanties","holidays").takeIf { profile.list("contracts").any { holidayAccess(it) } },
                Link("Dagritme","moments").takeIf { locations.any { it.optBoolean("moments_show") } }))
    }

    fun authorizeMedia(url: String, connection: Connection) {
        if (Pages.path(url) != null && token.isNotBlank()) connection.header("Authorization", "Bearer $token")
    }

    fun page(link: Link): Page = when {
        link.path == "chats" -> {
            chats = body("chats/").rows().filter { it.id("contract_id")?.let { id -> allowed("view_chat_message", contract = id) } == true }.associateBy { item ->
                val group = item.id("group_id") ?: throw IOException("Groep ontbreekt.")
                val contract = item.id("contract_id") ?: throw IOException("Contract ontbreekt.")
                "chat/$group/$contract"
            }
            val all = chats.map { (key,item) -> Link(listOf(item.str("group_name"),item.str("contract_child_name"))
                .filter(String::isNotBlank).joinToString(" · ").ifBlank { "Gesprek" }, key) }
            all.firstOrNull()?.let { conversation(it).copy(links = all.drop(1)) } ?: Page("Chats", emptyList(), emptyList())
        }
        link.path.startsWith("chat/") -> conversation(link)
        link.path.startsWith("diary/") -> diary(link)
        link.path == "news" -> {
            val rows = locations.mapNotNull { it.id("id") }.distinct().filter { allowed("view_newsletter", location = it) }.flatMap {
                body("newsletters/", mapOf("location_id" to it)).rows()
            }
            Page(link.label, rows.distinctBy { it.id("id") ?: it.toString() }.map { row ->
                val content = row.str("body","content","text","description")
                val links = newsletterLinks(row, content)
                Entry(row.str("title","subject","name"), listOf(row.str("sent_at")).filter(String::isNotBlank) + textLines(content),
                    attachments = links)
            }, emptyList())
        }
        link.path == "documents" -> {
            val docs = body("parents_documents/") as JSONObject
            val entries = buildList {
                fun categories(group: JSONObject, prefix: String) {
                    val categories = group.list("categories").ifEmpty { listOf(group) }
                    for (category in categories) {
                        val name = category.child("category").str("name").ifBlank { category.str("name","title") }
                        val attachments = files(category)
                        if (attachments.isNotEmpty()) add(Entry(listOf(prefix,name).filter(String::isNotBlank).joinToString(" · ").ifBlank { "Algemeen" },
                            attachments = attachments))
                    }
                }
                for (group in docs.list("general")) {
                    val loc = group.child("location")
                    if (allowed("view_parents_general_document", location = loc.id("id"))) categories(group, loc.str("name"))
                }
                for (group in docs.list("personal")) {
                    for (item in group.list("children")) {
                        val child = item.child("child")
                        if (allowed("view_parents_personal_document", group.child("location").id("id"), child = child.id("id")))
                            categories(item,child.str("normal_name","firstname"))
                    }
                }
                for (group in docs.list("user_contracts")) {
                    for (item in group.list("contracts")) {
                        val contract = item.child("contract")
                        if (allowed("view_contract", parent = contract.id("parents_id"))) categories(item,"Contract")
                    }
                }
            }
            Page(link.label, entries, emptyList())
        }
        link.path.substringBefore('/') in listOf("planning","holidays","moments") -> planningPage(link)
        link.path == "requests" -> {
            val entries = profile.list("contracts").flatMap { contract ->
                val id = contract.id("id") ?: throw IOException("Contract ontbreekt.")
                val data = body("parent_requests/count_by_type", mapOf("contract_id" to id, "range" to "year", "year" to java.time.Year.now().toString()))
                val lines = summary(data)
                if (lines.isEmpty()) emptyList() else listOf(Entry(contract.str("contract_child_name","name"), lines))
            }
            Page(link.label, entries, listOf(Link("Naar de planning", "planning")))
        }
        else -> throw IOException("Onbekend onderdeel.")
    }

    private fun summary(value: Any?): List<String> = when(value) {
        is JSONArray -> (0 until value.length()).flatMap { summary(value.opt(it)) }
        is JSONObject -> value.keys().asSequence().filterNot { it == "id" || it.endsWith("_id") }.flatMap { k ->
            val v = value.opt(k)
            if (v is JSONObject || v is JSONArray) summary(v).asSequence()
            else sequenceOf("${k.replace('_',' ')} · $v")
        }.toList()
        else -> emptyList()
    }

    private fun newsletterLinks(row: JSONObject, content: String): List<Link> {
        val links = mutableListOf<Link>()
        val doc = Jsoup.parseBodyFragment(content, ORIGIN + "/")
        for (anchor in doc.select("a[href]")) {
            val path = fileUrl(anchor.absUrl("href")) ?: continue
            links += Link(anchor.text().ifBlank { "Bijlage" }, path, browser = path.startsWith("https://") && !Pages.isFile(path))
        }
        fun attachment(value: Any?) {
            when (value) {
                is JSONArray -> for (i in 0 until value.length()) attachment(value.opt(i))
                is JSONObject -> {
                    val path = fileUrl(value.str("url","file_url","download_url","link","file"))
                    if (path != null) links += Link(value.str("filename","file_name","name","title").ifBlank { "Bijlage" }, path)
                    else attachment(value.opt("file"))
                }
                is String -> fileUrl(value)?.let { links += Link("Bijlage", it) }
            }
        }
        for (key in listOf("attachment","attachments","files","file")) attachment(row.opt(key))
        fileUrl(row.str("url","file_url","download_url"))?.let { links += Link("Bijlage", it) }
        return links.distinctBy { it.path }
    }

    private fun files(row: JSONObject): List<Link> {
        val nested = listOf("documents","files","attachments","categories").flatMap { row.list(it).flatMap(::files) }
        val asset = row.optJSONObject("attachment") ?: row.optJSONObject("file") ?: row
        val url = fileUrl(asset.str("url","file_url","download_url","link","file")) ?: return nested
        return nested + Link(row.str("filename","file_name","description","name","title").ifBlank { "Bijlage" }, url)
    }

    private fun conversation(link: Link): Page {
        val item = chats.getValue(link.path)
        val params = mapOf("group_id" to item.str("group_id"), "contract_id" to item.str("contract_id"))
        val recent = body("chats/messages/",params).rows()
        val older = body("chats/older_messages/",params).rows()
        val entries = (recent + older).distinctBy { it.str("id").ifBlank { it.toString() } }
            .sortedByDescending { it.str("date") }.map {
                Entry(listOf(it.str("sender_name"),it.str("date")).filter(String::isNotBlank).joinToString(" · "),
                    textLines(it.str("text")), photos = listOfNotNull(photo(it.child("photo"))))
            }
        return Page("Chats",entries,emptyList(),link, item.optBoolean("can_chat_today") && allowed("edit_chat_message", contract = item.id("contract_id")))
    }

    fun subscribe(link: Link, changed: () -> Unit): AutoCloseable? {
        val chat = chats[link.path] ?: return null
        return subscribeToChat(chat.str("group_id"), chat.str("contract_id"), token, changed)
    }

    fun sendMessage(chat: Link, message: String, attachment: (() -> JSONObject)? = null) {
        val item = chats.getValue(chat.path)
        if (!item.optBoolean("can_chat_today") || !allowed("edit_chat_message", contract = item.id("contract_id"))) throw IOException("Verzenden is niet beschikbaar.")
        body("chats/", payload = json("group_id" to item.get("group_id"),"contract_id" to item.get("contract_id"),
            "message" to message,"photo" to (attachment?.invoke() ?: JSONObject.NULL)))
    }

    private fun diary(link: Link): Page {
        val page = link.path.substringAfter('/').toInt()
        val ids = locations.mapNotNull { it.id("id") }.joinToString(",")
        val modern = (body("diaries/diaries_exist",mapOf("location_ids" to ids)) as JSONObject).getBoolean("diaries_exist")
        val params = mapOf("sort_by_date" to "DESC","page" to page.toString(),"per_page" to "10")
        val rows = if (modern) (body("diaries/", payload = json("sort_by_date" to "DESC","page" to page,"per_page" to 10)) as JSONObject)
            .getJSONArray("diaries").objects()
            else body("daily_reports/",params + ("filters" to "{}")).rows()
        val forms = mutableMapOf<String,ReplyTarget>()
        val entries = rows.flatMap { row ->
            val id = row.id("id") ?: throw IOException("Schriftje-bericht mist een nummer.")
            val detail = if (modern) body("diaries/$id/") as JSONObject else row
            val location = row.optJSONObject("location") ?: locations.find { it.id("id") == row.id("location_id") }
            val allowed = location?.optBoolean("enable_notes_on_daily_report") == true
            val legacyComments = if (!modern && row.optInt("notes_count") > 0)
                body("daily_reports/$id/notes").rows() else emptyList()
            val threads = if (modern) detail.list("chats").ifEmpty { listOf(detail) } else listOf(row)
            threads.map { thread ->
                val child = thread.id("child_id") ?: thread.child("child").id("id")
                val action = if (modern) "diaries/$id/add_comment/" else "daily_reports/$id/notes/"
                val draftKey = if (modern) "$action#$child" else action
                val form = if (allowed && (!modern || child != null)) {
                    val fields = if (modern) json("diary_id" to id.toLong(),"child_id" to child!!.toLong()) else json("subject" to "")
                    forms[draftKey] = ReplyTarget(action,fields)
                    ReplyForm(draftKey,"",link.path)
                } else null
                val comments = if (modern) thread.list("comments") else legacyComments
                Entry(listOf(thread.child("child").str("normal_name","firstname"),row.child("user").str("fullname"),row.str("published_at","created_at"))
                    .filter(String::isNotBlank).joinToString(" · "), textLines(detail.str("content","text")),
                    comments.map { c -> listOf(c.child("user").str("fullname").ifBlank { c.str("user_name","name","sender_name") }, c.str("created_at"))
                        .filter(String::isNotBlank) + textLines(c.str("content","text")) }, detail.list("photos").mapNotNull(::photo), form,
                    actions = if (modern && location?.optBoolean("diary_likes_available") == true) {
                        val liked = detail.optBoolean("liked",row.optBoolean("liked"))
                        listOf(ParentAction(if (liked) "Like intrekken" else "Vind ik leuk", "Schriftje · " + row.str("published_at","created_at"), link) {
                            val operation = if (liked) "remove_parents_like" else "set_parents_like"
                            body("diaries/$id/$operation/", payload = json("diary_id" to id.toLong()),
                                method = if (liked) Connection.Method.DELETE else Connection.Method.POST)
                        })
                    } else emptyList(), replyActions = if (allowed) commentActions(comments,modern,id,link) else emptyMap())
            }
        }
        replyFields = replyFields + forms
        val next = if (rows.size == 10) listOf(Link("Oudere berichten","diary/${page+1}")) else emptyList()
        return Page("Schriftje",entries,next)
    }

    private fun commentActions(comments: List<JSONObject>, modern: Boolean, diary: String, link: Link): Map<Int,List<ParentAction>> {
        val user = profile.child("user")
        val ownId = user.id("user_id") ?: user.id("id") ?: profile.id("user_id") ?: return emptyMap()
        return buildMap {
            comments.forEachIndexed { index, c ->
                val author = c.id("user_id") ?: c.child("user").id("id")
                val id = c.id("id")
                if (id == null || author != ownId || c.optBoolean("to_parent")) return@forEachIndexed
                val current = c.str("text","content")
                val fields = json("diary_id" to diary.toLong(),"comment_id" to id.toLong())
                put(index,buildList {
                    if (modern) add(ParentAction("Reactie bewerken", "Je eigen reactie",link,listOf(Input("Reactie",current)),"Opslaan") {
                        body("diaries/$diary/edit_comment/$id/",payload = JSONObject(fields.toString()).put("text",it.getValue("Reactie").trim()))
                    })
                    add(ParentAction("Reactie verwijderen",current,link,confirm = "Verwijderen") {
                        if (modern) body("diaries/$diary/remove_comment/$id/",payload = fields,method = Connection.Method.DELETE)
                        else body("daily_reports/$diary/notes/$id", method = Connection.Method.DELETE)
                    })
                })
            }
        }
    }

    fun reply(form: ReplyForm, text: String) {
        val target = replyFields[form.action] ?: throw IOException("Reageren is niet beschikbaar.")
        val payload = JSONObject(target.fields.toString()).put(if (target.fields.has("diary_id")) "text" else "content",text)
        body(target.path,payload = payload)
    }
}
