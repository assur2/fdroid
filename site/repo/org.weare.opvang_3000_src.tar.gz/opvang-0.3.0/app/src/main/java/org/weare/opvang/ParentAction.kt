// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.LocalTime

internal enum class InputKind { Text, Date, Time, Choice }
internal data class Input(val label: String, val initial: String = "", val kind: InputKind = InputKind.Text,
    val choices: Map<String,String> = emptyMap(), val required: Boolean = true)
internal data class ParentAction(val label: String, val subject: String, val refresh: Link?, val inputs: List<Input> = emptyList(),
    val confirm: String = "Bevestigen", val send: (Map<String,String>) -> Unit)

@Composable
internal fun ActionDialog(action: ParentAction, busy: Boolean, error: String, close: () -> Unit, send: (Map<String,String>) -> Unit) {
    val context = LocalContext.current
    val values = remember(action) { mutableStateMapOf(*action.inputs.map { it.label to it.initial }.toTypedArray()) }
    AlertDialog(onDismissRequest = { if (!busy) close() }, title = { Text(action.label) }, text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(action.subject)
            for (field in action.inputs) {
                val value = values[field.label].orEmpty()
                when (field.kind) {
                    InputKind.Text -> OutlinedTextField(value,{ values[field.label] = it }, enabled = !busy, label = { Text(field.label) })
                    InputKind.Date -> OutlinedButton({
                        val d = runCatching { LocalDate.parse(value) }.getOrDefault(LocalDate.now())
                        DatePickerDialog(context,{ _,y,m,day -> values[field.label] = LocalDate.of(y,m+1,day).toString() },
                            d.year,d.monthValue-1,d.dayOfMonth).show()
                    }, enabled = !busy) { Text(field.label + " · " + value.ifBlank { "Kies datum" }) }
                    InputKind.Time -> OutlinedButton({
                        val t = runCatching { LocalTime.parse(value) }.getOrDefault(LocalTime.of(9,0))
                        TimePickerDialog(context,{ _,h,m -> values[field.label] = LocalTime.of(h,m).toString() },t.hour,t.minute,true).show()
                    }, enabled = !busy) { Text(field.label + " · " + value.ifBlank { "Kies tijd" }) }
                    InputKind.Choice -> Box {
                        var expanded by remember { mutableStateOf(false) }
                        OutlinedButton({ expanded = true }, enabled = !busy) { Text(field.label + " · " + (field.choices[value] ?: "Kies")) }
                        DropdownMenu(expanded,{ expanded = false }) {
                            field.choices.forEach { (id,name) -> DropdownMenuItem({ values[field.label] = id; expanded = false }) { Text(name) } }
                        }
                    }
                }
            }
            if (error.isNotBlank()) Text(error,color = MaterialTheme.colors.error)
        }
    }, confirmButton = { Button({ send(values.toMap()) },enabled = !busy && action.inputs.all { !it.required || !values[it.label].isNullOrBlank() }) { Text(action.confirm) } },
        dismissButton = { TextButton(close, enabled = !busy) { Text("Annuleren") } })
}
