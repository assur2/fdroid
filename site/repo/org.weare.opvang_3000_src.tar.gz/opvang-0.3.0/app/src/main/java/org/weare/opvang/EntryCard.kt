// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.io.IOException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

internal class PhotoLoader(private val portal: Portal) {
    private val concurrent = Semaphore(3)
    private val cache = object : LruCache<String, Bitmap>(20 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.allocationByteCount
    }

    suspend fun load(path: String, size: Int): Bitmap = withContext(Dispatchers.IO) {
        val key = "$size:$path"
        concurrent.withPermit {
            cache.get(key)?.let { return@withPermit it }
            val bytes = portal.imageBytes(path)
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
            val longest = maxOf(options.outWidth, options.outHeight)
            var sample = 1
            while (longest / sample > size * 3 / 2) sample *= 2
            options.inSampleSize = sample
            options.inJustDecodeBounds = false
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
                ?: throw IOException("Foto niet leesbaar.")
            cache.put(key, bitmap)
            bitmap
        }
    }
}

@Composable
internal fun EntryCard(entry: Entry, loader: suspend (String, Int) -> Bitmap, onAttachment: (Link) -> Unit,
    onAction: (ParentAction) -> Unit = {}, composer: @Composable () -> Unit) {
    var selected by rememberSaveable { mutableIntStateOf(-1) }
    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, Color(0xFFBCCFC9)), elevation = 0.dp) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (entry.title.isNotBlank()) Text(entry.title, style = MaterialTheme.typography.subtitle2,
                color = MaterialTheme.colors.primary)
            entry.fields.forEach { (label, value) ->
                Text("$label · $value", style = MaterialTheme.typography.body2)
            }
            entry.lines.forEach { Text(it) }
            if (entry.attachments.isNotEmpty()) {
                if (entry.lines.isNotEmpty()) Text("Bijlage", style = MaterialTheme.typography.caption)
                entry.attachments.forEach { file ->
                    TextButton(onClick = { onAttachment(file) }) { Text(file.label) }
                }
            }
            if (entry.replies.isNotEmpty()) {
                Divider()
                entry.replies.forEachIndexed { index, reply ->
                    Column(Modifier.padding(start = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        reply.forEach { Text(it, style = MaterialTheme.typography.body2) }
                        entry.replyActions[index].orEmpty().forEach { action ->
                            TextButton({ onAction(action) }) { Text(action.label) }
                        }
                    }
                    Divider(color = Color(0xFFCCDAD6))
                }
            }
            entry.photos.chunked(3).forEachIndexed { row, photos ->
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    photos.forEachIndexed { column, photo ->
                        val index = row * 3 + column
                        Box(Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(6.dp))
                            .background(Color(0xFFE8F1EE)).clickable(onClickLabel = "Vergroot foto") { selected = index }) {
                            PortalPhoto(photo.thumbnail, loader, false, "Foto ${index + 1}")
                        }
                    }
                    repeat(3 - photos.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            entry.actions.forEach { action -> OutlinedButton({ onAction(action) }) { Text(action.label) } }
            composer()
        }
    }
    if (selected in entry.photos.indices) {
        PhotoGallery(entry.photos, selected, loader) { selected = -1 }
    }
}

@Composable
internal fun Composer(label: String, action: String, draft: String, enabled: Boolean,
    onChange: (String) -> Unit, onSend: () -> Unit, hasAttachment: Boolean = false) {
    OutlinedTextField(draft, onChange, Modifier.fillMaxWidth(), enabled = enabled,
        label = { Text(label) }, maxLines = 5)
    Button(onSend, enabled = enabled && (draft.isNotBlank() || hasAttachment)) { Text(action) }
}

@Composable
private fun PortalPhoto(path: String, loader: suspend (String, Int) -> Bitmap, large: Boolean, description: String) {
    var attempt by remember(path) { mutableIntStateOf(0) }
    var failed by remember(path, attempt) { mutableStateOf(false) }
    val bitmap by produceState<Bitmap?>(null, path, loader, attempt) {
        value = null
        try { value = loader(path, if (large) 2048 else 320) }
        catch (e: CancellationException) { throw e }
        catch (_: Exception) { failed = true }
    }
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        val image = bitmap
        when {
            image != null -> Image(image.asImageBitmap(), description, Modifier.fillMaxSize(),
                contentScale = if (large) ContentScale.Fit else ContentScale.Crop)
            failed -> TextButton(onClick = { attempt++ }) {
                Text("Opnieuw laden", color = if (large) Color.White else MaterialTheme.colors.primary)
            }
            else -> CircularProgressIndicator(Modifier.size(24.dp))
        }
    }
}

@Composable
private fun PhotoGallery(photos: List<Photo>, initial: Int, loader: suspend (String, Int) -> Bitmap, close: () -> Unit) {
    val pager = rememberPagerState(initialPage = initial) { photos.size }
    val scope = rememberCoroutineScope()
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(Color(0xFF14201D)).systemBarsPadding()) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("Foto ${pager.currentPage + 1} van ${photos.size}", color = Color.White)
                TextButton(close) { Text("Sluiten", color = Color.White) }
            }
            HorizontalPager(pager, Modifier.weight(1f)) { index ->
                PortalPhoto(photos[index].original, loader, true, "Foto ${index + 1}")
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                for ((label, delta) in listOf("Vorige" to -1, "Volgende" to 1)) {
                    val target = pager.currentPage + delta
                    val enabled = target in photos.indices
                    TextButton({ scope.launch { pager.animateScrollToPage(target) } }, enabled = enabled) {
                        Text(label, color = Color.White.copy(alpha = if (enabled) 1f else .38f))
                    }
                }
            }
        }
    }
}
