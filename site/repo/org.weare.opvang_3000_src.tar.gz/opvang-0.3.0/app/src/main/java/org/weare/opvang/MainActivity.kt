// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import android.content.ActivityNotFoundException
import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.FileProvider
import java.io.File
import java.io.IOException
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.*
import androidx.compose.ui.unit.dp
import androidx.lifecycle.findViewTreeLifecycleOwner
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private val model: PortalModel by viewModels()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        model.attach(SavedSession(applicationContext))
        setContent {
            MaterialTheme(colors = lightColors(primary = Color(0xFF145E51), secondary = Color(0xFF176658))) {
                PortalScreen(model)
            }
        }
    }
}

internal class PortalModel : ViewModel() {
    private var storage: SavedSession? = null
    var resumeAvailable by mutableStateOf(false)
        private set

    fun attach(store: SavedSession) {
        if (storage != null) return
        storage = store
        resumeSession()
    }

    fun resumeSession() = run {
        val saved = withContext(Dispatchers.IO) { storage?.read() } ?: return@run
        resumeAvailable = true
        val home = withContext(Dispatchers.IO) { portal.resume(saved) }
        pages.add(home)
        resumeAvailable = false
    }

    private var portal = Portal()
    var photos = PhotoLoader(portal)
        private set
    val drafts = mutableStateMapOf<String, String>()
    var download by mutableStateOf<Downloaded?>(null)
    val pages = mutableStateListOf<Page>()
    var email by mutableStateOf("")
    var password by mutableStateOf("")
    var code by mutableStateOf("")
    var needsCode by mutableStateOf(false)
    var locations by mutableStateOf(emptyList<Location>())
    var error by mutableStateOf("")
    var busy by mutableStateOf(false)

    private fun run(block: suspend () -> Unit) {
        if (busy) return
        busy = true
        error = ""
        viewModelScope.launch {
            try { block() }
            catch (e: CancellationException) { throw e }
            catch (e: Expired) { logout(); error = e.message.orEmpty() }
            catch (e: Exception) {
                error = when {
                    e is java.io.IOException && e.javaClass == java.io.IOException::class.java -> e.message.orEmpty()
                    else -> "KOVnet kon het verzoek niet afronden. Controleer je verbinding en probeer opnieuw."
                }
            }
            finally { busy = false }
        }
    }

    fun submit(location: String? = null) = run {
        val result = if (location != null) Login.Ready else withContext(Dispatchers.IO) {
            portal.check(email.trim(), password, code)
        }
        when (result) {
            Login.Code -> needsCode = true
            is Login.Choose -> locations = result.locations
            Login.Ready -> {
                val home = withContext(Dispatchers.IO) { portal.login(location.orEmpty()).also { storage?.save(portal.token) } }
                pages.add(home)
                password = ""; code = ""; locations = emptyList(); needsCode = false
            }
        }
    }

    var action by mutableStateOf<ParentAction?>(null)
    var notice by mutableStateOf("")
    fun startAction(next: ParentAction) {
        if (busy) return
        error = ""
        notice = ""
        action = next
    }
    fun forgotPassword() = startAction(ParentAction("Vergeten wachtwoord herstellen",
        "KOVnet stuurt de herstellink naar je e-mailadres.", null, listOf(Input("E-mailadres", email)), "Herstelmail aanvragen") {
        portal.resetPassword(it.getValue("E-mailadres"))
    })
    fun confirmAction(values: Map<String,String>) = run {
        val pending = action ?: return@run
        withContext(Dispatchers.IO) { pending.send(values) }
        action = null
        notice = if (pending.refresh == null) "Herstelverzoek verstuurd." else "Wijziging doorgegeven."
        pending.refresh?.let { link -> pages[pages.lastIndex] = withContext(Dispatchers.IO) { portal.page(link) } }
    }
    fun open(link: Link) = run { notice = ""; pages.add(withContext(Dispatchers.IO) { portal.page(link) }) }
    fun changeChat(link: Link) = run {
        val current = pages.last()
        val alternatives = (listOfNotNull(current.conversation) + current.links).filter { it.path != link.path }
        val selected = withContext(Dispatchers.IO) { portal.page(link) }
        pages[pages.lastIndex] = selected.copy(links = alternatives)
    }

    fun subscribe(link: Link) = portal.subscribe(link) {
        viewModelScope.launch {
            if (pages.lastOrNull()?.conversation == link && !busy) {
                val current = pages.last()
                run {
                    val updated = withContext(Dispatchers.IO) { portal.page(link) }
                    pages[pages.lastIndex] = updated.copy(links = current.links)
                }
            }
        }
    }

    val chatPhotos = mutableStateMapOf<String,android.net.Uri>()
    fun sendChat(link: Link, resolver: android.content.ContentResolver) {
        val text = drafts[link.path].orEmpty().trim()
        val uri = chatPhotos[link.path]
        if (text.isBlank() && uri == null) return
        run {
            try { withContext(Dispatchers.IO) { portal.sendMessage(link, text, uri?.let { { uploadChatPhoto(resolver,it) } }) } }
            catch (e: Expired) { throw e }
            catch (e: IOException) {
                error = "Verzending niet bevestigd. Controleer het gesprek voordat je opnieuw verzendt."
                return@run
            }
            drafts.remove(link.path)
            chatPhotos.remove(link.path)
            try { pages[pages.lastIndex] = withContext(Dispatchers.IO) { portal.page(link) }.copy(links = pages.last().links) }
            catch (e: Expired) { throw e }
            catch (e: IOException) { error = "Bericht ingestuurd. Open het gesprek opnieuw om het te verversen." }
        }
    }

    fun attachment(link: Link, directory: File) = run {
        download = withContext(Dispatchers.IO) {
            directory.listFiles()?.filter { it.lastModified() < System.currentTimeMillis() - 86400000L }
                ?.forEach { it.delete() }
            portal.download(link, directory)
        }
    }

    fun sendReply(form: ReplyForm) {
        val text = drafts[form.action].orEmpty().trim()
        if (text.isEmpty()) return
        run {
            try {
                withContext(Dispatchers.IO) { portal.reply(form, text) }
            } catch (e: Expired) { throw e }
            catch (e: IOException) {
                error = "Verzending niet bevestigd. Controleer het Schriftje voordat je opnieuw verzendt."
                return@run
            }
            drafts.remove(form.action)
            val updated = try {
                withContext(Dispatchers.IO) { portal.page(Link("Schriftje", form.page)) }
            } catch (e: Expired) { throw e }
            catch (e: IOException) {
                error = "Reactie ingestuurd. Open het Schriftje opnieuw om de reacties te laden."
                return@run
            }
            pages[pages.lastIndex] = updated
            if (updated.entries.none { it.form?.action == form.action &&
                    it.replies.flatten().joinToString(" ").contains(text.replace(Regex("""\s+"""), " ")) }) {
                error = "KOVnet heeft de reactie nog niet in het Schriftje getoond."
            }
        }
    }

    fun saveFile(resolver: android.content.ContentResolver, uri: android.net.Uri, asset: Downloaded) = run {
        withContext(Dispatchers.IO) {
            val stream = resolver.openOutputStream(uri) ?: throw IOException("Opslaan mislukt.")
            stream.use { output -> asset.file.inputStream().use { it.copyTo(output) } }
        }
        download = null
    }

    fun back() { if (!busy && pages.size > 1) { pages.removeAt(pages.lastIndex); error = "" } }
    fun logout() {
        storage?.clear(); resumeAvailable = false; download = null; portal = Portal(); photos = PhotoLoader(portal); drafts.clear(); pages.clear(); email = ""; password = ""; code = ""
        needsCode = false; locations = emptyList(); error = ""; notice = ""; action = null; chatPhotos.clear()
    }
}

@Composable
internal fun PortalScreen(model: PortalModel) {
    val page = model.pages.lastOrNull()
    val activity = checkNotNull(androidx.compose.ui.platform.LocalView.current.findViewTreeLifecycleOwner())
    DisposableEffect(activity, page?.conversation) {
        var subscription: AutoCloseable? = null
        val observer = androidx.lifecycle.LifecycleEventObserver { _, event ->
            when (event) {
                androidx.lifecycle.Lifecycle.Event.ON_START -> subscription = page?.conversation?.let(model::subscribe)
                androidx.lifecycle.Lifecycle.Event.ON_STOP -> { subscription?.close(); subscription = null }
                else -> Unit
            }
        }
        activity.lifecycle.addObserver(observer)
        onDispose { activity.lifecycle.removeObserver(observer); subscription?.close() }
    }
    BackHandler(enabled = model.pages.size > 1 || model.busy) { model.back() }
    Surface(modifier = Modifier.fillMaxSize()) {
        val context = LocalContext.current
        val save = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uri = result.data?.data
            val asset = model.download
            if (uri != null && asset != null && result.resultCode == android.app.Activity.RESULT_OK) {
                model.saveFile(context.contentResolver, uri, asset)
            }
        }
        model.action?.let { action ->
            ActionDialog(action, model.busy, model.error, { model.action = null; model.error = "" }, model::confirmAction)
        }
        model.download?.let { asset ->
            AlertDialog(onDismissRequest = { model.download = null }, title = { Text(asset.name) },
                text = { TextButton(onClick = {
                    save.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                        .setType(asset.mime).putExtra(Intent.EXTRA_TITLE, asset.name))
                }) { Text("Kopie opslaan") } },
                confirmButton = { TextButton(onClick = {
                    val uri = FileProvider.getUriForFile(context, context.packageName + ".files", asset.file, asset.name)
                    try {
                        context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, asset.mime)
                            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                        model.download = null
                    } catch (_: ActivityNotFoundException) {
                        save.launch(Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE)
                            .setType(asset.mime).putExtra(Intent.EXTRA_TITLE, asset.name))
                    }
                }) { Text("Openen") } }, dismissButton = {
                    TextButton(onClick = { model.download = null }) { Text("Sluiten") }
                })
        }
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            TopAppBar(title = { Text("Opvang") }, actions = {
                if (model.pages.size > 1) TextButton(onClick = model::back, enabled = !model.busy) { Text("Terug", color = Color.White) }
                if (page != null) TextButton(onClick = model::logout, enabled = !model.busy) { Text("Afmelden", color = Color.White) }
            })
            if (model.busy) LinearProgressIndicator(Modifier.fillMaxWidth())
            if (model.notice.isNotEmpty()) Text(model.notice, Modifier.padding(16.dp))
            if (model.error.isNotEmpty() && model.action == null) Text(model.error, Modifier.padding(16.dp), color = MaterialTheme.colors.error)
            key(model.pages.size, page?.title) {
                LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (page == null) {
                        item { Text("Aanmelden bij KOVnet", style = MaterialTheme.typography.h5) }
                        if (model.resumeAvailable) {
                            item { Button(model::resumeSession, enabled = !model.busy) { Text("Sessie hervatten") } }
                            item { TextButton(model::logout, enabled = !model.busy) { Text("Afmelden") } }
                        } else if (model.locations.isEmpty()) {
                            item { OutlinedTextField(model.email, { model.email = it }, Modifier.fillMaxWidth(),
                                enabled = !model.busy, label = { Text("E-mailadres") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email)) }
                            item { OutlinedTextField(model.password, { model.password = it }, Modifier.fillMaxWidth(),
                                enabled = !model.busy, label = { Text("Wachtwoord") }, singleLine = true,
                                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)) }
                            item { TextButton(model::forgotPassword, enabled = !model.busy) { Text("Vergeten wachtwoord herstellen") } }
                            if (model.needsCode) item { OutlinedTextField(model.code, { model.code = it }, Modifier.fillMaxWidth(),
                                enabled = !model.busy, label = { Text("Verificatiecode") }, singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword)) }
                            item { Button(onClick = { model.submit() }, enabled = !model.busy && model.email.isNotBlank() &&
                                model.password.isNotBlank() && (!model.needsCode || model.code.isNotBlank())) { Text("Aanmelden") } }
                        } else {
                            item { Text("Kies je locatie") }
                            items(model.locations) { loc ->
                                OutlinedButton({ model.submit(loc.id) }, enabled = !model.busy) { Text(loc.name) }
                            }
                            item { TextButton(model::logout, enabled = !model.busy) { Text("Opnieuw aanmelden") } }
                        }
                    } else {
                        item { Text(if (page.title == "Opvang") "Ouderportaal" else page.title, style = MaterialTheme.typography.h5) }
                        if (page.entries.isEmpty() && page.links.isEmpty()) item { Text("Geen gegevens gevonden.") }
                        page.conversation?.let { link ->
                            item {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    if (page.links.isEmpty()) Text(link.label, style = MaterialTheme.typography.subtitle2)
                                    else Box {
                                        var expanded by remember { mutableStateOf(false) }
                                        OutlinedButton({ expanded = true }, enabled = !model.busy) { Text(link.label + " ▾") }
                                        DropdownMenu(expanded, { expanded = false }) {
                                            page.links.forEach { other ->
                                                DropdownMenuItem({ expanded = false; model.changeChat(other) }) { Text(other.label) }
                                            }
                                        }
                                    }
                                    if (page.canSend) key(link.path) {
                                        val selected = model.chatPhotos[link.path]
                                        val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
                                            if (uri != null) model.chatPhotos[link.path] = uri
                                        }
                                        if (selected == null && BuildConfig.CHAT_PHOTO_UPLOAD_ID.isNotEmpty()) OutlinedButton({ picker.launch("image/*") }, enabled = !model.busy) { Text("Foto toevoegen") }
                                        else if (selected != null) TextButton({ model.chatPhotos.remove(link.path) }, enabled = !model.busy) { Text("Geselecteerde foto verwijderen") }
                                        Composer("Je bericht", "Verzenden", model.drafts[link.path].orEmpty(),
                                            !model.busy, { model.drafts[link.path] = it }, { model.sendChat(link,context.contentResolver) },selected != null)
                                    }
                                }
                            }
                        }
                        items(page.entries) { entry ->
                            EntryCard(entry, model.photos::load, { attachment ->
                                if (attachment.browser) {
                                    try { context.startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse(attachment.path))) }
                                    catch (_: ActivityNotFoundException) { model.error = "Er is geen browser beschikbaar om deze link te openen." }
                                } else model.attachment(attachment, File(context.cacheDir, "bijlagen"))
                            }, model::startAction) {
                                entry.form?.let { form ->
                                    Composer("Je reactie", "Reageren", model.drafts[form.action].orEmpty(),
                                        !model.busy, { model.drafts[form.action] = it }, { model.sendReply(form) })
                                }
                            }
                        }
                        if (page.conversation == null) items(page.links) { link ->
                            OutlinedButton({ model.open(link) }, Modifier.fillMaxWidth(), enabled = !model.busy,
                                contentPadding = PaddingValues(14.dp)) { Text(link.label) }
                        }
                    }
                }
            }
        }
    }
}
