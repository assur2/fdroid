// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import android.content.ContentResolver
import android.net.Uri
import android.provider.OpenableColumns
import java.io.FilterOutputStream
import java.io.IOException
import java.net.URL
import java.util.Base64
import java.util.UUID
import javax.net.ssl.HttpsURLConnection
import org.json.JSONObject

internal fun uploadChatPhoto(resolver: ContentResolver, uri: Uri): JSONObject {
    val mime = resolver.getType(uri)?.takeIf { it.startsWith("image/") } ?: throw IOException("Kies een afbeelding.")
    val name = resolver.query(uri,arrayOf(OpenableColumns.DISPLAY_NAME),null,null,null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    } ?: "foto"
    val url = Uri.parse("https://www.filestackapi.com/api/store/S3").buildUpon()
        .appendQueryParameter("key",BuildConfig.CHAT_PHOTO_UPLOAD_ID).appendQueryParameter("mimetype",mime)
        .appendQueryParameter("filename",name).appendQueryParameter("base64decode","true").build()
    val boundary = UUID.randomUUID().toString()
    val connection = URL(url.toString()).openConnection() as HttpsURLConnection
    try {
        connection.requestMethod = "POST"
        connection.instanceFollowRedirects = false
        connection.connectTimeout = 20000
        connection.readTimeout = 45000
        connection.doOutput = true
        connection.setChunkedStreamingMode(16384)
        connection.setRequestProperty("Content-Type","multipart/form-data; boundary=$boundary")
        val stream = resolver.openInputStream(uri) ?: throw IOException("De foto kan niet worden geopend.")
        stream.use { input ->
            connection.outputStream.use { output ->
                output.write("--$boundary\r\nContent-Disposition: form-data; name=\"data\"\r\n\r\n".toByteArray())
                val field = object : FilterOutputStream(output) { override fun close() = flush()
                    override fun write(b: ByteArray, off: Int, len: Int) = out.write(b,off,len) }
                Base64.getEncoder().wrap(field).use { input.copyTo(it) }
                output.write("\r\n--$boundary--\r\n".toByteArray())
            }
        }
        if (connection.responseCode !in 200..299) throw IOException("Upload van de foto is niet bevestigd.")
        val photo = JSONObject(connection.inputStream.bufferedReader().use { it.readText() })
        if (photo.str("url").isBlank()) throw IOException("Het foto-adres ontbreekt.")
        return photo
    } finally { connection.disconnect() }
}
