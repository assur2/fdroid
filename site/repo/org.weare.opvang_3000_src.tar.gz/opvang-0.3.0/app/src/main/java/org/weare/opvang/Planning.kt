// SPDX-License-Identifier: GPL-3.0-only
package org.weare.opvang

import java.io.IOException
import java.time.LocalDate
import java.time.LocalTime
import java.time.YearMonth
import java.time.format.DateTimeFormatter
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject
import org.jsoup.Connection

private val nl = Locale.forLanguageTag("nl-NL")
private val dayLabel = DateTimeFormatter.ofPattern("EEEE d MMMM yyyy",nl)
private val apiDate = DateTimeFormatter.ofPattern("dd-MM-yyyy",nl)
private fun date(value: String) = runCatching { LocalDate.parse(value.take(10)) }.getOrNull()
private fun MobileApi.location(c: JSONObject) = profile.list("locations").find { it.id("id") == c.id("location_id") }
internal fun MobileApi.holidayAccess(c: JSONObject, edit: Boolean = false) =
    location(c)?.optBoolean("set_holidays_by_parents") == true && allowed(if (edit) "edit_holiday" else "view_holiday",
        c.id("location_id"), child = c.id("child_id"), parent = c.id("parents_id"))

private fun MobileApi.contractName(c: JSONObject): String {
    val child = profile.list("children").find { it.id("id") == c.id("child_id") }
    return listOf(child?.str("normal_name","firstname").orEmpty().ifBlank { c.str("contract_child_name","name") },
        location(c)?.str("name").orEmpty(), c.str("contract_number").ifBlank { "Contract " + c.str("id") })
        .filter(String::isNotBlank).joinToString(" · ")
}

internal fun MobileApi.planningPage(link: Link): Page {
    val parts = link.path.split('/')
    val section = parts.first()
    val contracts = profile.list("contracts").filter { c -> c.id("id") != null && when(section) {
        "holidays" -> holidayAccess(c)
        "moments" -> location(c)?.optBoolean("moments_show") == true
        else -> true
    } }
    if (parts.size == 1) return Page(link.label,emptyList(),contracts.map { c ->
        val path = "$section/" + c.str("id")
        Link(contractName(c),when(section) {
            "moments" -> "$path/" + LocalDate.now()
            "planning" -> "$path/" + YearMonth.now()
            else -> path
        })
    })
    val contract = contracts.find { it.id("id") == parts[1] } ?: throw IOException("Onderdeel niet beschikbaar voor dit contract.")
    val id = parts[1]
    if (section == "holidays") {
        val query = mapOf("location_id" to contract.str("location_id"))
        val path = "contracts/$id/holidays"
        val data = body(path,query)
        val periods = rowsOf(data,"holidays")
        val actions = if (!holidayAccess(contract,true)) emptyList() else listOf(ParentAction("Vakantie toevoegen",contractName(contract),link,
            listOf(Input("Vanaf",kind = InputKind.Date),Input("Tot en met",kind = InputKind.Date)),"Vakantie doorgeven") { fields ->
            val start = LocalDate.parse(fields.getValue("Vanaf"))
            val end = LocalDate.parse(fields.getValue("Tot en met"))
            if (end <= start) throw IOException("Kies een einddatum na de begindatum.")
            if (!withinContract(contract,start) || !withinContract(contract,end)) throw IOException("Kies een periode binnen het contract.")
            body(path,query + mapOf("start_date" to start.toString(),"end_date" to end.toString()),method = Connection.Method.POST)
        })
        return Page("Vakanties",listOf(Entry(contractName(contract),periods.map { it.str("start_date") + " t/m " + it.str("end_date") }
            .ifEmpty { listOf("Geen vakanties geregistreerd.") },actions = actions)),emptyList())
    }
    if (section == "moments") {
        val day = LocalDate.parse(parts[2])
        val records = rowsOf(body("moments/contract/$id/",mapOf("date" to day.toString())),"moments")
        return Page("Dagritme",listOf(Entry(contractName(contract),listOf(day.format(dayLabel)))) + records.map { row ->
            val start = row.str("start_time")
            val end = runCatching { LocalTime.parse(start).plusMinutes(row.getLong("duration")).format(DateTimeFormatter.ofPattern("HH:mm")) }.getOrNull()
            Entry(row.child("moments_category").str("name"), listOf(listOfNotNull(start,end).joinToString(" – "),row.str("remarks"),
                row.child("status").str("remarks")).filter(String::isNotBlank))
        }.ifEmpty { listOf(Entry("Geen registraties op deze dag.")) },listOf(
            Link("Vorige dag","moments/$id/" + day.minusDays(1)),Link("Volgende dag","moments/$id/" + day.plusDays(1))))
    }
    val month = YearMonth.parse(parts[2])
    val data = body("contracts/$id/schedule",mapOf("month" to month.monthValue.toString(),"year" to month.year.toString())) as? JSONObject
        ?: throw IOException("Planning ontbreekt.")
    val days = rowsOf(data,"workdays")
    if (parts.size == 3) return Page("Mijn opvang",listOf(Entry(contractName(contract),listOf(month.format(DateTimeFormatter.ofPattern("MMMM yyyy",nl))))),
        days.mapNotNull { d -> date(d.str("date"))?.let { day ->
            val count = d.list("occupations").size
            Link(day.format(dayLabel) + if (count > 0) " · $count boeking(en)" else "",link.path + "/" + day)
        } } + listOf(Link("Vorige maand","planning/$id/" + month.minusMonths(1)),Link("Volgende maand","planning/$id/" + month.plusMonths(1))))
    val day = LocalDate.parse(parts[3])
    val workday = days.find { date(it.str("date")) == day } ?: throw IOException("Deze dag staat niet in de planning.")
    val loc = location(contract) ?: throw IOException("Opvanglocatie ontbreekt.")
    val groups = loc.list("groups").filterNot { it.optBoolean("archive") }
        .mapNotNull { g -> g.id("id")?.let { it to g.str("name") } }.toMap()
    val meta = data.child("meta")
    fun available(d: LocalDate): Boolean {
        val today = LocalDate.now()
        return withinContract(contract,d) && d >= today.plusDays(meta.optLong("time_limit",0)) &&
            (meta.optInt("weeks_limit") <= 0 || d <= today.plusWeeks(meta.optLong("weeks_limit"))) &&
            (meta.list("closings") + data.list("closings")).none { date(it.str("start_date")) != null && withinContract(it,d) }
    }
    val weekday = day.dayOfWeek.value % 7
    val blocks = when (val times = meta.opt("timeblocks")) {
        is JSONObject -> times.optJSONArray(weekday.toString())
        is JSONArray -> times.optJSONArray(weekday)
        else -> null
    }
    val timeblocks = (0 until (blocks?.length() ?: 0)).mapNotNull { blocks?.optString(it)?.takeIf(String::isNotBlank) }
    val editable = available(day)
    val subject = contractName(contract) + " · " + day.format(dayLabel)
    val newActions = if (editable && !loc.optBoolean("disable_extra_request") && groups.isNotEmpty())
        listOf(bookingAction("new",link,contract,day,null,groups,subject,::available,timeblocks)) else emptyList()
    val entries = workday.list("occupations").map { occ ->
        val group = groups[occ.str("group_id")] ?: occ.str("group_name").ifBlank { "Boeking" }
        val time = clock(occ,"starttime") + " – " + clock(occ,"endtime")
        val actions = buildList {
            if (editable && !occ.optBoolean("cancelled") && !occ.optBoolean("moved") && occ.optBoolean("authorized",true)) {
                if (!loc.optBoolean("disable_absent_request") && !occ.optBoolean("cancel_disabled"))
                    add(bookingAction("free",link,contract,day,occ,groups,"$subject · $group · $time",::available))
                if (!loc.optBoolean("disable_edit_request"))
                    add(bookingAction("change",link,contract,day,occ,groups,"$subject · $group · $time",::available,timeblocks))
                if (!loc.optBoolean("disable_switch_request") && !occ.optBoolean("switсh_disabled") && !occ.optBoolean("switch_disabled"))
                    add(bookingAction("switch",link,contract,day,occ,groups,"$subject · $group · $time",::available))
            }
        }
        Entry(group,listOf(time,occ.str("remarks")).filter(String::isNotBlank),actions = actions)
    }
    return Page("Mijn opvang",listOf(Entry(subject, if (entries.isEmpty()) listOf("Geen boekingen.") else emptyList(),actions = newActions)) + entries,emptyList())
}

private fun rowsOf(value: Any,key: String): List<JSONObject> = when(value) {
    is JSONArray -> value.objects()
    is JSONObject -> value.optJSONArray(key)?.objects() ?: throw IOException("KOVnet gaf een onverwacht formaat voor $key.")
    else -> throw IOException("Gegevens ontbreken.")
}
private fun withinContract(c: JSONObject,day: LocalDate) =
    date(c.str("start_date"))?.let { day < it } != true && date(c.str("end_date"))?.let { day > it } != true
private fun clock(occ: JSONObject,prefix: String) =
    occ.str(prefix + "_hours").padStart(2,'0') + ":" + occ.str(prefix + "_minutes").padStart(2,'0')

private fun MobileApi.bookingAction(choice: String, link: Link, c: JSONObject, day: LocalDate, occ: JSONObject?,
    groups: Map<String,String>, subject: String, available: (LocalDate) -> Boolean, timeblocks: List<String> = emptyList()): ParentAction {
    val reasons = mapOf("Ziek" to "Ziek","Vakantie" to "Vakantie","Bijzonder verlof" to "Bijzonder verlof","Other" to "Anders")
    val fields = buildList {
        when(choice) {
            "free" -> add(Input("Reden",kind = InputKind.Choice,choices = reasons))
            "switch" -> add(Input("Ruilen naar",kind = InputKind.Date))
            "new", "change" -> {
                if (choice == "new") add(Input("Groep",groups.keys.singleOrNull().orEmpty(),InputKind.Choice,groups))
                if (timeblocks.isEmpty()) {
                    add(Input("Begintijd",occ?.let { clock(it,"starttime") }.orEmpty(),InputKind.Time))
                    add(Input("Eindtijd",occ?.let { clock(it,"endtime") }.orEmpty(),InputKind.Time))
                } else add(Input("Dagdeel",kind = InputKind.Choice,choices = timeblocks.associateWith { it }))
            }
        }
        add(Input("Opmerking",required = false))
    }
    val title = when(choice) { "free" -> "Afwezig melden"; "switch" -> "Ruilen"; "change" -> "Tijden wijzigen"; else -> "Extra opvang" }
    return ParentAction(title,subject,link,fields,"Aanvraag versturen") { values ->
        val target = values["Ruilen naar"]?.let(LocalDate::parse) ?: day
        if (!available(day) || !available(target) || choice == "switch" && target == day) throw IOException("Kies een beschikbare opvangdag.")
        if (choice == "switch") {
            val calendar = body("contracts/" + c.str("id") + "/schedule",
                mapOf("month" to target.monthValue.toString(),"year" to target.year.toString()))
            val targetDays = rowsOf(calendar,"workdays")
            if (targetDays.none { date(it.str("date")) == target } ||
                (calendar as? JSONObject)?.child("meta")?.list("closings").orEmpty().any { date(it.str("start_date")) != null && withinContract(it,target) })
                throw IOException("Op deze ruildatum is geen opvang beschikbaar.")
        }
        val block = values["Dagdeel"]
        val bounds = block?.split('-')?.map { it.trim() }
        val start = values["Begintijd"] ?: bounds?.firstOrNull() ?: clock(requireNotNull(occ),"starttime")
        val end = values["Eindtijd"] ?: bounds?.lastOrNull() ?: clock(requireNotNull(occ),"endtime")
        fun minutes(s: String): Long {
            val t = runCatching { LocalTime.parse(s.padStart(5,'0')) }.getOrNull() ?: throw IOException("Onbekend tijdvak.")
            return t.toSecondOfDay() / 60L
        }
        val duration = minutes(end) - minutes(start)
        if (duration <= 0) throw IOException("Kies een eindtijd na de begintijd.")
        val group = occ?.get("group_id") ?: values.getValue("Groep").toLong()
        val payload = json("choice" to choice,"group_id" to group,"flex_date" to day.format(apiDate),
            "day" to day.dayOfMonth.toString(),"month" to day.monthValue.toString(),"year" to day.year.toString(),
            "switch_date" to target.format(apiDate),"timeblock" to block.orEmpty(),"starttime_hours" to if (block == null) start.substringBefore(':') else "00",
            "starttime_minutes" to if (block == null) start.substringAfter(':') else "00","endtime_hours" to if (block == null) end.substringBefore(':') else "00",
            "endtime_minutes" to if (block == null) end.substringAfter(':') else "00",
            "location_id" to c.get("location_id").toString(),"contract_id" to c.get("id").toString(),"parents_id" to c.get("parents_id").toString(),
            "remarks" to values["Opmerking"].orEmpty(),"destroy" to false)
        when(choice) {
            "free" -> payload.put("absence_reason",values.getValue("Reden")).put("form_title","Afmelding: ")
            "switch" -> payload.put("form_title","Ruilen naar: ").put("hours_difference",0)
            "new" -> {
                payload.put("authorized",false)
                if (block != null) payload.put("form_title","Extra opvang: ")
            }
        }
        val request = json("occupation" to payload,"use_hours_bucket" to false)
        if (choice == "change" && occ != null) {
            val oldDuration = minutes(clock(occ,"endtime")) - minutes(clock(occ,"starttime"))
            payload.put("hours_difference",(duration - oldDuration) / 60.0)
            for (field in listOf("starttime_hours","starttime_minutes","endtime_hours","endtime_minutes")) {
                payload.put("original_$field",occ.str(field))
                request.put("og_$field",occ.str(field))
            }
        }
        body("contracts/" + c.str("id") + "/schedule",payload = request)
    }
}
